set DESIGN expression

read_libs /home/install/FOUNDRY/digital/90nm/dig/lib/typical.lib

read_hdl expression.v
elaborate $DESIGN
current_design $DESIGN
check_design -unresolved

create_clock -name clk -period 10

set_input_delay 1 -clock clk [all_inputs]
set_output_delay 1 -clock clk [all_outputs]

syn_generic
syn_map
syn_opt

report_area
report_timing
report_power

write_hdl > expression_netlist.v
write_sdc > expression_constraints.sdc

gui_show

