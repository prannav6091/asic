
//input ports
add mapped point clk clk -type PI PI
add mapped point rst rst -type PI PI
add mapped point a[7] a[7] -type PI PI
add mapped point a[6] a[6] -type PI PI
add mapped point a[5] a[5] -type PI PI
add mapped point a[4] a[4] -type PI PI
add mapped point a[3] a[3] -type PI PI
add mapped point a[2] a[2] -type PI PI
add mapped point a[1] a[1] -type PI PI
add mapped point a[0] a[0] -type PI PI
add mapped point b[7] b[7] -type PI PI
add mapped point b[6] b[6] -type PI PI
add mapped point b[5] b[5] -type PI PI
add mapped point b[4] b[4] -type PI PI
add mapped point b[3] b[3] -type PI PI
add mapped point b[2] b[2] -type PI PI
add mapped point b[1] b[1] -type PI PI
add mapped point b[0] b[0] -type PI PI
add mapped point c[7] c[7] -type PI PI
add mapped point c[6] c[6] -type PI PI
add mapped point c[5] c[5] -type PI PI
add mapped point c[4] c[4] -type PI PI
add mapped point c[3] c[3] -type PI PI
add mapped point c[2] c[2] -type PI PI
add mapped point c[1] c[1] -type PI PI
add mapped point c[0] c[0] -type PI PI
add mapped point d[7] d[7] -type PI PI
add mapped point d[6] d[6] -type PI PI
add mapped point d[5] d[5] -type PI PI
add mapped point d[4] d[4] -type PI PI
add mapped point d[3] d[3] -type PI PI
add mapped point d[2] d[2] -type PI PI
add mapped point d[1] d[1] -type PI PI
add mapped point d[0] d[0] -type PI PI

//output ports
add mapped point z[9] z[9] -type PO PO
add mapped point z[8] z[8] -type PO PO
add mapped point z[7] z[7] -type PO PO
add mapped point z[6] z[6] -type PO PO
add mapped point z[5] z[5] -type PO PO
add mapped point z[4] z[4] -type PO PO
add mapped point z[3] z[3] -type PO PO
add mapped point z[2] z[2] -type PO PO
add mapped point z[1] z[1] -type PO PO
add mapped point z[0] z[0] -type PO PO

//inout ports




//Sequential Pins
add mapped point z[9]/q z_reg[9]/Q -type DFF DFF
add mapped point z[8]/q z_reg[8]/Q -type DFF DFF
add mapped point sum3[9]/q sum3_reg[9]/Q -type DFF DFF
add mapped point sum3[8]/q sum3_reg[8]/Q -type DFF DFF
add mapped point z[7]/q z_reg[7]/Q -type DFF DFF
add mapped point sum3[7]/q sum3_reg[7]/Q -type DFF DFF
add mapped point z[6]/q z_reg[6]/Q -type DFF DFF
add mapped point sum3[6]/q sum3_reg[6]/Q -type DFF DFF
add mapped point sum2[7]/q sum2_reg[7]/Q -type DFF DFF
add mapped point sum2[8]/q sum2_reg[8]/Q -type DFF DFF
add mapped point sum1[7]/q sum1_reg[7]/Q -type DFF DFF
add mapped point sum1[8]/q sum1_reg[8]/Q -type DFF DFF
add mapped point z[5]/q z_reg[5]/Q -type DFF DFF
add mapped point sum3[5]/q sum3_reg[5]/Q -type DFF DFF
add mapped point sum2[6]/q sum2_reg[6]/Q -type DFF DFF
add mapped point sum1[6]/q sum1_reg[6]/Q -type DFF DFF
add mapped point z[4]/q z_reg[4]/Q -type DFF DFF
add mapped point sum3[4]/q sum3_reg[4]/Q -type DFF DFF
add mapped point sum2[5]/q sum2_reg[5]/Q -type DFF DFF
add mapped point sum1[5]/q sum1_reg[5]/Q -type DFF DFF
add mapped point z[3]/q z_reg[3]/Q -type DFF DFF
add mapped point sum3[3]/q sum3_reg[3]/Q -type DFF DFF
add mapped point sum2[4]/q sum2_reg[4]/Q -type DFF DFF
add mapped point sum1[4]/q sum1_reg[4]/Q -type DFF DFF
add mapped point z[2]/q z_reg[2]/Q -type DFF DFF
add mapped point sum3[2]/q sum3_reg[2]/Q -type DFF DFF
add mapped point sum2[3]/q sum2_reg[3]/Q -type DFF DFF
add mapped point sum1[3]/q sum1_reg[3]/Q -type DFF DFF
add mapped point z[1]/q z_reg[1]/Q -type DFF DFF
add mapped point sum3[1]/q sum3_reg[1]/Q -type DFF DFF
add mapped point sum2[2]/q sum2_reg[2]/Q -type DFF DFF
add mapped point sum1[2]/q sum1_reg[2]/Q -type DFF DFF
add mapped point z[0]/q z_reg[0]/Q -type DFF DFF
add mapped point sum3[0]/q sum3_reg[0]/Q -type DFF DFF
add mapped point sum2[1]/q sum2_reg[1]/Q -type DFF DFF
add mapped point sum1[1]/q sum1_reg[1]/Q -type DFF DFF
add mapped point sum2[0]/q sum2_reg[0]/Q -type DFF DFF
add mapped point sum1[0]/q sum1_reg[0]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
