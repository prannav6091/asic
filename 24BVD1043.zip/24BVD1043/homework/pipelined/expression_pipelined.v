module expression_pipelined (
    input        clk,
    input        rst,
    input  [7:0] a,
    input  [7:0] b,
    input  [7:0] c,
    input  [7:0] d,
    output reg [9:0] z
);

reg [8:0] sum1;
reg [8:0] sum2;
reg [9:0] sum3;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        sum1 <= 0;
        sum2 <= 0;
        sum3 <= 0;
        z    <= 0;
    end
    else begin
        sum1 <= a + b;
        sum2 <= c + d;
        sum3 <= sum1 + sum2;
        z    <= sum3;
    end
end

endmodule
