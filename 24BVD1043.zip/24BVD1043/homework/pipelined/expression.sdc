# ==========================================
# SDC constraints for pipelined expression
# ==========================================

# Actual design clock - 10 ns period (100 MHz)
create_clock -name CLK -period 10.0 [get_ports clk]

# Input delays for data inputs
set_input_delay 2.0 -clock CLK \
    [remove_from_collection [all_inputs] [get_ports {clk rst}]]

# Output delays
set_output_delay 2.0 -clock CLK [all_outputs]

# Input transition for data inputs
set_input_transition 0.2 \
    [remove_from_collection [all_inputs] [get_ports {clk rst}]]

# Output load
set_load 0.05 [all_outputs]
