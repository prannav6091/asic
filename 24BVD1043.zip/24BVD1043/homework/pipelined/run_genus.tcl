# ==========================================
# Design configuration
# ==========================================

set TOP_MODULE "expression_pipelined"

# ==========================================
# Library and RTL search paths
# ==========================================

set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
set_db init_hdl_search_path /home/vlsi35/24BVD1043/homework/pipelined


# ==========================================
# Read standard-cell library
# ==========================================

read_libs slow.lib

# ==========================================
# Read pipelined RTL
# ==========================================

read_hdl expression_pipelined.v
elaborate $TOP_MODULE
current_design $TOP_MODULE

# ==========================================
# Read timing constraints
# ==========================================

read_sdc expression.sdc

# ==========================================
# Synthesis effort
# ==========================================

set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium

# ==========================================
# Generic synthesis
# ==========================================

syn_generic
write_hdl > output/netlist/${TOP_MODULE}_generic.v

# ==========================================
# Technology mapping
# ==========================================

syn_map
write_hdl > output/netlist/${TOP_MODULE}_mapped.v

# ==========================================
# Optimization
# ==========================================

syn_opt
write_hdl > output/netlist/${TOP_MODULE}_opt.v

# ==========================================
# Export synthesized constraints
# ==========================================

write_sdc > output/constraints/${TOP_MODULE}_synth.sdc

# ==========================================
# Reports
# ==========================================

report_timing > output/reports/${TOP_MODULE}_timing.rpt
report_power  > output/reports/${TOP_MODULE}_power.rpt
report_area   > output/reports/${TOP_MODULE}_area.rpt
report_gates  > output/reports/${TOP_MODULE}_gates.rpt
report_qor    > output/reports/${TOP_MODULE}_qor.rpt

# ==========================================
# Open GUI
# ==========================================

gui_show
