module expression (
input [7:0] a,
input [7:0] b,
input [7:0] c,
input [7:0] d,
output [9:0] z);

assign z = a+b+c+d;

endmodule
