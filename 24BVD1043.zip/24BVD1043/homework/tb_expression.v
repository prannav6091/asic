`timescale 1ns/1ps

module tb_expression;

reg [7:0] a, b, c, d;
wire [9:0] y;

reg [9:0] expected;
integer i, j, k, l;
integer errors;

expression dut (
.a(a),
.b(b),
.c(c),
.d(d),
.y(y)
);

initial begin
errors = 0;

```
for (i = 0; i < 256; i = i + 1) begin
    for (j = 0; j < 256; j = j + 1) begin
        for (k = 0; k < 256; k = k + 1) begin
            for (l = 0; l < 256; l = l + 1) begin
                a = i;
                b = j;
                c = k;
                d = l;

                expected = i + j + k + l;

                #1;

                if (y !== expected) begin
                    errors = errors + 1;
                    $display("ERROR: a=%0d b=%0d c=%0d d=%0d expected=%0d got=%0d",
                             a, b, c, d, expected, y);
                end
            end
        end
    end
end

if (errors == 0)
    $display("PASS: All input combinations passed.");
else
    $display("FAIL: %0d mismatches detected.", errors);

$finish;
```

end

endmodule

