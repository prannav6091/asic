# Virtual clock - 10 ns period
create_clock -name VCLK -period 10.0

# Input delay
set_input_delay 2.0 -clock VCLK [all_inputs]

# Output delay
set_output_delay 2.0 -clock VCLK [all_outputs]

# Input transition
set_input_transition 0.2 [all_inputs]

# Output load
set_load 0.05 [all_outputs]
