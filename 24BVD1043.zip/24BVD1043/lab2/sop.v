module sop(
input [3:0] a,
input [3:0] b,
input [3:0] c,
input [3:0] d,
output [3:0] y);

assign y = (a & b) | (c & d);

endmodule
