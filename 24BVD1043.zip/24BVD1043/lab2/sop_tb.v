module sop_tb;

// 4-bit vector declarations matching DUT ports
reg  [3:0] a, b, c, d;
wire [3:0] y;

// Instantiate DUT
sop dut (
    .a(a),
    .b(b),
    .c(c),
    .d(d),
    .y(y)
);

initial begin
    // Test Case 1: Both terms FALSE (a&b=0, c&d=0 -> y=0)
    a = 4'h0; b = 4'h0; c = 4'h0; d = 4'h0;
    #10;

    // Test Case 2: Only Term 1 TRUE (a&b=1, c&d=0 -> y=1)
    a = 4'hF; b = 4'hF; c = 4'h0; d = 4'h0;
    #10;

    // Test Case 3: Only Term 2 TRUE (a&b=0, c&d=1 -> y=1)
    a = 4'h0; b = 4'h0; c = 4'hF; d = 4'hF;
    #10;

    // Test Case 4: Mismatched inputs (a=1, b=0, c=0, d=1 -> y=0)
    // Proves each AND condition independently requires BOTH inputs high
    a = 4'hF; b = 4'h0; c = 4'h0; d = 4'hF;
    #10;

    // Test Case 5: Reset all signals to 0
    // Completes 1 -> 0 toggles for 100% Toggle Coverage
    a = 4'h0; b = 4'h0; c = 4'h0; d = 4'h0;
    #10;

    $finish;
end

endmodule
