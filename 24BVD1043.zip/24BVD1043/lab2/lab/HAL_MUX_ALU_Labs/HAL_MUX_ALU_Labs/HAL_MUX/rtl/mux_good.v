module mux_good (
    input  wire [3:0] a,
    input  wire [3:0] b,
    input  wire       sel,
    output wire [3:0] y
);

    // Continuous assignment handles 2:1 MUX cleanly
    assign y = sel ? a : b;

endmodule
