//--------------------------------------
// Controller
//--------------------------------------
module controller (
    input  wire clk,
    input  wire rst,
    input  wire start,
    output reg  load,
    output reg  execute,
    output reg  done
);

    // 2-bit local parameters with explicit bit-widths
    localparam [1:0] IDLE    = 2'b00;
    localparam [1:0] LOAD    = 2'b01;
    localparam [1:0] EXECUTE = 2'b10;
    localparam [1:0] DONE    = 2'b11;

    reg [1:0] state;
    reg [1:0] next_state;

    // Sequential State Register
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= IDLE;
        end else begin
            state <= next_state;
        end
    end

    // Combinational Next-State Logic
    always @(state or start) begin
        case (state)
            IDLE: begin
                if (start == 1'b1) begin
                    next_state = LOAD;
                end else begin
                    next_state = IDLE;
                end
            end
            LOAD: begin
                next_state = EXECUTE;
            end
            EXECUTE: begin
                next_state = DONE;
            end
            DONE: begin
                if (start == 1'b0) begin
                    next_state = IDLE;
                end else begin
                    next_state = DONE;
                end
            end
            default: begin
                next_state = IDLE;
            end
        endcase
    end

    // Combinational Output Logic
    always @(state) begin
        load    = 1'b0;
        execute = 1'b0;
        done    = 1'b0;

        case (state)
            IDLE: begin
                load    = 1'b0;
                execute = 1'b0;
                done    = 1'b0;
            end
            LOAD: begin
                load    = 1'b1;
                execute = 1'b0;
                done    = 1'b0;
            end
            EXECUTE: begin
                load    = 1'b0;
                execute = 1'b1;
                done    = 1'b0;
            end
            DONE: begin
                load    = 1'b0;
                execute = 1'b0;
                done    = 1'b1;
            end
            default: begin
                load    = 1'b0;
                execute = 1'b0;
                done    = 1'b0;
            end
        endcase
    end

endmodule
