//--------------------------------------
// Top Module
//--------------------------------------
module sapu (
    input  wire       clk,
    input  wire       rst,
    input  wire       start,
    input  wire       op,
    input  wire [3:0] A,
    input  wire [3:0] B,
    output wire [4:0] Y,
    output wire       done
);

    wire load;
    wire execute;

    controller CU (
        .clk(clk),
        .rst(rst),
        .start(start),
        .load(load),
        .execute(execute),
        .done(done)
    );

    datapath DP (
        .clk(clk),
        .rst(rst),
        .load(load),
        .execute(execute),
        .op(op),
        .A(A),
        .B(B),
        .Y(Y)
    );

endmodule
