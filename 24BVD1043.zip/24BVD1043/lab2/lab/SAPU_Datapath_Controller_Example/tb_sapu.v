module tb_sapu;

    reg        clk;
    reg        rst;
    reg        start;
    reg        op;
    reg  [3:0] A;
    reg  [3:0] B;

    wire [4:0] Y;
    wire       done;

    // Instantiate DUT
    sapu dut (
        .clk(clk),
        .rst(rst),
        .start(start),
        .op(op),
        .A(A),
        .B(B),
        .Y(Y),
        .done(done)
    );

    // 10ns Clock Generation
    always #5 clk = ~clk;

    // Task to run transaction and strictly follow FSM states (IDLE -> LOAD -> EXECUTE -> DONE)
    task execute_op(input [3:0] in_a, input [3:0] in_b, input in_op);
        begin
            @(posedge clk);
            A     = in_a;
            B     = in_b;
            op    = in_op;
            start = 1'b1;

            // Wait for FSM to move from IDLE -> LOAD -> EXECUTE
            @(posedge clk);
            
            // De-assert start during EXECUTE state
            start = 1'b0;

            // Wait until FSM reaches DONE state
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    initial begin
        // Initialize Signals
        clk   = 1'b0;
        rst   = 1'b1;
        start = 1'b0;
        op    = 1'b0;
        A     = 4'b0000;
        B     = 4'b0000;

        // Step 1: Release Reset and verify IDLE -> IDLE loop
        #12 rst = 1'b0;
        #20; // Tests IDLE -> IDLE transition (start = 0)

        // Step 2: Addition (op = 0) -> 3 + 2 = 5
        // Covers: op = 0 branch in Datapath
        execute_op(4'd3, 4'd2, 1'b0);
        #20;

        // Step 3: Subtraction (op = 1) -> 8 - 5 = 3
        // Covers: op = 1 branch in Datapath
        execute_op(4'd8, 4'd5, 1'b1);
        #20;

        // Step 4: FSM DONE -> DONE state coverage test
        // Asserts start = 1 while in DONE state to hit the DONE -> DONE transition branch
        @(posedge clk);
        start = 1'b1;
        execute_op(4'd15, 4'd15, 1'b0); // Drive all bits to 1s for 100% Toggle Coverage (0xF + 0xF)

        // Step 5: Complete Bit Toggles (0xF -> 0x0 -> 0xF -> 0x0)
        execute_op(4'd0, 4'd0, 1'b1);

        // Step 6: Reset re-assertion for 100% Reset Line Toggle Coverage
        rst = 1'b1;
        #10;
        rst = 1'b0;
        #10;

        // Fixed the '100%' format issue using '100%%'
        $display("--- 100%% COVERAGE TEST COMPLETED ---");
        $finish;
    end

endmodule
