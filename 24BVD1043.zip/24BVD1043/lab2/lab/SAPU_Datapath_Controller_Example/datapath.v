//--------------------------------------
// Datapath
//--------------------------------------
module datapath (
    input  wire       clk,
    input  wire       rst,
    input  wire       load,
    input  wire       execute,
    input  wire       op,
    input  wire [3:0] A,
    input  wire [3:0] B,
    output reg  [4:0] Y
);

    reg [3:0] regA;
    reg [3:0] regB;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            regA <= 4'b0000;
            regB <= 4'b0000;
            Y    <= 5'b00000;
        end else begin
            if (load == 1'b1) begin
                regA <= A;
                regB <= B;
            end
            if (execute == 1'b1) begin
                if (op == 1'b1) begin
                    Y <= {1'b0, regA} - {1'b0, regB};
                end else begin
                    Y <= {1'b0, regA} + {1'b0, regB};
                end
            end
        end
    end

endmodule
