module tb_fsm_full;

reg clk, rst, x;
wire y;

fsm_cov dut(
    .clk(clk),
    .rst(rst),
    .x(x),
    .y(y)
);

// Clock generator: Provides continuous 0->1 and 1->0 toggles
always #5 clk = ~clk;

initial begin
    // Initialize inputs
    clk = 0;
    rst = 1;
    x = 0;
    #10;
    
    // Release reset (rst transitions 1 -> 0)
    rst = 0;
    #10;

    // Sequence to traverse states (S0 -> S1 -> S2)
    // S0 -> S1
    x = 1;
    #10;

    // S1 -> S2 (If y acts here or on the next cycle, it will toggle)
    x = 1;
    #10;

    // S2 -> S0 (Bring x back down, forcing x to toggle 1 -> 0)
    x = 0;
    #10;

    // S0 stay
    x = 0;
    #10;
    
    // --- ADDITIONAL TOGGLE COVERAGE FIXES ---
    
    // 1. Force 'rst' to toggle back from 0 -> 1 -> 0
    // This solves the 50% coverage bottleneck on the rst signal line
    rst = 1; 
    #10;
    rst = 0;
    #10;

    // 2. Extra cycle to allow output 'y' to settle back to 0 
    // (Ensures y completes both its 0->1 and 1->0 transitions)
    x = 1;
    #10;
    x = 0;
    #10;

    $finish;
end

endmodule
