module adder_tb;

reg a, b, cin;
wire sum, cout;

// Instantiate DUT
adder dut (
    .a(a),
    .b(b),
    .cin(cin),
    .sum(sum),
    .cout(cout)
);

initial begin
    // Step 0: Set initial state (0 -> 1 preparation)
    a = 0; b = 0; cin = 0;
    #10; // sum = 0, cout = 0

    // Vector 1: Drive all inputs HIGH
    a = 1; b = 1; cin = 1;
    #10; // All inputs & outputs toggle: 0 -> 1

    // Vector 2: Drive all inputs LOW
    a = 0; b = 0; cin = 0;
    #10; // All inputs & outputs toggle: 1 -> 0

    $finish;
end

endmodule
