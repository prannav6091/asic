module seq_detector_101 (
    input wire clk,
    input wire rst,     // Active-high synchronous reset
    input wire x,       // Serial data input
    output reg y        // Sequence detected output (1 when "101" detected)
);

    // State Encoding
    localparam S0 = 2'b00; // Reset / Default state (No valid bits)
    localparam S1 = 2'b01; // Detected "1"
    localparam S2 = 2'b10; // Detected "10"

    reg [1:0] current_state, next_state;

    // 1. Sequential Block: State Register Update
    always @(posedge clk) begin
        if (rst) begin
            current_state <= S0;
        end else begin
            current_state <= next_state;
        end
    end

    // 2. Combinational Block: Next State Logic
    always @(*) begin
        case (current_state)
            S0: begin
                if (x) next_state = S1;
                else   next_state = S0;
            end

            S1: begin
                if (x) next_state = S1;
                else   next_state = S2;
            end

            S2: begin
                if (x) next_state = S1; // '101' detected! Overlaps into S1 for potential '10101'
                else   next_state = S0;
            end

            default: next_state = S0;
        endcase
    end

    // 3. Output Logic (Mealy machine output: depends on state and current input)
    always @(*) begin
        case (current_state)
            S2:      y = (x == 1'b1) ? 1'b1 : 1'b0;
            default: y = 1'b0;
        endcase
    end

endmodule
