module tb_seq_detector_101;

reg clk;
reg rst;
reg x;
wire y;

// Instantiate the FSM DUT
seq_detector_101 dut (
    .clk(clk),
    .rst(rst),
    .x(x),
    .y(y)
);

// 10ns period clock
always #5 clk = ~clk;

initial begin
    // Initialize signals
    clk = 0;
    rst = 1;
    x = 0;
    #10; // State S0 (Reset active) -> Covers S0 state

    // Step 1: Release reset while x=0
    // Covers S0 -> S0 transition (staying in S0 on x=0)
    rst = 0;
    x = 0;
    #10;

    // Step 2: Input x=1
    // Covers S0 -> S1 transition (moves to S1)
    x = 1;
    #10;

    // Step 3: Input x=1 again
    // Covers S1 -> S1 transition (staying in S1 on consecutive 1s)
    x = 1;
    #10;

    // Step 4: Input x=0
    // Covers S1 -> S2 transition (moves to S2)
    x = 0;
    #10;

    // Step 5: Input x=1 (Sequence "101" detected! Output y = 1)
    // Covers S2 -> S1 transition (overlapping detection branch)
    x = 1;
    #10;

    // Step 6: Input x=0 from S1 -> S2, then x=0 again to test S2 -> S0
    x = 0;
    #10; // Moves to S2
    x = 0;
    #10; // Covers S2 -> S0 transition (sequence broken, drops back to S0)

    // Step 7: Final toggle cleanup for 100% toggle coverage on rst
    rst = 1;
    #10;
    rst = 0;
    #10;

    $finish;
end

endmodule
