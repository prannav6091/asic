module tb_ripple_carry_adder_4bit;

    reg  [3:0] A;
    reg  [3:0] B;
    reg        cin;
    wire [3:0] sum;
    wire       cout;

    ripple_carry_adder_4bit uut (
        .A(A),
        .B(B),
        .cin(cin),
        .sum(sum),
        .cout(cout)
    );

    initial begin
        $display(" Time  |  A   B  cin | sum  cout | Decimal Math Check");
        
        $monitor("%4t ns | %b %b  %b  | %b   %b   | %2d + %2d + %0d = %2d (Carry: %0d)", 
                 $time, A, B, cin, sum, cout, A, B, cin, sum, cout);

        A = 4'b0000; B = 4'b0000; cin = 1'b0;
        #10;

        A = 4'b0011; B = 4'b0101; cin = 1'b0;
        #10;

        A = 4'b0110; B = 4'b0111; cin = 1'b1;
        #10;

        A = 4'b1100; B = 4'b0101; cin = 1'b0;
        #10;

        A = 4'b1111; B = 4'b1111; cin = 1'b1;
        #10;

        $finish;
    end

endmodule
