module tb_ripple_carry_adder_4bit;

    // 1. Declare signals for driving inputs and monitoring outputs
    reg  [3:0] A;
    reg  [3:0] B;
    reg        cin;
    wire [3:0] sum;
    wire       cout;

    // 2. Instantiate the Unit Under Test (UUT)
    ripple_carry_adder_4bit uut (
        .A(A),
        .B(B),
        .cin(cin),
        .sum(sum),
        .cout(cout)
    );

    // 3. Apply stimulus vectors
    initial begin
        // Display headers in the console window
        $display("-------------------------------------------------------");
        $display(" Time  |  A   B  cin | sum  cout | Decimal Math Check");
        $display("-------------------------------------------------------");
        
        // Automatically print values whenever any signal changes
        $monitor("%4t ns | %b %b  %b  | %b   %b   | %2d + %2d + %0d = %2d (Carry: %0d)", 
                 $time, A, B, cin, sum, cout, A, B, cin, sum, cout);

        // Test Case 1: Simple Addition (0 + 0)
        A = 4'b0000; B = 4'b0000; cin = 1'b0;
        #10;

        // Test Case 2: Addition without Carry-In (3 + 5 = 8)
        A = 4'b0011; B = 4'b0101; cin = 1'b0;
        #10;

        // Test Case 3: Addition with Carry-In (6 + 7 + 1 = 14)
        A = 4'b0110; B = 4 me_b0111; cin = 1'b1;
        #10;

        // Test Case 4: Overflow / Final Carry-Out (12 + 5 = 17 -> Sum: 1, Cout: 1)
        A = 4'b1100; B = 4'b0101; cin = 1'b0;
        #10;

        // Test Case 5: Maximum values (15 + 15 + 1 = 31 -> Sum: 15, Cout: 1)
        A = 4'b1111; B = 4'b1111; cin = 1'b1;
        #10;

        // Finish simulation
        $display("-------------------------------------------------------");
        $finish;
    end

endmodule
