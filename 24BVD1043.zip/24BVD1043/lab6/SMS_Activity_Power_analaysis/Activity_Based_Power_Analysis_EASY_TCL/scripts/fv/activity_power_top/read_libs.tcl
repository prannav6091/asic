add_search_path ../LIB/ -library -both
read_library -liberty -both \
    /home/vlsi35/24BVD1043/lab6/SMS_Activity_Power_analaysis/Activity_Based_Power_Analysis_EASY_TCL/scripts/../LIB/teaching_base.lib \
    /home/vlsi35/24BVD1043/lab6/SMS_Activity_Power_analaysis/Activity_Based_Power_Analysis_EASY_TCL/scripts/../LIB/teaching_base.lib

