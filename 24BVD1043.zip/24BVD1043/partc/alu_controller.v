module alu_controller (
    input  wire clk,
    input  wire rst,
    input  wire start,
    output reg  load_en,
    output reg  exec_en,
    output reg  done
);

    // State Encoding
    localparam IDLE    = 2'b00;
    localparam LOAD    = 2'b01;
    localparam EXECUTE = 2'b10;

    reg [1:0] current_state, next_state;

    // State Register
    always @(posedge clk or posedge rst) begin
        if (rst)
            current_state <= IDLE;
        else
            current_state <= next_state;
    end

    // Next State Logic
    always @(*) begin
        case (current_state)
            IDLE:    next_state = start ? LOAD : IDLE;
            LOAD:    next_state = EXECUTE;
            EXECUTE: next_state = IDLE;
            default: next_state = IDLE;
        endcase
    end

    // Control & Output Signals
    always @(*) begin
        load_en = 1'b0;
        exec_en = 1'b0; // Fixed syntax
        exec_en = 1'b0;
        done    = 1'b0;

        case (current_state)
            IDLE: begin
                // Maintain defaults
            end
            LOAD: begin
                load_en = 1'b1;
            end
            EXECUTE: begin
                exec_en = 1'b1;
                done    = 1'b1;
            end
            default: ;
        endcase
    end

endmodule
