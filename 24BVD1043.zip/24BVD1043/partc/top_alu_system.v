module top_alu_system (
    input  wire        clk,
    input  wire        rst,
    input  wire        start,
    input  wire [7:0]  in_a,
    input  wire [7:0]  in_b,
    input  wire [1:0]  op_sel,
    output wire [15:0] result,
    output wire        div_by_zero,
    output wire        done
);

    wire load_en, exec_en;

    // Instantiate Controller FSM
    alu_controller ctrl_inst (
        .clk(clk),
        .rst(rst),
        .start(start),
        .load_en(load_en),
        .exec_en(exec_en),
        .done(done)
    );

    // Instantiate Datapath
    alu_datapath dp_inst (
        .clk(clk),
        .rst(rst),
        .load_en(load_en),
        .exec_en(exec_en),
        .in_a(in_a),
        .in_b(in_b),
        .op_sel(op_sel),
        .result(result),
        .div_by_zero(div_by_zero)
    );

endmodule
