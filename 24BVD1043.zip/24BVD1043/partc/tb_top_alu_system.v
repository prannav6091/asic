module tb_top_alu_system;

    reg        clk;
    reg        rst;
    reg        start;
    reg  [7:0] in_a;
    reg  [7:0] in_b;
    reg  [1:0] op_sel;

    wire [15:0] result;
    wire        div_by_zero;
    wire        done;

    // Instantiate Top System
    top_alu_system uut (
        .clk(clk),
        .rst(rst),
        .start(start),
        .in_a(in_a),
        .in_b(in_b),
        .op_sel(op_sel),
        .result(result),
        .div_by_zero(div_by_zero),
        .done(done)
    );

    // 10ns Clock (100MHz)
    always #5 clk = ~clk;

    // Task to run transaction
    task run_op(input [7:0] a, input [7:0] b, input [1:0] op);
        begin
            @(posedge clk);
            in_a   = a;
            in_b   = b;
            op_sel = op;
            start  = 1'b1;
            @(posedge clk);
            start  = 1'b0;
            wait(done);
            @(posedge clk);
        end
    endtask

    initial begin
        // Waveform Dumping for Cadence SimVision
        $database("waves");
        $probe(tb_top_alu_system, "AS");

        // System Initialization
        clk   = 0;
        rst   = 1;
        start = 0;
        in_a  = 0;
        in_b  = 0;
        op_sel= 0;

        #20 rst = 0; // Release Reset
        #10;

        // 1. Addition (15 + 25 = 40)
        run_op(8'd15, 8'd25, 2'b00);

        // 2. Subtraction (100 - 35 = 65)
        run_op(8'd100, 8'd35, 2'b01);

        // 3. Multiplication (12 * 12 = 144)
        run_op(8'd12, 8'd12, 2'b10);

        // 4. Valid Division (80 / 4 = 20)
        run_op(8'd80, 8'd4, 2'b11);

        // 5. Corner Case: Division by Zero (50 / 0 -> div_by_zero = 1)
        run_op(8'd50, 8'd0, 2'b11);

        // 6. IDLE State Loop Coverage
        #30;

        // Cleanup Reset for 100% Toggle Coverage on Reset line
        rst = 1; #10;
        rst = 0; #10;

        $display("--- SIMULATION COMPLETE ---");
        $finish;
    end

endmodule
