module alu_datapath (
    input  wire        clk,
    input  wire        rst,
    input  wire        load_en,
    input  wire        exec_en,
    input  wire [7:0]  in_a,
    input  wire [7:0]  in_b,
    input  wire [1:0]  op_sel,
    output reg  [15:0] result,
    output reg         div_by_zero
);

    reg [7:0] a_reg, b_reg;
    reg [1:0] op_reg;

    // Load Registers
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            a_reg  <= 8'h00;
            b_reg  <= 8'h00;
            op_reg <= 2'b00;
        end else if (load_en) begin
            a_reg  <= in_a;
            b_reg  <= in_b;
            op_reg <= op_sel;
        end
    end

    // Execution Logic
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            result      <= 16'h0000;
            div_by_zero <= 1'b0;
        end else if (exec_en) begin
            div_by_zero <= 1'b0; // Default clear
            case (op_reg)
                2'b00: result <= a_reg + b_reg;        // Addition
                2'b01: result <= a_reg - b_reg;        // Subtraction
                2'b10: result <= a_reg * b_reg;        // Multiplication
                2'b11: begin                           // Division
                    if (b_reg == 8'h00) begin
                        div_by_zero <= 1'b1;
                        result      <= 16'hFFFF;       // Error flag output
                    end else begin
                        result      <= a_reg / b_reg;
                    end
                end
                default: result <= 16'h0000;
            endcase
        end
    end

endmodule
