module fir_normal (
    input  wire              clk,
    input  wire              rst,
    input  wire signed [7:0] x_in,
    output reg  signed [17:0] y_out
);

    // Fixed FIR coefficients
    parameter signed [7:0] H0 = 8'sd1;
    parameter signed [7:0] H1 = 8'sd2;
    parameter signed [7:0] H2 = 8'sd3;
    parameter signed [7:0] H3 = 8'sd4;

    // Delay line
    reg signed [7:0] x1, x2, x3;

    // Multiplication results
    wire signed [15:0] p0, p1, p2, p3;

    assign p0 = x_in * H0;
    assign p1 = x1   * H1;
    assign p2 = x2   * H2;
    assign p3 = x3   * H3;

    // FIR output
    wire signed [17:0] fir_sum;

    assign fir_sum = p0 + p1 + p2 + p3;

    always @(posedge clk) begin
        if (rst) begin
            x1    <= 8'sd0;
            x2    <= 8'sd0;
            x3    <= 8'sd0;
            y_out <= 18'sd0;
        end
        else begin
            x1    <= x_in;
            x2    <= x1;
            x3    <= x2;
            y_out <= fir_sum;
        end
    end

endmodule
