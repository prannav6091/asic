# Clock constraint: 10 ns period = 100 MHz
create_clock -name CLK -period 10.0 [get_ports clk]

# Input delay for data input
set_input_delay 2.0 -clock CLK [get_ports x_in]

# Reset is not a normal data timing path
set_false_path -from [get_ports rst]

# Output delay
set_output_delay 2.0 -clock CLK [get_ports y_out]

# Input transition
set_input_transition 0.2 [get_ports x_in]

# Output capacitive load
set_load 0.05 [get_ports y_out]
