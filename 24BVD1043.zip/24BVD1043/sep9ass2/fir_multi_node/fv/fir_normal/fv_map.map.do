
//input ports
add mapped point clk clk -type PI PI
add mapped point rst rst -type PI PI
add mapped point x_in[7] x_in[7] -type PI PI
add mapped point x_in[6] x_in[6] -type PI PI
add mapped point x_in[5] x_in[5] -type PI PI
add mapped point x_in[4] x_in[4] -type PI PI
add mapped point x_in[3] x_in[3] -type PI PI
add mapped point x_in[2] x_in[2] -type PI PI
add mapped point x_in[1] x_in[1] -type PI PI
add mapped point x_in[0] x_in[0] -type PI PI

//output ports
add mapped point y_out[17] y_out[17] -type PO PO
add mapped point y_out[16] y_out[16] -type PO PO
add mapped point y_out[15] y_out[15] -type PO PO
add mapped point y_out[14] y_out[14] -type PO PO
add mapped point y_out[13] y_out[13] -type PO PO
add mapped point y_out[12] y_out[12] -type PO PO
add mapped point y_out[11] y_out[11] -type PO PO
add mapped point y_out[10] y_out[10] -type PO PO
add mapped point y_out[9] y_out[9] -type PO PO
add mapped point y_out[8] y_out[8] -type PO PO
add mapped point y_out[7] y_out[7] -type PO PO
add mapped point y_out[6] y_out[6] -type PO PO
add mapped point y_out[5] y_out[5] -type PO PO
add mapped point y_out[4] y_out[4] -type PO PO
add mapped point y_out[3] y_out[3] -type PO PO
add mapped point y_out[2] y_out[2] -type PO PO
add mapped point y_out[1] y_out[1] -type PO PO
add mapped point y_out[0] y_out[0] -type PO PO

//inout ports




//Sequential Pins
add mapped point y_out[3]/q y_out_reg[3]/Q -type DFF DFF
add mapped point y_out[7]/q y_out_reg[7]/Q -type DFF DFF
add mapped point y_out[11]/q y_out_reg[11]/Q -type DFF DFF
add mapped point y_out[2]/q y_out_reg[2]/Q -type DFF DFF
add mapped point y_out[1]/q y_out_reg[1]/Q -type DFF DFF
add mapped point y_out[9]/q y_out_reg[9]/Q -type DFF DFF
add mapped point y_out[4]/q y_out_reg[4]/Q -type DFF DFF
add mapped point y_out[6]/q y_out_reg[6]/Q -type DFF DFF
add mapped point y_out[0]/q y_out_reg[0]/Q -type DFF DFF
add mapped point y_out[8]/q y_out_reg[8]/Q -type DFF DFF
add mapped point y_out[5]/q y_out_reg[5]/Q -type DFF DFF
add mapped point y_out[10]/q y_out_reg[10]/Q -type DFF DFF
add mapped point x3[3]/q x3_reg[3]/Q -type DFF DFF
add mapped point x3[2]/q x3_reg[2]/Q -type DFF DFF
add mapped point x3[7]/q x3_reg[7]/Q -type DFF DFF
add mapped point x3[4]/q x3_reg[4]/Q -type DFF DFF
add mapped point x3[5]/q x3_reg[5]/Q -type DFF DFF
add mapped point x3[1]/q x3_reg[1]/Q -type DFF DFF
add mapped point x3[0]/q x3_reg[0]/Q -type DFF DFF
add mapped point x3[6]/q x3_reg[6]/Q -type DFF DFF
add mapped point x2[2]/q x2_reg[2]/Q -type DFF DFF
add mapped point x2[3]/q x2_reg[3]/Q -type DFF DFF
add mapped point x2[7]/q x2_reg[7]/Q -type DFF DFF
add mapped point x2[6]/q x2_reg[6]/Q -type DFF DFF
add mapped point x2[4]/q x2_reg[4]/Q -type DFF DFF
add mapped point x2[1]/q x2_reg[1]/Q -type DFF DFF
add mapped point x2[0]/q x2_reg[0]/Q -type DFF DFF
add mapped point x2[5]/q x2_reg[5]/Q -type DFF DFF
add mapped point x1[2]/q x1_reg[2]/Q -type DFF DFF
add mapped point x1[5]/q x1_reg[5]/Q -type DFF DFF
add mapped point x1[6]/q x1_reg[6]/Q -type DFF DFF
add mapped point x1[4]/q x1_reg[4]/Q -type DFF DFF
add mapped point x1[3]/q x1_reg[3]/Q -type DFF DFF
add mapped point x1[7]/q x1_reg[7]/Q -type DFF DFF
add mapped point x1[1]/q x1_reg[1]/Q -type DFF DFF
add mapped point x1[0]/q x1_reg[0]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
