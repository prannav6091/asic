# Virtual clock
create_clock -name VCLK -period 10.0

# External input arrival time
set_input_delay 2.0 -clock VCLK [all_inputs]

# External output required time
set_output_delay 2.0 -clock VCLK [all_outputs]

# Input slew / transition
set_input_transition 0.2 [all_inputs]

# Output capacitive load
set_load 0.05 [all_outputs]
