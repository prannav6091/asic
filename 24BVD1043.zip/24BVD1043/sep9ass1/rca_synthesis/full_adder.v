module full_adder (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);

    wire x1;
    wire a1;
    wire a2;

    xor (x1,  a, b);
    xor (sum, x1, cin);

    and (a1, a, b);
    and (a2, x1, cin);

    or  (cout, a1, a2);

endmodule
