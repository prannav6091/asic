set TOP_MODULE "rca4"

# =========================================================
# Library
# =========================================================

set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
read_libs slow.lib

# =========================================================
# Read RTL
# =========================================================

read_hdl {full_adder.v rca4.v}

elaborate $TOP_MODULE

# =========================================================
# Timing constraints
# =========================================================

read_sdc rca4.sdc

# =========================================================
# Synthesis effort
# =========================================================

set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium


# =========================================================
# 1. GENERIC SYNTHESIS
# =========================================================

syn_generic

write_hdl > output/netlist/rca4_generic.v

report_timing > output/reports/rca4_generic_timing.rpt
report_area   > output/reports/rca4_generic_area.rpt
report_power  > output/reports/rca4_generic_power.rpt
report_qor    > output/reports/rca4_generic_qor.rpt


# =========================================================
# 2. MAPPED SYNTHESIS
# =========================================================

syn_map

write_hdl > output/netlist/rca4_mapped.v

report_timing > output/reports/rca4_mapped_timing.rpt
report_area   > output/reports/rca4_mapped_area.rpt
report_power  > output/reports/rca4_mapped_power.rpt
report_qor    > output/reports/rca4_mapped_qor.rpt


# =========================================================
# 3. OPTIMIZED SYNTHESIS
# =========================================================

syn_opt

write_hdl > output/netlist/rca4_optimized.v
write_sdc > output/rca4_synth.sdc

report_timing > output/reports/rca4_optimized_timing.rpt
report_area   > output/reports/rca4_optimized_area.rpt
report_power  > output/reports/rca4_optimized_power.rpt
report_qor    > output/reports/rca4_optimized_qor.rpt

report_gates > output/reports/rca4_gates.rpt

gui_show
