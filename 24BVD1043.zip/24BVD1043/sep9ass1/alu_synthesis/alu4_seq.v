module alu4_seq (
    input  wire       clk,
    input  wire       rst,
    input  wire [3:0] a,
    input  wire [3:0] b,
    input  wire [1:0] op,
    output reg  [3:0] y
);

    reg [3:0] alu_result;

    // Combinational ALU
    always @(*) begin
        case (op)
            2'b00: alu_result = a + b;
            2'b01: alu_result = a - b;
            2'b10: alu_result = a & b;
            2'b11: alu_result = a | b;
            default: alu_result = 4'b0000;
        endcase
    end

    // Sequential output register
    always @(posedge clk) begin
        if (rst)
            y <= 4'b0000;
        else
            y <= alu_result;
    end

endmodule
