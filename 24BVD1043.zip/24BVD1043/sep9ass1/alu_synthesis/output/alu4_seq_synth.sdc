# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.14-s082_1 on Mon Sep 07 11:57:13 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design alu4_seq

create_clock -name "CLK" -period 10.0 -waveform {0.0 5.0} [get_ports clk]
set_load -pin_load 0.05 [get_ports {y[3]}]
set_load -pin_load 0.05 [get_ports {y[2]}]
set_load -pin_load 0.05 [get_ports {y[1]}]
set_load -pin_load 0.05 [get_ports {y[0]}]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {a[3]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {a[2]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {a[1]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {a[0]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {b[3]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {b[2]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {b[1]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {b[0]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {op[1]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {op[0]}]
set_input_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports rst]
set_output_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {y[3]}]
set_output_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {y[2]}]
set_output_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {y[1]}]
set_output_delay -clock [get_clocks CLK] -add_delay 2.0 [get_ports {y[0]}]
set_input_transition 0.2 [get_ports clk]
set_input_transition 0.2 [get_ports rst]
set_input_transition 0.2 [get_ports {a[3]}]
set_input_transition 0.2 [get_ports {a[2]}]
set_input_transition 0.2 [get_ports {a[1]}]
set_input_transition 0.2 [get_ports {a[0]}]
set_input_transition 0.2 [get_ports {b[3]}]
set_input_transition 0.2 [get_ports {b[2]}]
set_input_transition 0.2 [get_ports {b[1]}]
set_input_transition 0.2 [get_ports {b[0]}]
set_input_transition 0.2 [get_ports {op[1]}]
set_input_transition 0.2 [get_ports {op[0]}]
set_wire_load_mode "enclosed"
