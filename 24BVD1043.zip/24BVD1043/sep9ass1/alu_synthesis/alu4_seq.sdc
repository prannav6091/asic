# Real clock on the ALU clock input
create_clock -name CLK -period 10.0 [get_ports clk]

# Input delays for data/control inputs
set_input_delay 2.0 -clock CLK [get_ports {a[*] b[*] op[*] rst}]

# Output delay
set_output_delay 2.0 -clock CLK [get_ports {y[*]}]

# Input transition
set_input_transition 0.2 [get_ports {a[*] b[*] op[*] rst clk}]

# Output load
set_load 0.05 [get_ports {y[*]}]
