set TOP_MODULE "alu4_seq"

# =========================================================
# 90 nm slow-corner library
# =========================================================

set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
read_libs slow.lib

# =========================================================
# Read and elaborate RTL
# =========================================================

read_hdl alu4_seq.v
elaborate $TOP_MODULE

# =========================================================
# Read timing/design constraints
# =========================================================

read_sdc alu4_seq.sdc

# =========================================================
# Synthesis effort
# =========================================================

set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium


# =========================================================
# 1. GENERIC SYNTHESIS
# =========================================================

syn_generic

write_hdl > output/netlist/alu4_seq_generic.v

report_timing > output/reports/alu4_seq_generic_timing.rpt
report_area   > output/reports/alu4_seq_generic_area.rpt
report_power  > output/reports/alu4_seq_generic_power.rpt
report_qor    > output/reports/alu4_seq_generic_qor.rpt


# =========================================================
# 2. MAPPED SYNTHESIS
# =========================================================

syn_map

write_hdl > output/netlist/alu4_seq_mapped.v

report_timing > output/reports/alu4_seq_mapped_timing.rpt
report_area   > output/reports/alu4_seq_mapped_area.rpt
report_power  > output/reports/alu4_seq_mapped_power.rpt
report_qor    > output/reports/alu4_seq_mapped_qor.rpt


# =========================================================
# 3. OPTIMIZED SYNTHESIS
# =========================================================

syn_opt

write_hdl > output/netlist/alu4_seq_optimized.v
write_sdc > output/alu4_seq_synth.sdc

report_timing > output/reports/alu4_seq_optimized_timing.rpt
report_area   > output/reports/alu4_seq_optimized_area.rpt
report_power  > output/reports/alu4_seq_optimized_power.rpt
report_qor    > output/reports/alu4_seq_optimized_qor.rpt

report_gates > output/reports/alu4_seq_gates.rpt

gui_show
