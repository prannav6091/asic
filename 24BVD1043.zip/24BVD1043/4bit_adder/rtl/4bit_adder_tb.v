module adder_4bit_tb;
    reg [3:0] A;
    reg [3:0] B;
    reg       Cin;
    wire [3:0] Sum;
    wire       Cout;

    adder_4bit uut (
        .A(A), 
        .B(B), 
        .Cin(Cin), 
        .Sum(Sum), 
        .Cout(Cout)
    );

    initial begin
        $display("   Time   |  A  |  B  | Cin | Sum | Cout ");
        $monitor("   %40t | %2d  | %2d  |  %1b  | %3d |   %1b", $time, A, B, Cin, Sum, Cout);

        A = 4'd5;  B = 4'd3;  Cin = 1'b0; #10;
        A = 4'd5;  B = 4'd3;  Cin = 1'b1; #10;
        A = 4'd12; B = 4'd6;  Cin = 1'b0; #10;
        A = 4'd15; B = 4'd15; Cin = 1'b1; #10;
        A = 4'd0;  B = 4'd0;  Cin = 1'b0; #10;
        $finish;
    end

endmodule
