module tb_adder_4bit;
    reg [3:0] A;
    reg [3:0] B;
    reg       Cin;
    wire [3:0] Sum;
    wire       Cout;

    adder_4bit uut (
        .A(A), 
        .B(B), 
        .Cin(Cin), 
        .Sum(Sum), 
        .Cout(Cout)
    );

    initial begin
        $display("-------------------------------------------");
        $display("   Time   |  A  |  B  | Cin | Sum | Cout ");
        $display("-------------------------------------------");
        $monitor("   %40t | %2d  | %2d  |  %1b  | %3d |   %1b", $time, A, B, Cin, Sum, Cout);

        // Test Case 1: Simple addition without carry
        A = 4'd5;  B = 4'd3;  Cin = 1'b0; #10; // 5 + 3 + 0 = 8 (Sum=8, Cout=0)
        
        // Test Case 2: Same inputs, but turn on Carry-in
        A = 4'd5;  B = 4'd3;  Cin = 1'b1; #10; // 5 + 3 + 1 = 9 (Sum=9, Cout=0)
        
        // Test Case 3: Forcing a Carry-out (result > 15)
        A = 4'd12; B = 4'd6;  Cin = 1'b0; #10; // 12 + 6 = 18 (18 - 16 = 2. Sum=2, Cout=1)
        
        // Test Case 4: Maximum possible value
        A = 4'd15; B = 4'd15; Cin = 1'b1; #10; // 15 + 15 + 1 = 31 (Sum=15, Cout=1)
        
        // Test Case 5: Zero check
        A = 4'd0;  B = 4'd0;  Cin = 1'b0; #10; // 0 + 0 + 0 = 0 (Sum=0, Cout=0)

        $display("-------------------------------------------");
        $finish;
    end

endmodule
