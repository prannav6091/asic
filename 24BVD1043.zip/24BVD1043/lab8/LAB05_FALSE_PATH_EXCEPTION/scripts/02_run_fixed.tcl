# ============================================================
# LAB05: Correct False-Path Timing Exception - FIX
# Tempus STA Debug Script
#
# Run:
#   tempus -files scripts/02_run_fixed.tcl
#
# Purpose:
#   1. Check input files and load the design.
#   2. Verify instance and pin names.
#   3. Confirm the false-path constraint is loaded.
#   4. Report setup and hold paths.
#   5. Handle the intentionally false-pathed CFG path safely.
#   6. Save reports without using nonexistent endpoints.
# ============================================================

set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR    [file normalize [file join $SCRIPT_DIR ..]]

set LIB        [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST    [file join $LAB_DIR netlist 02_fixed.v]
set SDC        [file join $LAB_DIR sdc 02_fixed.sdc]
set REPORT_DIR [file join $LAB_DIR reports]

set SETUP_REPORT [file join $REPORT_DIR 02_run_fixed_setup.rpt]
set HOLD_REPORT  [file join $REPORT_DIR 02_run_fixed_hold.rpt]
set CFG_REPORT   [file join $REPORT_DIR 02_run_fixed_cfg.rpt]

# ------------------------------------------------------------
# 1. Verify input files and create report directory
# ------------------------------------------------------------

puts "\n========== INPUT FILE CHECK =========="

file mkdir $REPORT_DIR

foreach f [list $LIB $NETLIST $SDC] {
    if {[file exists $f]} {
        puts "FOUND: $f"
    } else {
        puts "MISSING: $f"
        error "Required input file not found: $f"
    }
}

# ------------------------------------------------------------
# 2. Load the design
# ------------------------------------------------------------

puts "\n========== LOADING DESIGN =========="

if {[catch {read_lib $LIB} err]} {
    puts "ERROR reading Liberty library: $err"
    error "Library loading failed"
}

if {[catch {read_verilog $NETLIST} err]} {
    puts "ERROR reading Verilog netlist: $err"
    error "Netlist loading failed"
}

if {[catch {set_top_module false_path_top} err]} {
    puts "ERROR setting top module: $err"
    error "Top-module selection failed"
}

if {[catch {read_sdc $SDC} err]} {
    puts "ERROR reading SDC: $err"
    error "SDC loading failed"
}

puts "Library, netlist and SDC commands completed."

# ------------------------------------------------------------
# 3. Check instances and pins
# ------------------------------------------------------------

puts "\n========== INSTANCE AND PIN DEBUG =========="

foreach inst {
    U_DATA_L
    U_DATA_C
    U_CFG_L
    U_CFG_C
    U_LAUNCH
    U_CAPTURE
} {
    set cells [get_cells -quiet $inst]

    if {[sizeof_collection $cells] > 0} {
        puts "FOUND instance: $inst"
        puts "  Pins: [get_object_name \
            [get_pins -quiet -of_objects $cells]]"
    } else {
        puts "MISSING instance: $inst"
    }
}

puts "\n--- Endpoint validation ---"

foreach pin {
    U_DATA_L/CLK
    U_DATA_C/D
    U_CFG_L/CLK
    U_CFG_C/D
    U_LAUNCH/CLK
    U_CAPTURE/D
} {
    set pins [get_pins -quiet $pin]

    if {[sizeof_collection $pins] > 0} {
        puts "FOUND pin: $pin"
    } else {
        puts "MISSING pin: $pin"
    }
}

# ------------------------------------------------------------
# 4. Print expected hand calculations
# ------------------------------------------------------------

puts ""
puts "=================================================================="
puts "LAB05 FALSE-PATH EXCEPTION - AFTER JUSTIFIED EXCEPTION"
puts "=================================================================="
puts "Clock         : CLK period 5.00 ns, ideal"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns"
puts "Setup required: 5.00 - 0.20 = 4.80 ns"
puts "Hold required : 0.00 + 0.10 = 0.10 ns"
puts ""
puts "DATA path     : U_DATA_L -> 6 x BUF_X1 -> U_DATA_C/D"
puts "  Arrival     : 0.20 + 6 x 0.50 = 3.20 ns"
puts "  Setup slack : +1.60 ns"
puts "  Hold slack  : +3.10 ns"
puts ""
puts "CFG path      : U_CFG_L -> 12 x BUF_X1 -> U_CFG_C/D"
puts "  If timed    : setup -1.40 ns; hold +6.10 ns"
puts ""
puts "Expected SDC  : set_false_path -from [get_cells U_CFG_L]"
puts "                -to [get_pins U_CFG_C/D]"
puts "Result        : CFG excluded from constrained setup/hold analysis."
puts "                Physical delay remains unchanged."
puts "=================================================================="

# ------------------------------------------------------------
# 5. Check whether expected pins exist
# ------------------------------------------------------------

set DATA_START [get_pins -quiet U_DATA_L/CLK]
set DATA_END   [get_pins -quiet U_DATA_C/D]
set CFG_START  [get_pins -quiet U_CFG_L/CLK]
set CFG_END    [get_pins -quiet U_CFG_C/D]

if {
    [sizeof_collection $DATA_START] == 0 ||
    [sizeof_collection $DATA_END] == 0
} {
    puts "WARNING: DATA endpoints are missing; DATA reports may be skipped."
}

if {
    [sizeof_collection $CFG_START] == 0 ||
    [sizeof_collection $CFG_END] == 0
} {
    puts "WARNING: CFG endpoints are missing; CFG report will be skipped."
}

# ------------------------------------------------------------
# 6. Report all constrained setup paths
# ------------------------------------------------------------

puts "\n========== WORST SETUP PATHS (LATE) =========="

if {[catch {
    redirect -file $SETUP_REPORT {
        report_timing -late -path_type full_clock -max_paths 5
    }
} err]} {
    puts "ERROR generating setup report: $err"
} else {
    puts "Setup report saved: $SETUP_REPORT"
}

# ------------------------------------------------------------
# 7. Report all constrained hold paths
# ------------------------------------------------------------

puts "\n========== WORST HOLD PATHS (EARLY) =========="

if {[catch {
    redirect -file $HOLD_REPORT {
        report_timing -early -path_type full_clock -max_paths 5
    }
} err]} {
    puts "ERROR generating hold report: $err"
} else {
    puts "Hold report saved: $HOLD_REPORT"
}

# ------------------------------------------------------------
# 8. Examine the CFG path after the exception
# ------------------------------------------------------------

puts "\n========== CFG PATH AFTER FALSE-PATH EXCEPTION =========="

if {
    [sizeof_collection $CFG_START] > 0 &&
    [sizeof_collection $CFG_END] > 0
} {
    if {[catch {
        redirect -file $CFG_REPORT {
            report_timing \
                -late \
                -path_type full_clock \
                -from $CFG_START \
                -to $CFG_END \
                -max_paths 1
        }
    } err]} {
        puts "CFG timing report returned an error:"
        puts $err
        puts "This can occur when no constrained path matches the query."
    } else {
        puts "CFG report saved: $CFG_REPORT"
        puts "Inspect the report to confirm that no constrained path exists."
    }
} else {
    puts "CFG report skipped because one or both endpoint pins are missing."
}

# ------------------------------------------------------------
# 9. Final debug summary
# ------------------------------------------------------------

puts "\n========== DEBUG SUMMARY =========="
puts "Setup report: $SETUP_REPORT"
puts "Hold report : $HOLD_REPORT"
puts "CFG report  : $CFG_REPORT"
puts ""
puts "IMPORTANT:"
puts "1. Verify that 02_fixed.sdc contains the intended false-path exception."
puts "2. Confirm the exception matches the CFG path's actual launch/capture pins."
puts "3. Check the reports; do not assume a missing path proves the exception."
puts "4. Liberty TECHLIB errors must be debugged separately."
puts "==================================="

exit
