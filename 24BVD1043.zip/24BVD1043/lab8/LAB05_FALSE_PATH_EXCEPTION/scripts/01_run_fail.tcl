# ============================================================
# LAB05: Correct False-Path Timing Exception - FAIL
# Tempus STA Debug Script
#
# Run:
#   tempus -files scripts/01_run_fail.tcl
#
# Purpose:
#   1. Verify library, netlist, and SDC loading.
#   2. Debug missing instance/pin references.
#   3. Report DATA and CFG setup/hold timing.
#   4. Save timing reports for debugging.
# ============================================================

set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR    [file normalize [file join $SCRIPT_DIR ..]]

set LIB       [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST   [file join $LAB_DIR netlist 01_fail.v]
set SDC       [file join $LAB_DIR sdc 01_fail.sdc]
set REPORT_DIR [file join $LAB_DIR reports]
set REPORT_FILE [file join $REPORT_DIR 01_run_fail.rpt]

# ------------------------------------------------------------
# 1. Check input files
# ------------------------------------------------------------

file mkdir $REPORT_DIR

puts "\n========== INPUT FILE CHECK =========="

foreach f [list $LIB $NETLIST $SDC] {
    if {[file exists $f]} {
        puts "FOUND : $f"
    } else {
        puts "MISSING: $f"
        error "Required input file not found: $f"
    }
}

# ------------------------------------------------------------
# 2. Load library, netlist and constraints
# ------------------------------------------------------------

puts "\n========== LOADING DESIGN =========="

if {[catch {read_lib $LIB} err]} {
    puts "ERROR reading Liberty library: $err"
    error "Library loading failed"
}

if {[catch {read_verilog $NETLIST} err]} {
    puts "ERROR reading Verilog netlist: $err"
    error "Netlist loading failed"
}

if {[catch {set_top_module false_path_top} err]} {
    puts "ERROR setting top module: $err"
    error "Top-module selection failed"
}

if {[catch {read_sdc $SDC} err]} {
    puts "ERROR reading SDC: $err"
    error "SDC loading failed"
}

puts "Library, netlist and SDC commands completed."

# ------------------------------------------------------------
# 3. Debug design hierarchy and pin names
# ------------------------------------------------------------

puts "\n========== DESIGN OBJECT DEBUG =========="

puts "\nTop module: false_path_top"

puts "\n--- Available instances matching expected names ---"

foreach inst {
    U_DATA_L
    U_DATA_C
    U_CFG_L
    U_CFG_C
    U_LAUNCH
    U_CAPTURE
} {
    set cells [get_cells -quiet $inst]

    if {[sizeof_collection $cells] > 0} {
        puts "FOUND instance: $inst"
        puts "  Pins:"
        puts "  [get_object_name [get_pins -quiet -of_objects $cells]]"
    } else {
        puts "MISSING instance: $inst"
    }
}

puts "\n--- Verify expected timing endpoints ---"

foreach pin {
    U_DATA_L/CLK
    U_DATA_C/D
    U_CFG_L/CLK
    U_CFG_C/D
    U_LAUNCH/CLK
    U_CAPTURE/D
} {
    set pins [get_pins -quiet $pin]

    if {[sizeof_collection $pins] > 0} {
        puts "FOUND pin: $pin"
    } else {
        puts "MISSING pin: $pin"
    }
}

# ------------------------------------------------------------
# 4. Print expected hand calculations
# ------------------------------------------------------------

puts "\n"
puts "=================================================================="
puts "LAB05 FALSE-PATH EXCEPTION - BEFORE EXCEPTION"
puts "=================================================================="
puts "Clock         : CLK period 5.00 ns, ideal"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns"
puts "Setup required: 5.00 - 0.20 = 4.80 ns"
puts "Hold required : 0.00 + 0.10 = 0.10 ns"
puts ""
puts "DATA path     : U_DATA_L -> 6 x BUF_X1 -> U_DATA_C/D"
puts "  Arrival     : 0.20 + 6 x 0.50 = 3.20 ns"
puts "  Setup slack : 4.80 - 3.20 = +1.60 ns"
puts "  Hold slack  : 3.20 - 0.10 = +3.10 ns"
puts ""
puts "CFG path      : U_CFG_L -> 12 x BUF_X1 -> U_CFG_C/D"
puts "  Arrival     : 0.20 + 12 x 0.50 = 6.20 ns"
puts "  Setup slack : 4.80 - 6.20 = -1.40 ns"
puts "  Hold slack  : 6.20 - 0.10 = +6.10 ns"
puts ""
puts "Expected CFG setup result: VIOLATED"
puts "Do not hide a failing path by declaring it false."
puts "=================================================================="

# ------------------------------------------------------------
# 5. Safe timing report procedure
# ------------------------------------------------------------

proc safe_timing_report {label delay_type start_pin end_pin} {

    puts "\n----- $label -----"

    set start_obj [get_pins -quiet $start_pin]
    set end_obj   [get_pins -quiet $end_pin]

    if {[sizeof_collection $start_obj] == 0} {
        puts "SKIPPED: Start pin does not exist: $start_pin"
        return
    }

    if {[sizeof_collection $end_obj] == 0} {
        puts "SKIPPED: End pin does not exist: $end_pin"
        return
    }

    if {[catch {
        report_timing \
            $delay_type \
            -path_type full_clock \
            -from $start_obj \
            -to $end_obj \
            -max_paths 1
    } err]} {
        puts "TIMING REPORT ERROR: $err"
    }
}

# ------------------------------------------------------------
# 6. Run timing reports
# ------------------------------------------------------------

puts "\n========== ACTUAL TEMPUS TIMING REPORTS =========="

safe_timing_report \
    "DATA SETUP (late)" \
    -late \
    U_DATA_L/CLK \
    U_DATA_C/D

safe_timing_report \
    "DATA HOLD (early)" \
    -early \
    U_DATA_L/CLK \
    U_DATA_C/D

safe_timing_report \
    "CFG SETUP (late)" \
    -late \
    U_CFG_L/CLK \
    U_CFG_C/D

safe_timing_report \
    "CFG HOLD (early)" \
    -early \
    U_CFG_L/CLK \
    U_CFG_C/D

# ------------------------------------------------------------
# 7. Save a timing report using valid known endpoints
# ------------------------------------------------------------

puts "\n========== SAVING SUMMARY REPORT =========="

set report_start [get_pins -quiet U_CFG_L/CLK]
set report_end   [get_pins -quiet U_CFG_C/D]

if {
    [sizeof_collection $report_start] > 0 &&
    [sizeof_collection $report_end] > 0
} {
    if {[catch {
        redirect -file $REPORT_FILE {
            report_timing \
                -late \
                -path_type full_clock \
                -from [get_pins U_CFG_L/CLK] \
                -to [get_pins U_CFG_C/D] \
                -max_paths 1
        }
    } err]} {
        puts "ERROR saving timing report: $err"
    } else {
        puts "Timing report saved to: $REPORT_FILE"
    }
} else {
    puts "Report not saved: CFG timing endpoints are missing."
    puts "Check the instance and pin names in the netlist."
}

puts "\n========== DEBUG RUN COMPLETE =========="
exit
