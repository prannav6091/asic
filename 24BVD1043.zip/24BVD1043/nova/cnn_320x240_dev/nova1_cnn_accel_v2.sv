
module nova1_cnn_accel_v2 #(
    parameter integer DATA_WIDTH = 8,
    parameter integer LANES      = 16,
    parameter integer ACC_WIDTH  = 32,
    parameter integer ADDR_WIDTH = 4
) (
    input  logic clk,
    input  logic rst_n,

    // Configuration interface
    input  logic cfg_wr_en,
    input  logic cfg_wr_sel,
    input  logic [ADDR_WIDTH-1:0] cfg_wr_addr,
    input  logic signed [DATA_WIDTH-1:0] cfg_wr_data,

    // CNN computation controls
    input  logic signed [ACC_WIDTH-1:0] bias,
    input  logic [4:0] shift_amount,
    input  logic start,

    // Status and output
    output logic busy,
    output logic done,
    output logic signed [DATA_WIDTH-1:0] result
);

    // Main datapath and controller hierarchy
    cnn_datapath_v2 #(
        .DATA_WIDTH(DATA_WIDTH),
        .LANES(LANES),
        .ACC_WIDTH(ACC_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH)
    ) u_cnn_datapath (
        .clk(clk),
        .rst_n(rst_n),

        .cfg_wr_en(cfg_wr_en),
        .cfg_wr_sel(cfg_wr_sel),
        .cfg_wr_addr(cfg_wr_addr),
        .cfg_wr_data(cfg_wr_data),

        .bias(bias),
        .shift_amount(shift_amount),
        .start(start),

        .busy(busy),
        .done(done),
        .result(result)
    );

endmodule

