
module cnn_controller_v2 (
    input  logic clk,
    input  logic rst_n,
    input  logic start,

    output logic busy,
    output logic done,
    output logic capture_accum,
    output logic capture_result
);

    typedef enum logic [2:0] {
        IDLE,
        ACCUMULATE,
        POSTPROCESS,
        COMPLETE
    } state_t;

    state_t state, next_state;

    // State register
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            state <= IDLE;
        else
            state <= next_state;
    end

    // Next-state logic
    always_comb begin
        next_state = state;

        case (state)
            IDLE: begin
                if (start)
                    next_state = ACCUMULATE;
            end

            ACCUMULATE: begin
                next_state = POSTPROCESS;
            end

            POSTPROCESS: begin
                next_state = COMPLETE;
            end

            COMPLETE: begin
                next_state = IDLE;
            end

            default: begin
                next_state = IDLE;
            end
        endcase
    end

    // Control signals
    always_comb begin
        busy           = 1'b0;
        done           = 1'b0;
        capture_accum  = 1'b0;
        capture_result = 1'b0;

        case (state)
            IDLE: begin
                busy = 1'b0;
            end

            ACCUMULATE: begin
                busy          = 1'b1;
                capture_accum = 1'b1;
            end

            POSTPROCESS: begin
                busy           = 1'b1;
                capture_result = 1'b1;
            end

            COMPLETE: begin
                done = 1'b1;
            end

            default: begin
                busy = 1'b0;
            end
        endcase
    end

endmodule

