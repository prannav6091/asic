
module accumulator_v2 #(
    parameter integer ACC_WIDTH = 32
) (
    input  logic                     clk,
    input  logic                     rst_n,
    input  logic                     capture,

    input  logic signed [ACC_WIDTH-1:0] mac_sum,
    input  logic signed [ACC_WIDTH-1:0] bias,

    output logic signed [ACC_WIDTH-1:0] accum_out
);

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            accum_out <= '0;
        end
        else if (capture) begin
            accum_out <= mac_sum + bias;
        end
    end

endmodule

