
module cnn_datapath_v2 #(
    parameter integer DATA_WIDTH = 8,
    parameter integer LANES      = 16,
    parameter integer ACC_WIDTH  = 32,
    parameter integer ADDR_WIDTH = 4
) (
    input  logic clk,
    input  logic rst_n,

    input  logic cfg_wr_en,
    input  logic cfg_wr_sel,
    input  logic [ADDR_WIDTH-1:0] cfg_wr_addr,
    input  logic signed [DATA_WIDTH-1:0] cfg_wr_data,

    input  logic signed [ACC_WIDTH-1:0] bias,
    input  logic [4:0] shift_amount,
    input  logic start,

    output logic busy,
    output logic done,
    output logic signed [DATA_WIDTH-1:0] result
);

    logic [LANES*DATA_WIDTH-1:0] activations;
    logic [LANES*DATA_WIDTH-1:0] weights;

    logic signed [ACC_WIDTH-1:0] mac_sum;
    logic signed [ACC_WIDTH-1:0] accum_out;

    logic capture_accum;
    logic capture_result;
    logic postprocess_valid;

    logic input_wr_en;
    logic weight_wr_en;

    // Configuration writes are allowed only while idle
    assign input_wr_en  = cfg_wr_en && !cfg_wr_sel && !busy;
    assign weight_wr_en = cfg_wr_en &&  cfg_wr_sel && !busy;

    // Input activation buffer
    input_buffer_v2 #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(LANES),
        .ADDR_WIDTH(ADDR_WIDTH)
    ) u_input_buffer (
        .clk(clk),
        .rst_n(rst_n),
        .wr_en(input_wr_en),
        .wr_addr(cfg_wr_addr),
        .wr_data(cfg_wr_data),
        .packed_data(activations)
    );

    // Weight buffer
    weight_buffer_v2 #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(LANES),
        .ADDR_WIDTH(ADDR_WIDTH)
    ) u_weight_buffer (
        .clk(clk),
        .rst_n(rst_n),
        .wr_en(weight_wr_en),
        .wr_addr(cfg_wr_addr),
        .wr_data(cfg_wr_data),
        .packed_data(weights)
    );

    // Sixteen-lane dot-product MAC array
    mac_array_v2 #(
        .DATA_WIDTH(DATA_WIDTH),
        .LANES(LANES),
        .ACC_WIDTH(ACC_WIDTH)
    ) u_mac_array (
        .activations(activations),
        .weights(weights),
        .mac_sum(mac_sum)
    );

    // Add bias and register the sum
    accumulator_v2 #(
        .ACC_WIDTH(ACC_WIDTH)
    ) u_accumulator (
        .clk(clk),
        .rst_n(rst_n),
        .capture(capture_accum),
        .mac_sum(mac_sum),
        .bias(bias),
        .accum_out(accum_out)
    );

    // Fixed-point scaling, saturation, and ReLU
    postprocess_v2 #(
        .ACC_WIDTH(ACC_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) u_postprocess (
        .clk(clk),
        .rst_n(rst_n),
        .valid_in(capture_result),
        .accum_in(accum_out),
        .shift_amount(shift_amount),
        .result(result),
        .valid_out(postprocess_valid)
    );

    // Operation controller
    cnn_controller_v2 u_controller (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .busy(busy),
        .done(done),
        .capture_accum(capture_accum),
        .capture_result(capture_result)
    );

endmodule

