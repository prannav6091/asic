
module mac_array_v2 #(
    parameter integer DATA_WIDTH = 8,
    parameter integer LANES      = 16,
    parameter integer ACC_WIDTH  = 32
) (
    input  logic [LANES*DATA_WIDTH-1:0] activations,
    input  logic [LANES*DATA_WIDTH-1:0] weights,

    output logic signed [ACC_WIDTH-1:0] mac_sum
);

    logic signed [DATA_WIDTH-1:0] activation [0:LANES-1];
    logic signed [DATA_WIDTH-1:0] weight     [0:LANES-1];
    logic signed [(2*DATA_WIDTH)-1:0] product [0:LANES-1];

    integer i;

    // Unpack activations, weights, and calculate products
    always_comb begin
        for (integer j = 0; j < LANES; j = j + 1) begin
            activation[j] =
                $signed(activations[j*DATA_WIDTH +: DATA_WIDTH]);

            weight[j] =
                $signed(weights[j*DATA_WIDTH +: DATA_WIDTH]);

            product[j] = activation[j] * weight[j];
        end
    end

    // Sum all products with explicit sign extension
    always_comb begin
        mac_sum = '0;

        for (integer k = 0; k < LANES; k = k + 1) begin
            mac_sum = mac_sum + 
                {{(ACC_WIDTH-(2*DATA_WIDTH)){product[k][(2*DATA_WIDTH)-1]}},
                  product[k]};
        end
    end

endmodule

