
module weight_buffer_v2 #(
    parameter integer DATA_WIDTH = 8,
    parameter integer DEPTH      = 16,
    parameter integer ADDR_WIDTH = 4
) (
    input  logic                         clk,
    input  logic                         rst_n,

    input  logic                         wr_en,
    input  logic [ADDR_WIDTH-1:0]        wr_addr,
    input  logic signed [DATA_WIDTH-1:0] wr_data,

    output logic [DEPTH*DATA_WIDTH-1:0]  packed_data
);

    logic signed [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    integer i;

    // Asynchronous active-low reset and synchronous writes
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (i = 0; i < DEPTH; i = i + 1)
                mem[i] <= '0;
        end
        else if (wr_en && (wr_addr < DEPTH)) begin
            mem[wr_addr] <= wr_data;
        end
    end

    // Present all stored weights to the MAC array
    always_comb begin
        packed_data = '0;

        for (integer j = 0; j < DEPTH; j = j + 1) begin
            packed_data[j*DATA_WIDTH +: DATA_WIDTH] = mem[j];
        end
    end

endmodule

