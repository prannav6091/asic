
module postprocess_v2 #(
    parameter integer ACC_WIDTH  = 32,
    parameter integer DATA_WIDTH = 8
) (
    input  logic                     clk,
    input  logic                     rst_n,
    input  logic                     valid_in,

    input  logic signed [ACC_WIDTH-1:0] accum_in,
    input  logic        [4:0]           shift_amount,

    output logic signed [DATA_WIDTH-1:0] result,
    output logic                         valid_out
);

    localparam logic signed [ACC_WIDTH-1:0] MAX_INT8 = 127;
    localparam logic signed [ACC_WIDTH-1:0] MIN_INT8 = -128;

    logic signed [ACC_WIDTH-1:0] shifted_value;
    logic signed [DATA_WIDTH-1:0] quantized_value;

    // Scale, saturate, and apply ReLU
    always_comb begin
        shifted_value  = accum_in >>> shift_amount;
        quantized_value = '0;

        if (shifted_value > MAX_INT8) begin
            quantized_value = 8'sd127;
        end
        else if (shifted_value < MIN_INT8) begin
            quantized_value = -8'sd128;
        end
        else begin
            quantized_value = shifted_value[DATA_WIDTH-1:0];
        end

        // ReLU: negative activations become zero
        if (quantized_value < 0) begin
            quantized_value = '0;
        end
    end

    // Register output and its validity indication
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            result    <= '0;
            valid_out <= 1'b0;
        end
        else begin
            valid_out <= valid_in;

            if (valid_in) begin
                result <= quantized_value;
            end
        end
    end

endmodule
