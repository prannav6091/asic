
`timescale 1ns/1ps

module nova_image_buffer #(
    parameter int unsigned DEPTH          = 76800,
    parameter int unsigned PIX_ADDR_WIDTH = (DEPTH <= 1) ? 1 : $clog2(DEPTH),
    parameter int unsigned HOST_ADDR_WIDTH = PIX_ADDR_WIDTH + 2
) (
    input  logic                       clk,
    input  logic                       rst_n,

    // Host write request.
    // Address is a byte offset relative to the image window.
    // A request is accepted at each rising edge when host_valid=1.
    // Response is returned one cycle later.
    input  logic                       host_valid,
    output logic                       host_ready,
    input  logic                       host_write,
    input  logic [HOST_ADDR_WIDTH-1:0]  host_addr,
    input  logic [31:0]                host_wdata,
    input  logic [3:0]                 host_wstrb,
    output logic                       host_resp_valid,
    output logic                       host_resp_error,

    // CNN pixel read request.
    // Read response, including an invalid-address indication,
    // is returned one cycle after pix_req is sampled.
    input  logic                       pix_req,
    input  logic [PIX_ADDR_WIDTH-1:0]   pix_addr,
    output logic                       pix_valid,
    output logic [7:0]                 pix_data,
    output logic                       pix_error,

    // Control from the surrounding subsystem.
    input  logic                       inference_active,
    input  logic                       frame_commit,
    output logic                       frame_loaded
);

    localparam int unsigned WORD_DEPTH = DEPTH / 4;

    // This initial implementation packs four pixels per host word.
    // DEPTH must be a positive multiple of four.
    initial begin
        if (DEPTH == 0 || (DEPTH % 4) != 0)
            $error("DEPTH must be nonzero and divisible by 4");
        if (HOST_ADDR_WIDTH < 3)
            $error("HOST_ADDR_WIDTH is too small");
    end

    // Memory is intentionally not reset.
    // The implementation can be mapped to a suitable memory macro
    // or inferred memory by the target synthesis flow.
    logic [7:0] pixel_mem [0:DEPTH-1];

    assign host_ready = 1'b1;

    wire host_addr_aligned = (host_addr[1:0] == 2'b00);
    wire host_addr_in_range =
        (host_addr[HOST_ADDR_WIDTH-1:2] < WORD_DEPTH);

    wire host_write_accept =
        host_valid &&
        host_write &&
        host_addr_aligned &&
        host_addr_in_range &&
        (|host_wstrb) &&
        !inference_active &&
        !pix_req;

    integer lane;
    integer word_idx;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            host_resp_valid <= 1'b0;
            host_resp_error <= 1'b0;

            pix_valid       <= 1'b0;
            pix_error       <= 1'b0;
            pix_data        <= 8'h00;

            frame_loaded    <= 1'b0;
        end else begin
            // Default: response/valid indications are pulses.
            host_resp_valid <= 1'b0;
            host_resp_error <= 1'b0;

            pix_valid       <= 1'b0;
            pix_error       <= 1'b0;

            // Host request: fixed one-cycle response.
            if (host_valid) begin
                host_resp_valid <= 1'b1;

                if (!host_write ||
                    !host_addr_aligned ||
                    !host_addr_in_range ||
                    !(|host_wstrb) ||
                    inference_active ||
                    pix_req) begin

                    host_resp_error <= 1'b1;

                end else begin
                    word_idx = host_addr[HOST_ADDR_WIDTH-1:2];

                    // Little-endian lane mapping:
                    // lane 0 -> lowest-addressed pixel.
                    for (lane = 0; lane < 4; lane = lane + 1) begin
                        if (host_wstrb[lane]) begin
                            pixel_mem[(word_idx * 4) + lane]
                                <= host_wdata[(lane * 8) +: 8];
                        end
                    end
                end
            end

            // CNN pixel read: synchronous, one-cycle response.
            if (pix_req) begin
                pix_valid <= 1'b1;

                if (pix_addr < DEPTH) begin
                    pix_data <= pixel_mem[pix_addr];
                    pix_error <= 1'b0;
                end else begin
                    pix_data <= 8'h00;
                    pix_error <= 1'b1;
                end
            end

            // A successful host write invalidates the previous
            // "complete frame" indication.
            if (host_write_accept)
                frame_loaded <= 1'b0;
            else if (frame_commit && !inference_active)
                frame_loaded <= 1'b1;
        end
    end

endmodule

