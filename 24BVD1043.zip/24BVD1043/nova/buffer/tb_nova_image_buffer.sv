`timescale 1ns/1ps

module tb_nova_image_buffer;

localparam int DEPTH = 76800;
    localparam int PIX_ADDR_WIDTH = $clog2(DEPTH);
    localparam int HOST_ADDR_WIDTH = PIX_ADDR_WIDTH + 2;

logic clk = 1'b0;
    always #5 clk = ~clk;

    logic rst_n;

logic host_valid;
    logic host_ready;
    logic host_write;
    logic [HOST_ADDR_WIDTH-1:0] host_addr;
    logic [31:0] host_wdata;
    logic [3:0] host_wstrb;
    logic host_resp_valid;
    logic host_resp_error;

logic pix_req;
    logic [PIX_ADDR_WIDTH-1:0] pix_addr;
    logic pix_valid;
    logic [7:0] pix_data;
    logic pix_error;

logic inference_active;
    logic frame_commit;
    logic frame_loaded;

nova_image_buffer #(
        .DEPTH(DEPTH),
        .PIX_ADDR_WIDTH(PIX_ADDR_WIDTH),
        .HOST_ADDR_WIDTH(HOST_ADDR_WIDTH)
    ) dut (
        .clk,
        .rst_n,

.host_valid,
        .host_ready,
        .host_write,
        .host_addr,
        .host_wdata,
        .host_wstrb,
        .host_resp_valid,
        .host_resp_error,

.pix_req,
        .pix_addr,
        .pix_valid,
        .pix_data,
        .pix_error,

.inference_active,
        .frame_commit,
        .frame_loaded
    );

task automatic host_write_word(
        input logic [HOST_ADDR_WIDTH-1:0] addr,
        input logic [31:0] data,
        input logic [3:0] strb,
        input logic expected_error
    );
        begin
            @(negedge clk);
            host_valid = 1'b1;
            host_write = 1'b1;
            host_addr  = addr;
            host_wdata = data;
            host_wstrb = strb;

@(posedge clk);
            #1;

if (!host_resp_valid)
                $fatal(1, "Missing host response");

if (host_resp_error !== expected_error)
                $fatal(1, "Host error mismatch at addr %0d",
                       addr);

@(negedge clk);
            host_valid = 1'b0;
        end
    endtask

task automatic read_pixel(
        input logic [PIX_ADDR_WIDTH-1:0] addr,
        input logic [7:0] expected_data,
        input logic expected_error
    );
        begin
            @(negedge clk);
            pix_req  = 1'b1;
            pix_addr = addr;

@(posedge clk);
            #1;

if (!pix_valid)
                $fatal(1, "Missing pixel response");

if (pix_error !== expected_error)
                $fatal(1, "Pixel error mismatch at addr %0d",
                       addr);

if (pix_data !== expected_data)
                $fatal(1,
                    "Pixel mismatch addr=%0d got=%02x expected=%02x",
                    addr, pix_data, expected_data);

@(negedge clk);
            pix_req = 1'b0;
        end
    endtask

    integer w;

initial begin
        rst_n = 1'b0;

host_valid = 1'b0;
        host_write = 1'b0;
        host_addr  = '0;
        host_wdata = '0;
        host_wstrb = '0;

pix_req  = 1'b0;
        pix_addr = '0;

inference_active = 1'b0;
        frame_commit = 1'b0;

repeat (3) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;

if (frame_loaded !== 1'b0)
            $fatal(1, "frame_loaded should clear on reset");

if (!host_ready)
            $fatal(1, "Host should be ready");

// Fill every word with a recognizable byte pattern:
        // lane0=w, lane1=w+1, lane2=w+2, lane3=w+3.
        for (w = 0; w<DEPTH/4; w = w + 1) begin
            logic [31:0] data_word;

data_word[7:0]   = w;
            data_word[15:8]  = w + 1;
            data_word[23:16] = w + 2;
            data_word[31:24] = w + 3;

host_write_word(
                w * 4,
                data_word,
                4'b1111,
                1'b0
            );
        end

// Commit the completed image.
        @(negedge clk);
        frame_commit = 1'b1;

@(posedge clk);
        #1;

if (frame_loaded !== 1'b1)
            $fatal(1, "Frame commit failed");

@(negedge clk);
        frame_commit = 1'b0;

// First packed word.
        read_pixel(0, 8'h00, 1'b0);
        read_pixel(1, 8'h01, 1'b0);
        read_pixel(2, 8'h02, 1'b0);
        read_pixel(3, 8'h03, 1'b0);

// Last packed word: w=19199; lane3=(w+3) mod 256 = 2.
        read_pixel(DEPTH-4, 8'hFF, 1'b0);
        read_pixel(DEPTH-3, 8'h00, 1'b0);
        read_pixel(DEPTH-2, 8'h01, 1'b0);
        read_pixel(DEPTH-1, 8'h02, 1'b0);

// Partial write: update pixel 1 only.
        host_write_word(0, 32'h0000_AA00, 4'b0010, 1'b0);

if (frame_loaded !== 1'b0)
            $fatal(1, "Write should invalidate frame_loaded");

read_pixel(1, 8'hAA, 1'b0);
        read_pixel(0, 8'h00, 1'b0);

// Invalid host address: exactly one byte beyond the image.
        host_write_word(DEPTH, 32'h12345678, 4'b1111, 1'b1);

// Misaligned host word address.
        host_write_word(1, 32'h12345678, 4'b1111, 1'b1);

// Empty byte strobe.
        host_write_word(0, 32'h12345678, 4'b0000, 1'b1);

// CNN-side invalid pixel address.
        read_pixel(DEPTH, 8'h00, 1'b1);

// Writes during inference must be rejected.
        inference_active = 1'b1;
        host_write_word(0, 32'hDEADBEEF, 4'b1111, 1'b1);
        inference_active = 1'b0;

// Verify rejected write did not alter pixel zero.
        read_pixel(0, 8'h00, 1'b0);

// Reset during a quiescent state clears metadata.
        @(negedge clk);
        rst_n = 1'b0;

repeat (2) @(posedge clk);
        #1;

if (frame_loaded !== 1'b0)
            $fatal(1, "Reset did not clear frame_loaded");

if (host_resp_valid !== 1'b0 || pix_valid !== 1'b0)
            $fatal(1, "Reset did not clear response-valid state");

@(negedge clk);
        rst_n = 1'b1;

$display("PASS: nova_image_buffer testbench completed");
        $finish;
    end

endmodule
