"""Compatibility wrapper for the NOVA-1 hardware model-loader flow.

The old exporter programmed hundreds of model MMIO writes. The current
deployment flow packages the trained INT8 model into nova1_model_image.mem
and generates a short CPU program that starts the hardware model loader.
"""

from nova1_model_loader_program_generator import *  # noqa: F401,F403
