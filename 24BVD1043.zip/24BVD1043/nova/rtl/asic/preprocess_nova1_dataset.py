﻿from pathlib import Path
from PIL import Image
import csv

project = Path(__file__).resolve().parent
source_dir = project / "dataset"
output_dir = project / "dataset_320x240_gray"
output_dir.mkdir(exist_ok=True)

# Labels correspond to the eight filenames in sorted order.
labels = [
    "cat",
    "dog",
    "car",
    "motorcycle",
    "cat",
    "dog",
    "car",
    "motorcycle",
]

extensions = {".jpg", ".jpeg", ".png", ".bmp"}
images = sorted(
    [p for p in source_dir.iterdir()
     if p.is_file() and p.suffix.lower() in extensions],
    key=lambda p: p.name.lower()
)

if len(images) != 8:
    raise ValueError(
        f"Expected exactly 8 source images, but found {len(images)}."
    )

records = []

for index, (image_path, label) in enumerate(zip(images, labels), start=1):
    with Image.open(image_path) as image:
        original_size = image.size
        processed = image.convert("L").resize(
            (320, 240),
            Image.Resampling.LANCZOS
        )
        output_name = f"{index:02d}_{label}.png"
        output_path = output_dir / output_name
        processed.save(output_path, format="PNG")

    records.append({
        "index": index,
        "source_filename": image_path.name,
        "label": label,
        "class_id": ["cat", "dog", "car", "motorcycle"].index(label),
        "original_size": f"{original_size[0]}x{original_size[1]}",
        "processed_filename": output_name,
        "processed_size": "320x240",
        "mode": "L",
    })

with (output_dir / "labels.csv").open(
    "w", newline="", encoding="utf-8"
) as file:
    writer = csv.DictWriter(file, fieldnames=records[0].keys())
    writer.writeheader()
    writer.writerows(records)

print("\nPreprocessing complete.")
print("Output folder:", output_dir)
print("Images created:", len(records))
print("Image format: grayscale PNG")
print("Resolution: 320 x 240")
print("\nImage labels:")

for record in records:
    print(
        f"{record['processed_filename']}: "
        f"{record['label']} (class {record['class_id']})"
    )

print("\nLabel mapping saved to labels.csv")
