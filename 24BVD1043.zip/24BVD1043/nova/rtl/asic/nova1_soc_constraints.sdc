# NOVA-1 SoC timing constraints
# Top-level clock: clk
# Clock period: 10 ns = 100 MHz

create_clock -name core_clk -period 10.000 [get_ports {clk}]
