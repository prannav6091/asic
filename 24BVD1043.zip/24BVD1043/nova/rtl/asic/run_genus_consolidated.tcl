# ============================================================
# NOVA-1 SoC - Cadence Genus Synthesis Script
# Top module: nova1_soc
# ============================================================

set TOP nova1_soc

# Update this path if your library is stored elsewhere.
set LIB_FILES [list \
    "/home/install/FOUNDRY/digital/180nm/dig/lib/typical.lib" \
]

# Locate RTL and SDC beside this TCL script.
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set RTL_FILE [file join $SCRIPT_DIR "nova1_soc_all_rtl.sv"]
set SDC_FILE [file join $SCRIPT_DIR "nova1_soc_constraints.sdc"]

# Output directories
set OUT_DIR "genus_output"
set REPORT_DIR "$OUT_DIR/reports"

file mkdir $OUT_DIR
file mkdir $REPORT_DIR

# Library setup
set_db init_lib_search_path [list \
    [file dirname [lindex $LIB_FILES 0]]]
set_db library $LIB_FILES

# Check input files
if {![file exists $RTL_FILE]} {
    error "ERROR: RTL file not found: $RTL_FILE"
}
if {![file exists $SDC_FILE]} {
    error "ERROR: SDC file not found: $SDC_FILE"
}

# Read and elaborate RTL
set_db hdl_max_memory_address_range 16777216

puts "INFO: Reading RTL: $RTL_FILE"
read_hdl -sv [list $RTL_FILE]

puts "INFO: Elaborating top: $TOP"
elaborate $TOP

puts "INFO: Checking design"
check_design -unresolved

# Read timing constraints
puts "INFO: Reading SDC: $SDC_FILE"
read_sdc $SDC_FILE

# Synthesis
puts "INFO: Running generic synthesis"
syn_generic

puts "INFO: Running technology mapping"
syn_map

puts "INFO: Optimizing design"
syn_opt

# Write mapped netlist and constraints
write_hdl > "$OUT_DIR/nova1_soc_mapped.v"
write_sdc "$OUT_DIR/nova1_soc_constraints.sdc"

# Reports
report_area > "$REPORT_DIR/area.rpt"
report_timing -max_paths 50 > "$REPORT_DIR/timing.rpt"
report_power > "$REPORT_DIR/power.rpt"
report_qor > "$REPORT_DIR/qor.rpt"
report_gates > "$REPORT_DIR/gates.rpt"

# Save database
write_db "$OUT_DIR/nova1_soc_synthesis.db"

puts "============================================================"
puts "NOVA-1 synthesis script finished"
puts "Review logs and reports for errors and timing violations."
puts "Output directory: $OUT_DIR"
puts "============================================================"

gui_show
