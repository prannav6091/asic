
module channel_sum_buffer #(
    // For a 320x240 image with a 3x3 VALID convolution:
    // (320 - 2) * (240 - 2) = 75,684 output positions.
    // Override this parameter if the actual layer needs a
    // different number of output positions.
    parameter integer MAX_OUTPUTS = 75684
)(
    input  logic clk,
    input  logic reset,

    input  logic [15:0] input_channels,
    input  logic [15:0] channel_index,

    input  logic [31:0] output_index,

    input  logic signed [31:0] channel_result,
    input  logic               channel_valid,

    output logic signed [31:0] accumulated_result,
    output logic               accumulated_valid
);

    // Partial sums are deliberately not reset in bulk.
    // The first channel initializes each location before
    // subsequent channels accumulate into it.
    logic signed [31:0] partial_sum [0:MAX_OUTPUTS-1];

    logic signed [31:0] old_sum;
    logic signed [31:0] new_sum;

    logic output_index_valid;

    // Check the address before accessing the array.
    always_comb begin
        output_index_valid = (output_index < MAX_OUTPUTS);

        old_sum = 32'sd0;

        if (output_index_valid) begin
            old_sum = partial_sum[output_index];
        end

        new_sum = old_sum + channel_result;
    end

    always_ff @(posedge clk) begin
        if (reset) begin
            accumulated_result <= 32'sd0;
            accumulated_valid  <= 1'b0;
        end
        else begin
            accumulated_valid <= 1'b0;

            // Ignore invalid addresses and zero-channel jobs.
            if (channel_valid &&
                output_index_valid &&
                (input_channels != 16'd0)) begin

                // First input channel: initialize this position.
                if (channel_index == 16'd0) begin

                    // A single-channel layer needs no accumulation.
                    if (input_channels == 16'd1) begin
                        accumulated_result <= channel_result;
                        accumulated_valid  <= 1'b1;

                        partial_sum[output_index] <= 32'sd0;
                    end
                    else begin
                        partial_sum[output_index] <= channel_result;
                    end
                end

                // Last input channel: produce the final sum.
                else if (channel_index == (input_channels - 16'd1)) begin
                    accumulated_result <= new_sum;
                    accumulated_valid  <= 1'b1;

                    // Clear the consumed entry for the next job.
                    partial_sum[output_index] <= 32'sd0;
                end

                // Intermediate input channels: keep accumulating.
                else begin
                    partial_sum[output_index] <= new_sum;
                end
            end
        end
    end

endmodule

