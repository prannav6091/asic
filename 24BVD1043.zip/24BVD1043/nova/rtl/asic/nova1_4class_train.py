﻿import numpy as np
from pathlib import Path

DATA_FILE = Path("nova1_4class_demo_dataset.npz")
MODEL_FILE = Path("nova1_4class_float.npz")

SEED = 42
EPOCHS = 1500
LEARNING_RATE = 0.01

rng = np.random.default_rng(SEED)

data = np.load(DATA_FILE)
X = data["X"].astype(np.float32)
y = data["y"].astype(np.int64)

if X.shape != (8, 1, 8, 8):
    raise ValueError(f"Unexpected input shape: {X.shape}")
if set(y.tolist()) != {0, 1, 2, 3}:
    raise ValueError(f"Unexpected class labels: {y}")

# Keep the same convolution dimensions as the current RTL.
def init_weights(shape, fan_in):
    return (rng.standard_normal(shape) * np.sqrt(2.0 / fan_in)).astype(np.float32)

W1 = init_weights((4, 1, 3, 3), 9)
b1 = np.zeros(4, dtype=np.float32)
W2 = init_weights((8, 4, 3, 3), 36)
b2 = np.zeros(8, dtype=np.float32)

def conv_forward(x, w, b, stride):
    n, cin, h, width = x.shape
    cout, _, kh, kw = w.shape
    oh = (h - kh) // stride + 1
    ow = (width - kw) // stride + 1
    out = np.zeros((n, cout, oh, ow), dtype=np.float32)

    for i in range(oh):
        for j in range(ow):
            patch = x[:, :, i*stride:i*stride+kh,
                      j*stride:j*stride+kw]
            out[:, :, i, j] = (
                np.einsum("nchw,ochw->no", patch, w) + b
            )
    return out

def conv_backward(x, w, grad_out, stride):
    n, cin, h, width = x.shape
    cout, _, kh, kw = w.shape
    oh, ow = grad_out.shape[2:]
    grad_x = np.zeros_like(x)
    grad_w = np.zeros_like(w)
    grad_b = grad_out.sum(axis=(0, 2, 3))

    for i in range(oh):
        for j in range(ow):
            hs, ws = i * stride, j * stride
            patch = x[:, :, hs:hs+kh, ws:ws+kw]
            g = grad_out[:, :, i, j]
            grad_w += np.einsum("no,nchw->ochw", g, patch)
            grad_x[:, :, hs:hs+kh, ws:ws+kw] += np.einsum(
                "no,ochw->nchw", g, w
            )
    return grad_x, grad_w, grad_b

def forward(x):
    z1 = conv_forward(x, W1, b1, 2)
    a1 = np.maximum(z1, 0)
    z2 = conv_forward(a1, W2, b2, 1)
    scores = z2[:, :, 0, 0]
    return z1, a1, z2, scores

def softmax_cross_entropy(scores, labels):
    shifted = scores - scores.max(axis=1, keepdims=True)
    exp_scores = np.exp(shifted)
    probs = exp_scores / exp_scores.sum(axis=1, keepdims=True)

    loss = -np.log(
        np.clip(probs[np.arange(len(labels)), labels], 1e-9, 1.0)
    ).mean()

    grad = probs.copy()
    grad[np.arange(len(labels)), labels] -= 1
    grad /= len(labels)
    return loss, grad, probs

for epoch in range(1, EPOCHS + 1):
    z1, a1, z2, scores = forward(X)
    loss, grad_scores, probs = softmax_cross_entropy(scores, y)

    grad_z2 = grad_scores[:, :, None, None]
    grad_a1, grad_W2, grad_b2 = conv_backward(a1, W2, grad_z2, 1)

    grad_z1 = grad_a1 * (z1 > 0)
    _, grad_W1, grad_b1 = conv_backward(X, W1, grad_z1, 2)

    W1 -= LEARNING_RATE * grad_W1
    b1 -= LEARNING_RATE * grad_b1
    W2 -= LEARNING_RATE * grad_W2
    b2 -= LEARNING_RATE * grad_b2

    if epoch == 1 or epoch % 100 == 0:
        print(f"Epoch {epoch:4d}/{EPOCHS} | loss={loss:.5f}")

_, _, _, scores = forward(X)
predictions = scores.argmax(axis=1)
accuracy = float(np.mean(predictions == y))

print("\nTraining-set results (not a generalization test):")
for name, label, pred in zip(data["filenames"], y, predictions):
    print(f"{name:20s} expected={label} predicted={pred}")

print(f"\nTraining accuracy: {accuracy * 100:.1f}%")
print("W1 shape:", W1.shape, "| W2 shape:", W2.shape)

np.savez(
    MODEL_FILE,
    W1=W1, b1=b1,
    W2=W2, b2=b2,
    class_names=np.asarray(["cat", "dog", "car", "motorcycle"]),
    training_images=X,
    training_labels=y,
    training_predictions=predictions,
    training_scores=scores,
    training_accuracy=np.asarray(accuracy),
)

print("\nSaved new model:", MODEL_FILE.resolve())
print("Existing regression model was not modified.")
