﻿import numpy as np
from pathlib import Path

SOURCE = Path("nova1_4class_int8.npz")
OUTPUT = Path("nova1_4class_model_image.mem")
REPORT = Path("nova1_4class_model_image_validation.txt")

if not SOURCE.exists():
    raise FileNotFoundError(f"Missing quantized model: {SOURCE}")

model = np.load(SOURCE)

W1 = model["W1"]
b1 = model["b1"].astype(np.int64)
W2 = model["W2"]
b2 = model["b2"].astype(np.int64)
shift1 = int(model["shift1"])
shift2 = int(model["shift2"])

assert W1.shape == (4, 1, 3, 3), W1.shape
assert b1.shape == (4,), b1.shape
assert W2.shape == (8, 4, 3, 3), W2.shape
assert b2.shape == (8,), b2.shape
assert 0 <= shift1 <= 31
assert 0 <= shift2 <= 31

words = []

def append_word(value):
    words.append(int(value) & 0xFFFFFFFF)

def append_layer(weights, biases, stride, shift):
    cout, cin, kh, kw = weights.shape
    assert kh == 3 and kw == 3

    # Header: Cout[31:24], Cin[23:16], stride[1:0].
    header = (cout << 24) | (cin << 16) | stride
    append_word(header)

    # Match the RTL loader order:
    # filter -> input channel -> tap (row-major 3x3).
    for f in range(cout):
        for c in range(cin):
            for ky in range(3):
                for kx in range(3):
                    # RTL reads the signed weight from word[7:0].
                    append_word(int(weights[f, c, ky, kx]) & 0xFF)

    # Signed 32-bit biases.
    for bias in biases:
        append_word(int(bias))

    # One quantization word per output filter.
    for _ in range(cout):
        append_word(shift)

append_word(0x4E4F5641)  # "NOVA"
append_word(2)           # Number of layers

append_layer(W1, b1, stride=2, shift=shift1)
append_layer(W2, b2, stride=1, shift=shift2)

# Expected size:
# Header words: 2
# Layer 1: 1 + 36 weights + 4 biases + 4 quant words = 45
# Layer 2: 1 + 288 weights + 8 biases + 8 quant words = 305
expected_count = 2 + 45 + 305
assert len(words) == expected_count, (
    f"Wrong word count: {len(words)}, expected {expected_count}"
)

# Write to a NEW file.
OUTPUT.write_text(
    "".join(f"{word:08X}\n" for word in words),
    encoding="ascii"
)

# Read the actual file back and verify every word.
readback = [
    int(line.strip(), 16)
    for line in OUTPUT.read_text(encoding="ascii").splitlines()
    if line.strip()
]
assert readback == words, "Exported file differs from generated words"

# Validate the header and all weight/bias/quant sections by parsing
# the exported words according to the loader's expected format.
pos = 0
assert readback[pos] == 0x4E4F5641
pos += 1
assert readback[pos] == 2
pos += 1

for layer_index, (weights, biases, stride, shift) in enumerate([
    (W1, b1, 2, shift1),
    (W2, b2, 1, shift2),
], start=1):
    cout, cin, _, _ = weights.shape
    expected_header = (cout << 24) | (cin << 16) | stride
    assert readback[pos] == expected_header, (
        f"Layer {layer_index}: header mismatch"
    )
    pos += 1

    for f in range(cout):
        for c in range(cin):
            for ky in range(3):
                for kx in range(3):
                    expected_weight = int(
                        weights[f, c, ky, kx]
                    ) & 0xFF
                    assert readback[pos] == expected_weight, (
                        f"Layer {layer_index} weight mismatch at word {pos}"
                    )
                    pos += 1

    for f in range(cout):
        expected_bias = int(biases[f]) & 0xFFFFFFFF
        assert readback[pos] == expected_bias, (
            f"Layer {layer_index} bias mismatch at filter {f}"
        )
        pos += 1

    for f in range(cout):
        assert readback[pos] == shift, (
            f"Layer {layer_index} quant shift mismatch at filter {f}"
        )
        pos += 1

assert pos == len(readback)

report = [
    "NOVA-1 four-class model image validation",
    "========================================",
    f"Source NPZ: {SOURCE.resolve()}",
    f"Output MEM: {OUTPUT.resolve()}",
    f"Total words: {len(readback)}",
    f"File size: {OUTPUT.stat().st_size} bytes",
    "Magic word: 4E4F5641",
    "Layer count: 2",
    f"Layer 1: Cout=4, Cin=1, stride=2, shift={shift1}",
    f"Layer 2: Cout=8, Cin=4, stride=1, shift={shift2}",
    "Weight order: filter -> channel -> row-major 3x3 taps",
    "Bias encoding: signed 32-bit two's complement",
    "Quant encoding: shift in bits [4:0], repeated per filter",
    "Readback validation: PASS",
    "Word-by-word validation: PASS",
    "Original regression artifacts: not modified",
]
REPORT.write_text("\n".join(report) + "\n", encoding="utf-8")

print("\n".join(report))
print(f"Validation report: {REPORT.resolve()}")
