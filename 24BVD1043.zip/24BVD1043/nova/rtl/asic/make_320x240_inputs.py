from pathlib import Path
from PIL import Image
import numpy as np

DATASET = Path("dataset_320x240_gray")
WIDTH, HEIGHT = 320, 240
PIXELS = WIDTH * HEIGHT
WORDS = PIXELS // 4

images = [
    "01_cat.png",
    "02_dog.png",
    "03_car.png",
    "04_motorcycle.png",
    "05_cat.png",
    "06_dog.png",
    "07_car.png",
    "08_motorcycle.png",
]

for index, filename in enumerate(images):
    path = DATASET / filename
    if not path.exists():
        raise FileNotFoundError(f"Missing image: {path}")

    with Image.open(path) as image:
        image = image.convert("L")
        if image.size != (WIDTH, HEIGHT):
            raise ValueError(
                f"{filename}: expected 320x240, got {image.size}"
            )
        pixels = np.asarray(image, dtype=np.uint8).reshape(-1)

    # Match the existing 8x8 generator's input scaling:
    # unsigned grayscale 0..255 -> signed INT8 range 0..127.
    pixels = np.rint(pixels.astype(np.float32) * (127.0 / 255.0))
    pixels = pixels.astype(np.uint8)

    words = (
        pixels[0::4].astype(np.uint32)
        | (pixels[1::4].astype(np.uint32) << 8)
        | (pixels[2::4].astype(np.uint32) << 16)
        | (pixels[3::4].astype(np.uint32) << 24)
    )

    output = Path(f"nova1_320x240_input_{index}.mem")
    output.write_text(
        "".join(f"{int(word):08X}\n" for word in words),
        encoding="ascii"
    )

    print(f"{output}: {filename}, {len(words)} words")

    if len(words) != WORDS:
        raise RuntimeError(f"Incorrect word count in {output}")

print(f"\nPASS: generated {len(images)} images at 320x240.")
print(f"Each image: {PIXELS} pixels, {WORDS} 32-bit words.")
