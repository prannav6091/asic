﻿import numpy as np
from pathlib import Path

FLOAT_FILE = Path("nova1_4class_float.npz")
DATA_FILE = Path("nova1_4class_demo_dataset.npz")
OUTPUT_FILE = Path("nova1_4class_int8.npz")
INPUT_SCALE = 127.0

model = np.load(FLOAT_FILE)
data = np.load(DATA_FILE)

W1 = model["W1"].astype(np.float32)
b1 = model["b1"].astype(np.float32)
W2 = model["W2"].astype(np.float32)
b2 = model["b2"].astype(np.float32)
X = data["X"].astype(np.float32)
y = data["y"].astype(np.int64)

assert W1.shape == (4, 1, 3, 3), W1.shape
assert b1.shape == (4,), b1.shape
assert W2.shape == (8, 4, 3, 3), W2.shape
assert b2.shape == (8,), b2.shape
assert X.shape == (8, 1, 8, 8), X.shape

def quantize_weights(weights):
    max_abs = float(np.max(np.abs(weights)))
    scale = 1.0 if max_abs == 0 else 127.0 / max_abs
    quantized = np.clip(
        np.round(weights * scale), -127, 127
    ).astype(np.int8)
    return quantized, scale

W1_q, W1_scale = quantize_weights(W1)
W2_q, W2_scale = quantize_weights(W2)

def quantize_input(image):
    return np.clip(
        np.round(image * INPUT_SCALE), 0, 127
    ).astype(np.int32)

def int_conv_raw(x, weights, bias, stride):
    # x shape: H x W x Cin
    h, width, cin = x.shape
    cout, _, kh, kw = weights.shape
    oh = (h - kh) // stride + 1
    ow = (width - kw) // stride + 1
    out = np.zeros((oh, ow, cout), dtype=np.int64)

    for oy in range(oh):
        for ox in range(ow):
            iy, ix = oy * stride, ox * stride
            for f in range(cout):
                acc = int(bias[f])
                for c in range(cin):
                    for ky in range(3):
                        for kx in range(3):
                            acc += (
                                int(x[iy + ky, ix + kx, c])
                                * int(weights[f, c, ky, kx])
                            )
                out[oy, ox, f] = acc
    return out

def choose_shift(max_value):
    shift = 0
    while (int(max_value) >> shift) > 127:
        shift += 1
    return shift

def requant_relu(raw, shift):
    return np.clip(
        np.maximum(raw, 0) >> shift, 0, 127
    ).astype(np.int32)

# Layer 1 bias uses input scale * layer 1 weight scale.
b1_q = np.round(
    b1 * INPUT_SCALE * W1_scale
).astype(np.int32)

# Calibrate layer 1 using all available images.
max_acc1 = 0
for image in X:
    xq = quantize_input(image[0])[..., None]
    raw1 = int_conv_raw(xq, W1_q, b1_q, stride=2)
    max_acc1 = max(max_acc1, int(np.maximum(raw1, 0).max()))

SHIFT1 = choose_shift(max_acc1)

# Layer 2 bias accounts for layer 1 requantization.
layer1_real_scale = INPUT_SCALE * W1_scale / (2 ** SHIFT1)
b2_q = np.round(
    b2 * layer1_real_scale * W2_scale
).astype(np.int32)

# Calibrate layer 2 using the quantized layer 1 activations.
max_acc2 = 0
for image in X:
    xq = quantize_input(image[0])[..., None]
    raw1 = int_conv_raw(xq, W1_q, b1_q, stride=2)
    a1 = requant_relu(raw1, SHIFT1)
    raw2 = int_conv_raw(a1, W2_q, b2_q, stride=1)
    max_acc2 = max(max_acc2, int(np.maximum(raw2, 0).max()))

SHIFT2 = choose_shift(max_acc2)

# Run integer inference for each dataset image.
all_scores = []
predictions = []
all_a1 = []
all_raw1 = []
all_raw2 = []

for image in X:
    xq = quantize_input(image[0])[..., None]
    raw1 = int_conv_raw(xq, W1_q, b1_q, stride=2)
    a1 = requant_relu(raw1, SHIFT1)
    raw2 = int_conv_raw(a1, W2_q, b2_q, stride=1)
    a2 = requant_relu(raw2, SHIFT2)

    # Matches the existing quantizer: scores at spatial position (0,0).
    scores = a2[0, 0, :].copy()
    all_scores.append(scores)
    predictions.append(int(np.argmax(scores)))
    all_a1.append(a1)
    all_raw1.append(raw1)
    all_raw2.append(raw2)

all_scores = np.asarray(all_scores, dtype=np.int32)
predictions = np.asarray(predictions, dtype=np.int64)
accuracy = float(np.mean(predictions == y))

print("NOVA-1 four-class INT8 quantization")
print("-----------------------------------")
print("Input scale:", INPUT_SCALE)
print("Layer 1 weight scale:", W1_scale)
print("Layer 2 weight scale:", W2_scale)
print("Layer 1 shift:", SHIFT1, "| calibration max:", max_acc1)
print("Layer 2 shift:", SHIFT2, "| calibration max:", max_acc2)
print("W1 INT8 shape:", W1_q.shape)
print("W2 INT8 shape:", W2_q.shape)
print("\nPer-image results:")

for name, expected, predicted, scores in zip(
    data["filenames"], y, predictions, all_scores
):
    status = "PASS" if expected == predicted else "MISMATCH"
    print(
        f"{name:20s} expected={expected} predicted={predicted} "
        f"scores={scores.tolist()} {status}"
    )

print(f"\nINT8 training-set accuracy: {accuracy * 100:.1f}%")

np.savez(
    OUTPUT_FILE,
    W1=W1_q,
    b1=b1_q,
    W2=W2_q,
    b2=b2_q,
    shift1=np.asarray(SHIFT1, dtype=np.int32),
    shift2=np.asarray(SHIFT2, dtype=np.int32),
    input_scale=np.asarray(INPUT_SCALE, dtype=np.float32),
    W1_scale=np.asarray(W1_scale, dtype=np.float32),
    W2_scale=np.asarray(W2_scale, dtype=np.float32),
    class_names=data["class_names"],
    filenames=data["filenames"],
    labels=y,
    predictions=predictions,
    scores=all_scores,
    layer1_activations=np.asarray(all_a1),
    layer1_raw=np.asarray(all_raw1),
    layer2_raw=np.asarray(all_raw2),
    training_accuracy=np.asarray(accuracy, dtype=np.float32),
)

print("\nSaved:", OUTPUT_FILE.resolve())
print("Existing regression artifacts were not modified.")
