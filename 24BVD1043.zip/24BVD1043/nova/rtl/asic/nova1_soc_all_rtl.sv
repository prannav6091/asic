// Consolidated NOVA-1 RTL. Top module: nova1_soc.

module accelerator_interface (

    input  logic        clk,
    input  logic        reset,

    // =========================================================
    // SIMPLE MEMORY-MAPPED BUS
    // =========================================================

    input  logic        bus_write,
    input  logic        bus_read,

    input  logic [31:0] bus_addr,
    input  logic [31:0] bus_wdata,

    output logic [31:0] bus_rdata,


    // =========================================================
    // CONVOLUTION ENGINE CONNECTION
    // =========================================================

    output logic        accel_start,

    output logic signed [7:0] pixel0,
    output logic signed [7:0] pixel1,
    output logic signed [7:0] pixel2,
    output logic signed [7:0] pixel3,
    output logic signed [7:0] pixel4,
    output logic signed [7:0] pixel5,
    output logic signed [7:0] pixel6,
    output logic signed [7:0] pixel7,
    output logic signed [7:0] pixel8,

    output logic signed [7:0] weight0,
    output logic signed [7:0] weight1,
    output logic signed [7:0] weight2,
    output logic signed [7:0] weight3,
    output logic signed [7:0] weight4,
    output logic signed [7:0] weight5,
    output logic signed [7:0] weight6,
    output logic signed [7:0] weight7,
    output logic signed [7:0] weight8,

    input  logic        accel_busy,
    input  logic        accel_done,

    input  logic signed [31:0] accel_result

);


    // =========================================================
    // REGISTER ADDRESSES
    // =========================================================

    localparam logic [7:0] ADDR_CONTROL   = 8'h00;
    localparam logic [7:0] ADDR_STATUS    = 8'h04;

    localparam logic [7:0] ADDR_PIXEL03   = 8'h08;
    localparam logic [7:0] ADDR_PIXEL47   = 8'h0C;
    localparam logic [7:0] ADDR_PIXEL8    = 8'h10;

    localparam logic [7:0] ADDR_WEIGHT03  = 8'h14;
    localparam logic [7:0] ADDR_WEIGHT47  = 8'h18;
    localparam logic [7:0] ADDR_WEIGHT8   = 8'h1C;

    localparam logic [7:0] ADDR_RESULT    = 8'h20;


    // =========================================================
    // WRITE LOGIC
    // =========================================================

    always_ff @(posedge clk or posedge reset) begin

        if (reset) begin

            accel_start <= 1'b0;

            pixel0 <= 8'sd0;
            pixel1 <= 8'sd0;
            pixel2 <= 8'sd0;
            pixel3 <= 8'sd0;
            pixel4 <= 8'sd0;
            pixel5 <= 8'sd0;
            pixel6 <= 8'sd0;
            pixel7 <= 8'sd0;
            pixel8 <= 8'sd0;

            weight0 <= 8'sd0;
            weight1 <= 8'sd0;
            weight2 <= 8'sd0;
            weight3 <= 8'sd0;
            weight4 <= 8'sd0;
            weight5 <= 8'sd0;
            weight6 <= 8'sd0;
            weight7 <= 8'sd0;
            weight8 <= 8'sd0;

        end

        else begin

            // start is a one-clock pulse
            accel_start <= 1'b0;

            if (bus_write) begin

                case (bus_addr[7:0])

                    // -----------------------------------------
                    // CONTROL
                    // bit 0 = start
                    // -----------------------------------------

                    ADDR_CONTROL: begin

                        if (bus_wdata[0])
                            accel_start <= 1'b1;

                    end


                    // -----------------------------------------
                    // PIXELS 0..3
                    // -----------------------------------------

                    ADDR_PIXEL03: begin

                        pixel0 <= bus_wdata[7:0];
                        pixel1 <= bus_wdata[15:8];
                        pixel2 <= bus_wdata[23:16];
                        pixel3 <= bus_wdata[31:24];

                    end


                    // -----------------------------------------
                    // PIXELS 4..7
                    // -----------------------------------------

                    ADDR_PIXEL47: begin

                        pixel4 <= bus_wdata[7:0];
                        pixel5 <= bus_wdata[15:8];
                        pixel6 <= bus_wdata[23:16];
                        pixel7 <= bus_wdata[31:24];

                    end


                    // -----------------------------------------
                    // PIXEL 8
                    // -----------------------------------------

                    ADDR_PIXEL8: begin

                        pixel8 <= bus_wdata[7:0];

                    end


                    // -----------------------------------------
                    // WEIGHTS 0..3
                    // -----------------------------------------

                    ADDR_WEIGHT03: begin

                        weight0 <= bus_wdata[7:0];
                        weight1 <= bus_wdata[15:8];
                        weight2 <= bus_wdata[23:16];
                        weight3 <= bus_wdata[31:24];

                    end


                    // -----------------------------------------
                    // WEIGHTS 4..7
                    // -----------------------------------------

                    ADDR_WEIGHT47: begin

                        weight4 <= bus_wdata[7:0];
                        weight5 <= bus_wdata[15:8];
                        weight6 <= bus_wdata[23:16];
                        weight7 <= bus_wdata[31:24];

                    end


                    // -----------------------------------------
                    // WEIGHT 8
                    // -----------------------------------------

                    ADDR_WEIGHT8: begin

                        weight8 <= bus_wdata[7:0];

                    end


                    default: begin
                    end

                endcase

            end

        end

    end


    // =========================================================
    // READ LOGIC
    // =========================================================

    always_comb begin

        bus_rdata = 32'b0;

        if (bus_read) begin

            case (bus_addr[7:0])

                ADDR_CONTROL: begin

                    bus_rdata = 32'b0;

                end


                ADDR_STATUS: begin

                    bus_rdata = {
                        30'b0,
                        accel_done,
                        accel_busy
                    };

                end


                ADDR_PIXEL03: begin

                    bus_rdata = {
                        pixel3,
                        pixel2,
                        pixel1,
                        pixel0
                    };

                end


                ADDR_PIXEL47: begin

                    bus_rdata = {
                        pixel7,
                        pixel6,
                        pixel5,
                        pixel4
                    };

                end


                ADDR_PIXEL8: begin

                    bus_rdata = {
                        24'b0,
                        pixel8
                    };

                end


                ADDR_WEIGHT03: begin

                    bus_rdata = {
                        weight3,
                        weight2,
                        weight1,
                        weight0
                    };

                end


                ADDR_WEIGHT47: begin

                    bus_rdata = {
                        weight7,
                        weight6,
                        weight5,
                        weight4
                    };

                end


                ADDR_WEIGHT8: begin

                    bus_rdata = {
                        24'b0,
                        weight8
                    };

                end


                ADDR_RESULT: begin

                    bus_rdata = accel_result;

                end


                default: begin

                    bus_rdata = 32'b0;

                end

            endcase

        end

    end

endmodule

module address_decoder (

    input  logic [31:0] address,
    input  logic        mem_read,
    input  logic        mem_write,

    output logic        dmem_read,
    output logic        dmem_write,

    output logic        accel_read,
    output logic        accel_write
);

    // =========================================================
    // NOVA-1 MEMORY MAP
    // =========================================================
    //
    // 0x0000_0000 - 0x3FFF_FFFF : Normal Data Memory
    // 0x4000_0000 - 0x4000_00FF : AI Accelerator
    //
    // =========================================================

    always_comb begin

        // Defaults
        dmem_read   = 1'b0;
        dmem_write  = 1'b0;

        accel_read  = 1'b0;
        accel_write = 1'b0;


        // -----------------------------------------------------
        // AI ACCELERATOR REGION
        // -----------------------------------------------------

        if ((address >= 32'h4000_0000) &&
            (address <= 32'h4000_00FF)) begin

            accel_read  = mem_read;
            accel_write = mem_write;

        end

        // -----------------------------------------------------
        // NORMAL DATA MEMORY
        // -----------------------------------------------------

        else begin

            dmem_read  = mem_read;
            dmem_write = mem_write;

        end

    end

endmodule

module alu (
    input  logic [31:0] operand_a,
    input  logic [31:0] operand_b,
    input  logic [3:0]  alu_control,

    output logic [31:0] result,
    output logic        zero
);

    // ALU operation codes
    localparam logic [3:0] ALU_ADD  = 4'b0000;
    localparam logic [3:0] ALU_SUB  = 4'b0001;
    localparam logic [3:0] ALU_AND  = 4'b0010;
    localparam logic [3:0] ALU_OR   = 4'b0011;
    localparam logic [3:0] ALU_XOR  = 4'b0100;
    localparam logic [3:0] ALU_SLL  = 4'b0101;
    localparam logic [3:0] ALU_SRL  = 4'b0110;
    localparam logic [3:0] ALU_SRA  = 4'b0111;
    localparam logic [3:0] ALU_SLT  = 4'b1000;
    localparam logic [3:0] ALU_SLTU = 4'b1001;

    // ALU operation
    always_comb begin

        case (alu_control)

            ALU_ADD:
                result = operand_a + operand_b;

            ALU_SUB:
                result = operand_a - operand_b;

            ALU_AND:
                result = operand_a & operand_b;

            ALU_OR:
                result = operand_a | operand_b;

            ALU_XOR:
                result = operand_a ^ operand_b;

            ALU_SLL:
                result = operand_a << operand_b[4:0];

            ALU_SRL:
                result = operand_a >> operand_b[4:0];

            ALU_SRA:
                result = $signed(operand_a) >>> operand_b[4:0];

            ALU_SLT:
                result = ($signed(operand_a) < $signed(operand_b))
                         ? 32'd1 : 32'd0;

            ALU_SLTU:
                result = (operand_a < operand_b)
                         ? 32'd1 : 32'd0;

            default:
                result = 32'b0;

        endcase

    end

    // Zero flag
    always_comb begin
        zero = (result == 32'b0);
    end

endmodule

module branch_jump_logic (
    input  logic [31:0] pc,
    input  logic [31:0] rs1_value,
    input  logic [31:0] rs2_value,

    input  logic [31:0] branch_immediate,
    input  logic [31:0] jump_immediate,

    input  logic [2:0] funct3,

    input  logic branch,
    input  logic jump,
    input  logic jalr,

    output logic [31:0] next_pc,
    output logic        branch_taken
);

    // Branch types
    localparam logic [2:0] BEQ = 3'b000;
    localparam logic [2:0] BNE = 3'b001;

    always_comb begin

        // Default:
        // Move to next sequential instruction
        next_pc = pc + 32'd4;
        branch_taken = 1'b0;

        // ==========================================
        // BRANCH INSTRUCTIONS
        // ==========================================

        if (branch) begin

            case (funct3)

                // BEQ
                BEQ: begin
                    if (rs1_value == rs2_value) begin
                        next_pc = pc + branch_immediate;
                        branch_taken = 1'b1;
                    end
                end

                // BNE
                BNE: begin
                    if (rs1_value != rs2_value) begin
                        next_pc = pc + branch_immediate;
                        branch_taken = 1'b1;
                    end
                end

                default: begin
                    next_pc = pc + 32'd4;
                    branch_taken = 1'b0;
                end

            endcase

        end

        // ==========================================
        // JUMP INSTRUCTIONS
        // ==========================================

        if (jump) begin

            // JALR:
            // target = rs1 + immediate
            if (jalr) begin
                next_pc = (rs1_value + jump_immediate)
                          & 32'hFFFFFFFE;
            end

            // JAL:
            // target = PC + immediate
            else begin
                next_pc = pc + jump_immediate;
            end

        end

    end

endmodule

module channel_accumulator (

    input  logic clk,
    input  logic reset,

    // Number of input channels participating
    // in the current output accumulation.
    //
    // Examples:
    // RGB first layer = 3
    // later CNN layer = 16, 32, 64, ...
    input  logic [15:0] input_channels,

    // One 3x3 convolution result from one channel
    input  logic signed [31:0] channel_result,
    input  logic               channel_valid,

    // Final accumulated value across all channels
    output logic signed [31:0] accumulated_result,
    output logic               accumulated_valid
);

    logic signed [31:0] accumulator;

    logic [15:0] channel_count;

    logic signed [31:0] next_sum;


    always_comb begin

        next_sum =
            accumulator + channel_result;

    end


    always_ff @(posedge clk) begin

        if (reset) begin

            accumulator         <= 32'sd0;
            channel_count       <= 16'd0;

            accumulated_result  <= 32'sd0;
            accumulated_valid   <= 1'b0;

        end

        else begin

            // Default: output-valid is a one-cycle pulse
            accumulated_valid <= 1'b0;


            if (channel_valid) begin

                // ---------------------------------------------
                // Guard against invalid configuration
                // ---------------------------------------------

                if (input_channels == 16'd0) begin

                    accumulator   <= 32'sd0;
                    channel_count <= 16'd0;

                end


                // ---------------------------------------------
                // Last channel
                //
                // channel_count starts at 0.
                //
                // For input_channels = 3:
                //
                // channel 0
                // channel 1
                // channel 2 -> final output
                // ---------------------------------------------

                else if (
                    channel_count
                    ==
                    (input_channels - 16'd1)
                ) begin

                    accumulated_result <=
                        next_sum;

                    accumulated_valid <=
                        1'b1;


                    // Prepare for next spatial output/filter

                    accumulator <=
                        32'sd0;

                    channel_count <=
                        16'd0;

                end


                // ---------------------------------------------
                // More channels remain
                // ---------------------------------------------

                else begin

                    accumulator <=
                        next_sum;

                    channel_count <=
                        channel_count + 1'b1;

                end

            end

        end

    end

endmodule

module channel_sum_buffer #(
    // For a 320x240 image with a 3x3 VALID convolution:
    // (320 - 2) * (240 - 2) = 75,684 output positions.
    // Override this parameter if the actual layer needs a
    // different number of output positions.
    parameter integer MAX_OUTPUTS = 75684
)(
    input  logic clk,
    input  logic reset,

    input  logic [15:0] input_channels,
    input  logic [15:0] channel_index,

    input  logic [31:0] output_index,

    input  logic signed [31:0] channel_result,
    input  logic               channel_valid,

    output logic signed [31:0] accumulated_result,
    output logic               accumulated_valid
);

    // Partial sums are deliberately not reset in bulk.
    // The first channel initializes each location before
    // subsequent channels accumulate into it.
    logic signed [31:0] partial_sum [0:MAX_OUTPUTS-1];

    logic signed [31:0] old_sum;
    logic signed [31:0] new_sum;

    logic output_index_valid;

    // Check the address before accessing the array.
    always_comb begin
        output_index_valid = (output_index < MAX_OUTPUTS);

        old_sum = 32'sd0;

        if (output_index_valid) begin
            old_sum = partial_sum[output_index];
        end

        new_sum = old_sum + channel_result;
    end

    always_ff @(posedge clk) begin
        if (reset) begin
            accumulated_result <= 32'sd0;
            accumulated_valid  <= 1'b0;
        end
        else begin
            accumulated_valid <= 1'b0;

            // Ignore invalid addresses and zero-channel jobs.
            if (channel_valid &&
                output_index_valid &&
                (input_channels != 16'd0)) begin

                // First input channel: initialize this position.
                if (channel_index == 16'd0) begin

                    // A single-channel layer needs no accumulation.
                    if (input_channels == 16'd1) begin
                        accumulated_result <= channel_result;
                        accumulated_valid  <= 1'b1;

                        partial_sum[output_index] <= 32'sd0;
                    end
                    else begin
                        partial_sum[output_index] <= channel_result;
                    end
                end

                // Last input channel: produce the final sum.
                else if (channel_index == (input_channels - 16'd1)) begin
                    accumulated_result <= new_sum;
                    accumulated_valid  <= 1'b1;

                    // Clear the consumed entry for the next job.
                    partial_sum[output_index] <= 32'sd0;
                end

                // Intermediate input channels: keep accumulating.
                else begin
                    partial_sum[output_index] <= new_sum;
                end
            end
        end
    end

endmodule

module cnn_layer_controller #(
    parameter integer FILTER_LANES = 4
)(
    input logic clk,
    input logic reset,

    input logic start,

    input logic [15:0] input_channels,
    input logic [15:0] output_channels,

    // =========================================================
    // HANDSHAKES
    // =========================================================

    input logic channel_done,
    input logic group_compute_done,

    // =========================================================
    // CONTROLLER OUTPUTS
    // =========================================================

    output logic [15:0] current_channel,
    output logic [15:0] filter_base,

    output logic channel_request,
    output logic filter_group_start,

    output logic [FILTER_LANES-1:0] lane_active,

    output logic busy,
    output logic done
);


    typedef enum logic [2:0] {

        IDLE,

        START_GROUP,

        REQUEST_CHANNEL,

        WAIT_CHANNEL,

        WAIT_GROUP_DONE,

        NEXT_GROUP,

        FINISHED

    } state_t;


    state_t state;

    integer lane;


    // =========================================================
    // ACTIVE FILTER LANES
    //
    // Example:
    //
    // Cout = 10
    // FILTER_LANES = 4
    //
    // base 0 -> 1111
    // base 4 -> 1111
    // base 8 -> 0011
    // =========================================================

    always_comb begin

        lane_active = '0;


        for (
            lane = 0;
            lane < FILTER_LANES;
            lane = lane + 1
        ) begin

            if (
                (filter_base + lane)
                <
                output_channels
            ) begin

                lane_active[lane] =
                    1'b1;

            end

        end

    end


    // =========================================================
    // CONTROLLER FSM
    // =========================================================

    always_ff @(posedge clk) begin

        if (reset) begin

            state <=
                IDLE;


            current_channel <=
                16'd0;

            filter_base <=
                16'd0;


            channel_request <=
                1'b0;

            filter_group_start <=
                1'b0;


            busy <=
                1'b0;

            done <=
                1'b0;

        end

        else begin

            // =================================================
            // DEFAULT ONE-CYCLE PULSES
            // =================================================

            channel_request <=
                1'b0;

            filter_group_start <=
                1'b0;


            case (state)


                // =============================================
                // IDLE
                // =============================================

                IDLE: begin

                    busy <=
                        1'b0;


                    // -----------------------------------------
                    // IMPORTANT:
                    //
                    // DONE is NOT automatically cleared here.
                    //
                    // It remains sticky until a new START.
                    // -----------------------------------------


                    if (
                        start &&
                        (input_channels != 16'd0) &&
                        (output_channels != 16'd0)
                    ) begin

                        // New job clears previous DONE.

                        done <=
                            1'b0;


                        busy <=
                            1'b1;


                        current_channel <=
                            16'd0;

                        filter_base <=
                            16'd0;


                        state <=
                            START_GROUP;

                    end

                end


                // =============================================
                // START NEW FILTER GROUP
                // =============================================

                START_GROUP: begin

                    filter_group_start <=
                        1'b1;


                    current_channel <=
                        16'd0;


                    state <=
                        REQUEST_CHANNEL;

                end


                // =============================================
                // REQUEST CURRENT INPUT CHANNEL
                // =============================================

                REQUEST_CHANNEL: begin

                    channel_request <=
                        1'b1;


                    state <=
                        WAIT_CHANNEL;

                end


                // =============================================
                // WAIT FOR DMA / STREAMING ENGINE
                // =============================================

                WAIT_CHANNEL: begin

                    if (channel_done) begin


                        // -------------------------------------
                        // LAST INPUT CHANNEL?
                        // -------------------------------------

                        if (
                            (current_channel + 1'b1)
                            >=
                            input_channels
                        ) begin

                            state <=
                                WAIT_GROUP_DONE;

                        end


                        // -------------------------------------
                        // REQUEST NEXT INPUT CHANNEL
                        // -------------------------------------

                        else begin

                            current_channel <=
                                current_channel + 1'b1;


                            state <=
                                REQUEST_CHANNEL;

                        end

                    end

                end


                // =============================================
                // WAIT FOR FINAL RESULTS OF THIS FILTER GROUP
                // =============================================

                WAIT_GROUP_DONE: begin

                    if (group_compute_done) begin


                        // -------------------------------------
                        // FINAL FILTER GROUP?
                        // -------------------------------------

                        if (
                            (filter_base + FILTER_LANES)
                            >=
                            output_channels
                        ) begin

                            state <=
                                FINISHED;

                        end


                        // -------------------------------------
                        // MORE FILTER GROUPS REMAIN
                        // -------------------------------------

                        else begin

                            state <=
                                NEXT_GROUP;

                        end

                    end

                end


                // =============================================
                // ADVANCE TO NEXT FILTER GROUP
                // =============================================

                NEXT_GROUP: begin

                    filter_base <=
                        filter_base +
                        FILTER_LANES;


                    current_channel <=
                        16'd0;


                    state <=
                        START_GROUP;

                end


                // =============================================
                // FINISHED
                //
                // DONE remains HIGH until the CPU/controller
                // begins another layer.
                // =============================================

                FINISHED: begin

                    busy <=
                        1'b0;

                    done <=
                        1'b1;


                    // -----------------------------------------
                    // Allow another START directly from the
                    // finished state.
                    // -----------------------------------------

                    if (
                        start &&
                        (input_channels != 16'd0) &&
                        (output_channels != 16'd0)
                    ) begin

                        done <=
                            1'b0;

                        busy <=
                            1'b1;


                        current_channel <=
                            16'd0;

                        filter_base <=
                            16'd0;


                        state <=
                            START_GROUP;

                    end

                end


                // =============================================
                // SAFETY
                // =============================================

                default: begin

                    state <=
                        IDLE;

                    busy <=
                        1'b0;

                end

            endcase

        end

    end


endmodule

module cnn_layer_engine #(
    parameter integer MAX_WIDTH             = 4096,
    parameter integer MAX_OUTPUTS           = 8294400,
    parameter integer MAX_INPUT_CHANNELS    = 64,
    parameter integer MAX_OUTPUT_CHANNELS   = 64,
    parameter integer FILTER_LANES          = 4,
    parameter integer MAX_LAYERS            = 8,
    parameter integer PIPELINE_DRAIN_CYCLES = 4
)(
    input logic clk,
    input logic reset,

    // =========================================================
    // LAYER CONTROL
    // =========================================================

    input logic start,

    // Layer currently executing
    input logic [15:0] active_layer,

    input logic [15:0] image_width,
    input logic [15:0] image_height,

    input logic [15:0] input_channels,
    input logic [15:0] output_channels,

    // 0 = planar
    // 1 = C4 packed
    input logic input_layout_c4,

    // 1 = stride 1
    // 2 = stride 2
    input logic [1:0] stride,

    input logic [31:0] input_base_address,
    input logic [31:0] output_base_address,

    output logic busy,
    output logic done,


    // =========================================================
    // MEMORY READ
    // =========================================================

    output logic        mem_read_req,
    output logic [31:0] mem_read_address,

    input logic [31:0] mem_read_data,
    input logic        mem_read_valid,


    // =========================================================
    // MEMORY WRITE
    // =========================================================

    output logic        mem_write_req,
    output logic [31:0] mem_write_address,
    output logic [31:0] mem_write_data,


    // =========================================================
    // MODEL PROGRAMMING LAYER
    // =========================================================

    input logic [15:0] weight_wr_layer,


    // =========================================================
    // WEIGHT PROGRAMMING
    // =========================================================

    input logic weight_wr_en,

    input logic [15:0] weight_wr_filter,
    input logic [15:0] weight_wr_channel,
    input logic [3:0]  weight_wr_tap,

    input logic signed [7:0] weight_wr_data,


    // =========================================================
    // BIAS PROGRAMMING
    // =========================================================

    input logic bias_wr_en,

    input logic [15:0] bias_wr_filter,
    input logic signed [31:0] bias_wr_data,


    // =========================================================
    // QUANTIZATION PROGRAMMING
    // =========================================================

    input logic quant_wr_en,

    input logic [15:0] quant_wr_filter,
    input logic [4:0]  quant_wr_data
);


    // =========================================================
    // LAYER CONTROLLER SIGNALS
    // =========================================================

    logic [15:0] current_channel;
    logic [15:0] filter_base;

    logic controller_channel_request;
    logic controller_filter_group_start;

    logic [FILTER_LANES-1:0] lane_active;

    logic controller_channel_done;
    logic group_compute_done;


    // =========================================================
    // DMA SIGNALS
    // =========================================================

    logic dma_busy;
    logic dma_channel_done;

    logic signed [7:0] dma_pixel;
    logic              dma_pixel_valid;

    logic [15:0] dma_channel_index;
    logic        dma_channel_start;


    // =========================================================
    // WEIGHTS
    // =========================================================

    logic signed [7:0] f0_k00, f0_k01, f0_k02;
    logic signed [7:0] f0_k10, f0_k11, f0_k12;
    logic signed [7:0] f0_k20, f0_k21, f0_k22;

    logic signed [7:0] f1_k00, f1_k01, f1_k02;
    logic signed [7:0] f1_k10, f1_k11, f1_k12;
    logic signed [7:0] f1_k20, f1_k21, f1_k22;

    logic signed [7:0] f2_k00, f2_k01, f2_k02;
    logic signed [7:0] f2_k10, f2_k11, f2_k12;
    logic signed [7:0] f2_k20, f2_k21, f2_k22;

    logic signed [7:0] f3_k00, f3_k01, f3_k02;
    logic signed [7:0] f3_k10, f3_k11, f3_k12;
    logic signed [7:0] f3_k20, f3_k21, f3_k22;


    // =========================================================
    // POSTPROCESS PARAMETERS
    // =========================================================

    logic signed [31:0] bias0;
    logic signed [31:0] bias1;
    logic signed [31:0] bias2;
    logic signed [31:0] bias3;

    logic [4:0] quant_shift0;
    logic [4:0] quant_shift1;
    logic [4:0] quant_shift2;
    logic [4:0] quant_shift3;


    // =========================================================
    // CNN OUTPUTS
    // =========================================================

    logic signed [7:0] feature0;
    logic signed [7:0] feature1;
    logic signed [7:0] feature2;
    logic signed [7:0] feature3;

    logic feature_valid;

    logic [31:0] feature_index_unused;


    // =========================================================
    // OUTPUT GEOMETRY
    // =========================================================

    logic [31:0] outputs_per_channel;

    logic [31:0] group_output_count;
    logic [31:0] group_number;


    always_comb begin

        outputs_per_channel = 32'd0;


        if (
            (image_width >= 16'd3) &&
            (image_height >= 16'd3)
        ) begin

            // =================================================
            // STRIDE 2
            //
            // out_w = floor((W - 3)/2) + 1
            // =================================================

            if (stride == 2'd2) begin

                outputs_per_channel =

                    (
                        ((image_width - 16'd2) + 1)
                        >> 1
                    )

                    *

                    (
                        ((image_height - 16'd2) + 1)
                        >> 1
                    );

            end

            // =================================================
            // STRIDE 1
            // =================================================

            else begin

                outputs_per_channel =

                    (image_width - 16'd2)
                    *
                    (image_height - 16'd2);

            end

        end


        group_number =
            filter_base / FILTER_LANES;

    end


    // =========================================================
    // LAYER CONTROLLER
    // =========================================================

    cnn_layer_controller #(
        .FILTER_LANES(
            FILTER_LANES
        )
    ) CONTROLLER (

        .clk(clk),
        .reset(reset),

        .start(start),

        .input_channels(
            input_channels
        ),

        .output_channels(
            output_channels
        ),

        .channel_done(
            controller_channel_done
        ),

        .group_compute_done(
            group_compute_done
        ),

        .current_channel(
            current_channel
        ),

        .filter_base(
            filter_base
        ),

        .channel_request(
            controller_channel_request
        ),

        .filter_group_start(
            controller_filter_group_start
        ),

        .lane_active(
            lane_active
        ),

        .busy(busy),
        .done(done)

    );


    // =========================================================
    // DUAL-LAYOUT DMA
    // =========================================================

    nova1_dma DMA (

        .clk(clk),
        .reset(reset),

        .channel_request(
            controller_channel_request
        ),

        .requested_channel(
            current_channel
        ),

        .image_width(
            image_width
        ),

        .image_height(
            image_height
        ),

        .tensor_channels(
            input_channels
        ),

        .input_layout_c4(
            input_layout_c4
        ),

        .input_base_address(
            input_base_address
        ),

        .mem_read_req(
            mem_read_req
        ),

        .mem_read_address(
            mem_read_address
        ),

        .mem_read_data(
            mem_read_data
        ),

        .mem_read_valid(
            mem_read_valid
        ),

        .pixel_out(
            dma_pixel
        ),

        .pixel_valid(
            dma_pixel_valid
        ),

        .channel_index(
            dma_channel_index
        ),

        .channel_start(
            dma_channel_start
        ),

        .busy(
            dma_busy
        ),

        .channel_done(
            dma_channel_done
        )

    );


    // =========================================================
    // PIPELINE DRAIN
    // =========================================================

    logic drain_active;

    integer drain_counter;


    always_ff @(posedge clk) begin

        if (reset) begin

            drain_active <=
                1'b0;

            drain_counter <=
                0;

            controller_channel_done <=
                1'b0;

        end

        else begin

            controller_channel_done <=
                1'b0;


            if (
                dma_channel_done &&
                !drain_active
            ) begin

                drain_active <=
                    1'b1;

                drain_counter <=
                    PIPELINE_DRAIN_CYCLES;

            end


            else if (drain_active) begin

                if (drain_counter > 0) begin

                    drain_counter <=
                        drain_counter - 1;

                end

                else begin

                    controller_channel_done <=
                        1'b1;

                    drain_active <=
                        1'b0;

                end

            end

        end

    end


    // =========================================================
    // LAYER-AWARE WEIGHT MEMORY
    // =========================================================

    cnn_weight_memory #(

        .MAX_INPUT_CHANNELS(
            MAX_INPUT_CHANNELS
        ),

        .MAX_OUTPUT_CHANNELS(
            MAX_OUTPUT_CHANNELS
        ),

        .FILTER_LANES(
            FILTER_LANES
        ),

        .MAX_LAYERS(
            MAX_LAYERS
        )

    ) WEIGHT_MEMORY (

        .clk(
            clk
        ),

        .reset(
            reset
        ),

        // =====================================================
        // ACTIVE EXECUTION LAYER
        // =====================================================

        .active_layer(
            active_layer
        ),

        // =====================================================
        // MODEL PROGRAMMING LAYER
        // =====================================================

        .weight_wr_layer(
            weight_wr_layer
        ),

        // =====================================================
        // WEIGHTS
        // =====================================================

        .weight_wr_en(
            weight_wr_en
        ),

        .weight_wr_filter(
            weight_wr_filter
        ),

        .weight_wr_channel(
            weight_wr_channel
        ),

        .weight_wr_tap(
            weight_wr_tap
        ),

        .weight_wr_data(
            weight_wr_data
        ),

        // =====================================================
        // BIAS
        // =====================================================

        .bias_wr_en(
            bias_wr_en
        ),

        .bias_wr_filter(
            bias_wr_filter
        ),

        .bias_wr_data(
            bias_wr_data
        ),

        // =====================================================
        // QUANTIZATION
        // =====================================================

        .quant_wr_en(
            quant_wr_en
        ),

        .quant_wr_filter(
            quant_wr_filter
        ),

        .quant_wr_data(
            quant_wr_data
        ),

        // =====================================================
        // READ SELECTION
        // =====================================================

        .filter_base(
            filter_base
        ),

        .channel_index(
            dma_channel_index
        ),


        // =====================================================
        // FILTER 0
        // =====================================================

        .f0_k00(f0_k00),
        .f0_k01(f0_k01),
        .f0_k02(f0_k02),

        .f0_k10(f0_k10),
        .f0_k11(f0_k11),
        .f0_k12(f0_k12),

        .f0_k20(f0_k20),
        .f0_k21(f0_k21),
        .f0_k22(f0_k22),


        // =====================================================
        // FILTER 1
        // =====================================================

        .f1_k00(f1_k00),
        .f1_k01(f1_k01),
        .f1_k02(f1_k02),

        .f1_k10(f1_k10),
        .f1_k11(f1_k11),
        .f1_k12(f1_k12),

        .f1_k20(f1_k20),
        .f1_k21(f1_k21),
        .f1_k22(f1_k22),


        // =====================================================
        // FILTER 2
        // =====================================================

        .f2_k00(f2_k00),
        .f2_k01(f2_k01),
        .f2_k02(f2_k02),

        .f2_k10(f2_k10),
        .f2_k11(f2_k11),
        .f2_k12(f2_k12),

        .f2_k20(f2_k20),
        .f2_k21(f2_k21),
        .f2_k22(f2_k22),


        // =====================================================
        // FILTER 3
        // =====================================================

        .f3_k00(f3_k00),
        .f3_k01(f3_k01),
        .f3_k02(f3_k02),

        .f3_k10(f3_k10),
        .f3_k11(f3_k11),
        .f3_k12(f3_k12),

        .f3_k20(f3_k20),
        .f3_k21(f3_k21),
        .f3_k22(f3_k22),


        // =====================================================
        // POSTPROCESS
        // =====================================================

        .bias0(
            bias0
        ),

        .bias1(
            bias1
        ),

        .bias2(
            bias2
        ),

        .bias3(
            bias3
        ),

        .quant_shift0(
            quant_shift0
        ),

        .quant_shift1(
            quant_shift1
        ),

        .quant_shift2(
            quant_shift2
        ),

        .quant_shift3(
            quant_shift3
        )

    );


    // =========================================================
    // STRIDE-AWARE PARALLEL CNN DATAPATH
    // =========================================================

    parallel_multi_channel_conv_top #(

        .MAX_WIDTH(
            MAX_WIDTH
        ),

        .MAX_OUTPUTS(
            MAX_OUTPUTS
        )

    ) CNN_DATAPATH (

        .clk(clk),
        .reset(reset),

        .image_width(
            image_width
        ),

        .image_height(
            image_height
        ),

        .input_channels(
            input_channels
        ),

        .stride(
            stride
        ),

        .channel_index(
            dma_channel_index
        ),

        .channel_start(
            dma_channel_start
        ),

        .pixel_in(
            dma_pixel
        ),

        .pixel_valid(
            dma_pixel_valid
        ),


        // =====================================================
        // FILTER 0
        // =====================================================

        .f0_k00(f0_k00),
        .f0_k01(f0_k01),
        .f0_k02(f0_k02),

        .f0_k10(f0_k10),
        .f0_k11(f0_k11),
        .f0_k12(f0_k12),

        .f0_k20(f0_k20),
        .f0_k21(f0_k21),
        .f0_k22(f0_k22),


        // =====================================================
        // FILTER 1
        // =====================================================

        .f1_k00(f1_k00),
        .f1_k01(f1_k01),
        .f1_k02(f1_k02),

        .f1_k10(f1_k10),
        .f1_k11(f1_k11),
        .f1_k12(f1_k12),

        .f1_k20(f1_k20),
        .f1_k21(f1_k21),
        .f1_k22(f1_k22),


        // =====================================================
        // FILTER 2
        // =====================================================

        .f2_k00(f2_k00),
        .f2_k01(f2_k01),
        .f2_k02(f2_k02),

        .f2_k10(f2_k10),
        .f2_k11(f2_k11),
        .f2_k12(f2_k12),

        .f2_k20(f2_k20),
        .f2_k21(f2_k21),
        .f2_k22(f2_k22),


        // =====================================================
        // FILTER 3
        // =====================================================

        .f3_k00(f3_k00),
        .f3_k01(f3_k01),
        .f3_k02(f3_k02),

        .f3_k10(f3_k10),
        .f3_k11(f3_k11),
        .f3_k12(f3_k12),

        .f3_k20(f3_k20),
        .f3_k21(f3_k21),
        .f3_k22(f3_k22),


        // =====================================================
        // POSTPROCESS
        // =====================================================

        .bias0(
            bias0
        ),

        .bias1(
            bias1
        ),

        .bias2(
            bias2
        ),

        .bias3(
            bias3
        ),

        .quant_shift0(
            quant_shift0
        ),

        .quant_shift1(
            quant_shift1
        ),

        .quant_shift2(
            quant_shift2
        ),

        .quant_shift3(
            quant_shift3
        ),


        // =====================================================
        // OUTPUT
        // =====================================================

        .feature0(
            feature0
        ),

        .feature1(
            feature1
        ),

        .feature2(
            feature2
        ),

        .feature3(
            feature3
        ),

        .feature_valid(
            feature_valid
        ),

        .feature_index(
            feature_index_unused
        )

    );


    // =========================================================
    // C4 FEATURE WRITEBACK
    // =========================================================

    always_ff @(posedge clk) begin

        if (reset) begin

            mem_write_req <=
                1'b0;

            mem_write_address <=
                32'd0;

            mem_write_data <=
                32'd0;

            group_output_count <=
                32'd0;

            group_compute_done <=
                1'b0;

        end

        else begin

            mem_write_req <=
                1'b0;


            // =================================================
            // NEW FILTER GROUP
            // =================================================

            if (
                controller_filter_group_start
            ) begin

                group_output_count <=
                    32'd0;

                group_compute_done <=
                    1'b0;

            end


            // =================================================
            // WRITE FEATURE
            // =================================================

            if (feature_valid) begin

                mem_write_req <=
                    1'b1;


                mem_write_address <=

                    output_base_address

                    +

                    (
                        (
                            (
                                group_number
                                *
                                outputs_per_channel
                            )
                            +
                            group_output_count
                        )
                        *
                        32'd4
                    );


                // =================================================
                // PACK FOUR INT8 LANES
                // =================================================

                if (lane_active[0])
                    mem_write_data[7:0] <=
                        feature0;
                else
                    mem_write_data[7:0] <=
                        8'd0;


                if (lane_active[1])
                    mem_write_data[15:8] <=
                        feature1;
                else
                    mem_write_data[15:8] <=
                        8'd0;


                if (lane_active[2])
                    mem_write_data[23:16] <=
                        feature2;
                else
                    mem_write_data[23:16] <=
                        8'd0;


                if (lane_active[3])
                    mem_write_data[31:24] <=
                        feature3;
                else
                    mem_write_data[31:24] <=
                        8'd0;


                // =================================================
                // LAST OUTPUT OF FILTER GROUP
                // =================================================

                if (
                    (group_output_count + 1)
                    >=
                    outputs_per_channel
                ) begin

                    group_output_count <=
                        32'd0;


                    // Sticky until next filter group begins.

                    group_compute_done <=
                        1'b1;

                end

                else begin

                    group_output_count <=
                        group_output_count + 1'b1;

                end

            end

        end

    end


endmodule

module cnn_network_controller #(
    parameter integer MAX_LAYERS = 8
)(
    input logic clk,
    input logic reset,

    // =========================================================
    // NETWORK CONTROL
    // =========================================================

    input logic start,
    input logic [15:0] num_layers,

    // =========================================================
    // ORIGINAL INPUT CONFIGURATION
    // =========================================================

    input logic [15:0] original_width,
    input logic [15:0] original_height,
    input logic [15:0] original_channels,

    input logic [31:0] original_input_base,

    // =========================================================
    // PING-PONG FEATURE BUFFERS
    // =========================================================

    input logic [31:0] buffer_a_base,
    input logic [31:0] buffer_b_base,

    // =========================================================
    // CPU/MMIO LAYER DESCRIPTOR WRITE INTERFACE
    //
    // descriptor_wr_en is a one-cycle commit pulse.
    // =========================================================

    input logic        descriptor_wr_en,
    input logic [15:0] descriptor_wr_index,
    input logic [15:0] descriptor_wr_cout,
    input logic [1:0]  descriptor_wr_stride,

    // =========================================================
    // LAYER ENGINE HANDSHAKE
    // =========================================================

    input logic layer_done,

    output logic layer_start,

    // =========================================================
    // CURRENT LAYER CONFIGURATION
    // =========================================================

    output logic [15:0] current_layer,

    output logic [15:0] layer_width,
    output logic [15:0] layer_height,

    output logic [15:0] layer_input_channels,
    output logic [15:0] layer_output_channels,

    output logic layer_input_layout_c4,

    output logic [1:0] layer_stride,

    output logic [31:0] layer_input_base,
    output logic [31:0] layer_output_base,

    // =========================================================
    // CALCULATED OUTPUT GEOMETRY
    // =========================================================

    output logic [15:0] layer_output_width,
    output logic [15:0] layer_output_height,

    // =========================================================
    // STATUS
    // =========================================================

    output logic busy,
    output logic done
);


    // =========================================================
    // CPU-PROGRAMMABLE LAYER DESCRIPTOR MEMORY
    //
    // Geometry does NOT need to be programmed per layer.
    //
    // Cin automatically comes from the previous Cout.
    // Width/height automatically come from previous geometry.
    //
    // CPU only programs:
    //
    //   Cout
    //   stride
    // =========================================================

    logic [15:0] cout_mem
        [0:MAX_LAYERS-1];

    logic [1:0] stride_mem
        [0:MAX_LAYERS-1];


    integer i;


    // =========================================================
    // DYNAMIC GEOMETRY STATE
    // =========================================================

    logic [15:0] next_width;
    logic [15:0] next_height;
    logic [15:0] next_channels;


    // =========================================================
    // GEOMETRY CALCULATOR
    // =========================================================

    logic geometry_valid;


    cnn_output_geometry GEOMETRY (

        .input_width(
            layer_width
        ),

        .input_height(
            layer_height
        ),

        .stride(
            layer_stride
        ),

        .output_width(
            layer_output_width
        ),

        .output_height(
            layer_output_height
        ),

        .valid(
            geometry_valid
        )

    );


    // =========================================================
    // NETWORK FSM
    // =========================================================

    typedef enum logic [2:0] {

        IDLE,

        LOAD_LAYER,

        START_LAYER,

        WAIT_DONE_CLEAR,

        WAIT_LAYER,

        NEXT_LAYER,

        FINISHED

    } state_t;


    state_t state;


    // =========================================================
    // CONTROL
    // =========================================================

    always_ff @(posedge clk) begin

        if (reset) begin

            state <=
                IDLE;


            current_layer <=
                16'd0;


            layer_width <=
                16'd0;

            layer_height <=
                16'd0;


            layer_input_channels <=
                16'd0;

            layer_output_channels <=
                16'd0;


            layer_input_layout_c4 <=
                1'b0;

            layer_stride <=
                2'd1;


            layer_input_base <=
                32'd0;

            layer_output_base <=
                32'd0;


            next_width <=
                16'd0;

            next_height <=
                16'd0;

            next_channels <=
                16'd0;


            layer_start <=
                1'b0;


            busy <=
                1'b0;

            done <=
                1'b0;


            // =================================================
            // DEFAULT DESCRIPTOR TABLE
            //
            // These defaults preserve our existing tests.
            //
            // CPU may overwrite them through MMIO.
            // =================================================

            for (
                i = 0;
                i < MAX_LAYERS;
                i = i + 1
            ) begin

                cout_mem[i] <=
                    16'd0;

                stride_mem[i] <=
                    2'd1;

            end


            // Layer 0
            //
            // RGB input -> 4 output channels
            // stride 2

            cout_mem[0] <=
                16'd4;

            stride_mem[0] <=
                2'd2;


            // Layer 1

            if (MAX_LAYERS > 1) begin

                cout_mem[1] <=
                    16'd8;

                stride_mem[1] <=
                    2'd1;

            end


            // Layer 2

            if (MAX_LAYERS > 2) begin

                cout_mem[2] <=
                    16'd4;

                stride_mem[2] <=
                    2'd1;

            end

        end

        else begin

            // =================================================
            // DEFAULT ONE-CYCLE START PULSE
            // =================================================

            layer_start <=
                1'b0;


            // =================================================
            // CPU/MMIO DESCRIPTOR PROGRAMMING
            // =================================================

            if (
                descriptor_wr_en &&
                (descriptor_wr_index < MAX_LAYERS)
            ) begin

                cout_mem[
                    descriptor_wr_index
                ] <=
                    descriptor_wr_cout;


                // Only stride 1 or 2 is accepted.
                //
                // Invalid values fall back to stride 1.

                if (
                    descriptor_wr_stride == 2'd2
                ) begin

                    stride_mem[
                        descriptor_wr_index
                    ] <=
                        2'd2;

                end

                else begin

                    stride_mem[
                        descriptor_wr_index
                    ] <=
                        2'd1;

                end

            end


            // =================================================
            // FSM
            // =================================================

            case (state)


                // =============================================
                // IDLE
                // =============================================

                IDLE: begin

                    busy <=
                        1'b0;


                    if (
                        start &&
                        (num_layers != 16'd0)
                    ) begin

                        busy <=
                            1'b1;

                        done <=
                            1'b0;


                        current_layer <=
                            16'd0;


                        // Seed geometry from original image.

                        next_width <=
                            original_width;

                        next_height <=
                            original_height;

                        next_channels <=
                            original_channels;


                        state <=
                            LOAD_LAYER;

                    end

                end


                // =============================================
                // LOAD CURRENT LAYER
                // =============================================

                LOAD_LAYER: begin

                    // -----------------------------------------
                    // Dynamic input geometry
                    // -----------------------------------------

                    layer_width <=
                        next_width;

                    layer_height <=
                        next_height;

                    layer_input_channels <=
                        next_channels;


                    // -----------------------------------------
                    // CPU-programmed layer descriptor
                    // -----------------------------------------

                    layer_output_channels <=
                        cout_mem[
                            current_layer
                        ];

                    layer_stride <=
                        stride_mem[
                            current_layer
                        ];


                    // -----------------------------------------
                    // First input is planar.
                    //
                    // All intermediate CNN tensors use C4.
                    // -----------------------------------------

                    if (
                        current_layer == 16'd0
                    ) begin

                        layer_input_layout_c4 <=
                            1'b0;

                    end

                    else begin

                        layer_input_layout_c4 <=
                            1'b1;

                    end


                    // =========================================
                    // INPUT BUFFER
                    // =========================================

                    if (
                        current_layer == 16'd0
                    ) begin

                        layer_input_base <=
                            original_input_base;

                    end

                    else if (
                        current_layer[0]
                    ) begin

                        // Odd layer reads Buffer A.

                        layer_input_base <=
                            buffer_a_base;

                    end

                    else begin

                        // Even layer >= 2 reads Buffer B.

                        layer_input_base <=
                            buffer_b_base;

                    end


                    // =========================================
                    // OUTPUT BUFFER
                    // =========================================

                    if (
                        !current_layer[0]
                    ) begin

                        // Even layer writes Buffer A.

                        layer_output_base <=
                            buffer_a_base;

                    end

                    else begin

                        // Odd layer writes Buffer B.

                        layer_output_base <=
                            buffer_b_base;

                    end


                    state <=
                        START_LAYER;

                end


                // =============================================
                // START REAL CNN LAYER
                // =============================================

                START_LAYER: begin

                    if (
                        geometry_valid &&
                        (layer_output_channels != 16'd0)
                    ) begin

                        layer_start <=
                            1'b1;


                        state <=
                            WAIT_DONE_CLEAR;

                    end

                    else begin

                        // Invalid geometry or descriptor.

                        busy <=
                            1'b0;

                        done <=
                            1'b1;


                        state <=
                            FINISHED;

                    end

                end


                // =============================================
                // WAIT UNTIL PREVIOUS STICKY DONE CLEARS
                // =============================================

                WAIT_DONE_CLEAR: begin

                    if (!layer_done) begin

                        state <=
                            WAIT_LAYER;

                    end

                end


                // =============================================
                // WAIT FOR CURRENT LAYER COMPLETION
                // =============================================

                WAIT_LAYER: begin

                    if (layer_done) begin

                        // -------------------------------------
                        // Propagate geometry into next layer.
                        // -------------------------------------

                        next_width <=
                            layer_output_width;

                        next_height <=
                            layer_output_height;

                        next_channels <=
                            layer_output_channels;


                        // -------------------------------------
                        // Final layer?
                        // -------------------------------------

                        if (
                            (current_layer + 1'b1)
                            >=
                            num_layers
                        ) begin

                            state <=
                                FINISHED;

                        end

                        else begin

                            state <=
                                NEXT_LAYER;

                        end

                    end

                end


                // =============================================
                // ADVANCE NETWORK
                // =============================================

                NEXT_LAYER: begin

                    current_layer <=
                        current_layer + 1'b1;


                    state <=
                        LOAD_LAYER;

                end


                // =============================================
                // ENTIRE NETWORK COMPLETE
                // =============================================

                FINISHED: begin

                    busy <=
                        1'b0;

                    done <=
                        1'b1;


                    // Start another inference without reset.

                    if (
                        start &&
                        (num_layers != 16'd0)
                    ) begin

                        done <=
                            1'b0;

                        busy <=
                            1'b1;


                        current_layer <=
                            16'd0;


                        next_width <=
                            original_width;

                        next_height <=
                            original_height;

                        next_channels <=
                            original_channels;


                        state <=
                            LOAD_LAYER;

                    end

                end


                // =============================================
                // SAFETY
                // =============================================

                default: begin

                    state <=
                        IDLE;

                    busy <=
                        1'b0;

                end

            endcase

        end

    end


endmodule

module cnn_network_engine #(
    parameter integer MAX_WIDTH             = 4096,
    parameter integer MAX_OUTPUTS           = 8294400,
    parameter integer MAX_INPUT_CHANNELS    = 64,
    parameter integer MAX_OUTPUT_CHANNELS   = 64,
    parameter integer FILTER_LANES          = 4,
    parameter integer MAX_LAYERS            = 8,
    parameter integer PIPELINE_DRAIN_CYCLES = 4
)(
    input logic clk,
    input logic reset,

    // =========================================================
    // NETWORK CONTROL
    // =========================================================

    input logic start,
    input logic [15:0] num_layers,

    // =========================================================
    // ORIGINAL INPUT TENSOR
    // =========================================================

    input logic [15:0] original_width,
    input logic [15:0] original_height,
    input logic [15:0] original_channels,

    input logic [31:0] original_input_base,

    // =========================================================
    // PING-PONG FEATURE BUFFERS
    // =========================================================

    input logic [31:0] buffer_a_base,
    input logic [31:0] buffer_b_base,

    output logic busy,
    output logic done,

    // =========================================================
    // MEMORY
    // =========================================================

    output logic        mem_read_req,
    output logic [31:0] mem_read_address,

    input logic [31:0] mem_read_data,
    input logic        mem_read_valid,

    output logic        mem_write_req,
    output logic [31:0] mem_write_address,
    output logic [31:0] mem_write_data,

    // =========================================================
    // MODEL PROGRAMMING LAYER
    // =========================================================

    input logic [15:0] weight_wr_layer,

    // =========================================================
    // WEIGHT PROGRAMMING
    // =========================================================

    input logic weight_wr_en,

    input logic [15:0] weight_wr_filter,
    input logic [15:0] weight_wr_channel,
    input logic [3:0]  weight_wr_tap,

    input logic signed [7:0] weight_wr_data,

    // =========================================================
    // BIAS PROGRAMMING
    // =========================================================

    input logic bias_wr_en,

    input logic [15:0] bias_wr_filter,
    input logic signed [31:0] bias_wr_data,

    // =========================================================
    // QUANT PROGRAMMING
    // =========================================================

    input logic quant_wr_en,

    input logic [15:0] quant_wr_filter,
    input logic [4:0]  quant_wr_data,

    // =========================================================
    // DESCRIPTOR PROGRAMMING
    // =========================================================

    input logic        descriptor_wr_en,
    input logic [15:0] descriptor_wr_index,
    input logic [15:0] descriptor_wr_cout,
    input logic [1:0]  descriptor_wr_stride,

    // =========================================================
    // DEBUG
    // =========================================================

    output logic [15:0] current_layer,

    output logic [15:0] active_width,
    output logic [15:0] active_height,

    output logic [15:0] active_cin,
    output logic [15:0] active_cout,

    output logic active_layout_c4,

    output logic [1:0] active_stride,

    output logic [15:0] active_output_width,
    output logic [15:0] active_output_height,

    output logic [31:0] active_input_base,
    output logic [31:0] active_output_base
);


    // =========================================================
    // NETWORK CONTROLLER -> LAYER ENGINE
    // =========================================================

    logic network_layer_start;

    logic layer_engine_busy;
    logic layer_engine_done;

    logic [15:0] layer_width;
    logic [15:0] layer_height;

    logic [15:0] layer_input_channels;
    logic [15:0] layer_output_channels;

    logic layer_input_layout_c4;

    logic [1:0] layer_stride;

    logic [31:0] layer_input_base;
    logic [31:0] layer_output_base;

    logic [15:0] layer_output_width;
    logic [15:0] layer_output_height;


    // =========================================================
    // NETWORK CONTROLLER
    // =========================================================

    cnn_network_controller #(
        .MAX_LAYERS(
            MAX_LAYERS
        )
    ) NETWORK_CONTROLLER (

        .clk(
            clk
        ),

        .reset(
            reset
        ),

        .start(
            start
        ),

        .num_layers(
            num_layers
        ),

        .original_width(
            original_width
        ),

        .original_height(
            original_height
        ),

        .original_channels(
            original_channels
        ),

        .original_input_base(
            original_input_base
        ),

        .buffer_a_base(
            buffer_a_base
        ),

        .buffer_b_base(
            buffer_b_base
        ),

        // =====================================================
        // DESCRIPTORS
        // =====================================================

        .descriptor_wr_en(
            descriptor_wr_en
        ),

        .descriptor_wr_index(
            descriptor_wr_index
        ),

        .descriptor_wr_cout(
            descriptor_wr_cout
        ),

        .descriptor_wr_stride(
            descriptor_wr_stride
        ),

        // =====================================================
        // LAYER ENGINE HANDSHAKE
        // =====================================================

        .layer_done(
            layer_engine_done
        ),

        .layer_start(
            network_layer_start
        ),

        // =====================================================
        // CURRENT LAYER CONFIG
        // =====================================================

        .current_layer(
            current_layer
        ),

        .layer_width(
            layer_width
        ),

        .layer_height(
            layer_height
        ),

        .layer_input_channels(
            layer_input_channels
        ),

        .layer_output_channels(
            layer_output_channels
        ),

        .layer_input_layout_c4(
            layer_input_layout_c4
        ),

        .layer_stride(
            layer_stride
        ),

        .layer_input_base(
            layer_input_base
        ),

        .layer_output_base(
            layer_output_base
        ),

        .layer_output_width(
            layer_output_width
        ),

        .layer_output_height(
            layer_output_height
        ),

        .busy(
            busy
        ),

        .done(
            done
        )

    );


    // =========================================================
    // CNN LAYER ENGINE
    // =========================================================

    cnn_layer_engine #(

        .MAX_WIDTH(
            MAX_WIDTH
        ),

        .MAX_OUTPUTS(
            MAX_OUTPUTS
        ),

        .MAX_INPUT_CHANNELS(
            MAX_INPUT_CHANNELS
        ),

        .MAX_OUTPUT_CHANNELS(
            MAX_OUTPUT_CHANNELS
        ),

        .FILTER_LANES(
            FILTER_LANES
        ),

        .MAX_LAYERS(
            MAX_LAYERS
        ),

        .PIPELINE_DRAIN_CYCLES(
            PIPELINE_DRAIN_CYCLES
        )

    ) LAYER_ENGINE (

        .clk(
            clk
        ),

        .reset(
            reset
        ),

        .start(
            network_layer_start
        ),

        // =====================================================
        // EXECUTING LAYER
        //
        // Automatically controlled by network controller
        // =====================================================

        .active_layer(
            current_layer
        ),

        // =====================================================
        // GEOMETRY
        // =====================================================

        .image_width(
            layer_width
        ),

        .image_height(
            layer_height
        ),

        .input_channels(
            layer_input_channels
        ),

        .output_channels(
            layer_output_channels
        ),

        .input_layout_c4(
            layer_input_layout_c4
        ),

        .stride(
            layer_stride
        ),

        // =====================================================
        // MEMORY BASES
        // =====================================================

        .input_base_address(
            layer_input_base
        ),

        .output_base_address(
            layer_output_base
        ),

        // =====================================================
        // STATUS
        // =====================================================

        .busy(
            layer_engine_busy
        ),

        .done(
            layer_engine_done
        ),

        // =====================================================
        // MEMORY
        // =====================================================

        .mem_read_req(
            mem_read_req
        ),

        .mem_read_address(
            mem_read_address
        ),

        .mem_read_data(
            mem_read_data
        ),

        .mem_read_valid(
            mem_read_valid
        ),

        .mem_write_req(
            mem_write_req
        ),

        .mem_write_address(
            mem_write_address
        ),

        .mem_write_data(
            mem_write_data
        ),

        // =====================================================
        // PARAMETER PROGRAMMING LAYER
        //
        // Controlled independently by CPU/MMIO
        // =====================================================

        .weight_wr_layer(
            weight_wr_layer
        ),

        // =====================================================
        // WEIGHTS
        // =====================================================

        .weight_wr_en(
            weight_wr_en
        ),

        .weight_wr_filter(
            weight_wr_filter
        ),

        .weight_wr_channel(
            weight_wr_channel
        ),

        .weight_wr_tap(
            weight_wr_tap
        ),

        .weight_wr_data(
            weight_wr_data
        ),

        // =====================================================
        // BIAS
        // =====================================================

        .bias_wr_en(
            bias_wr_en
        ),

        .bias_wr_filter(
            bias_wr_filter
        ),

        .bias_wr_data(
            bias_wr_data
        ),

        // =====================================================
        // QUANTIZATION
        // =====================================================

        .quant_wr_en(
            quant_wr_en
        ),

        .quant_wr_filter(
            quant_wr_filter
        ),

        .quant_wr_data(
            quant_wr_data
        )

    );


    // =========================================================
    // DEBUG OUTPUTS
    // =========================================================

    always_comb begin

        active_width =
            layer_width;

        active_height =
            layer_height;

        active_cin =
            layer_input_channels;

        active_cout =
            layer_output_channels;

        active_layout_c4 =
            layer_input_layout_c4;

        active_stride =
            layer_stride;

        active_output_width =
            layer_output_width;

        active_output_height =
            layer_output_height;

        active_input_base =
            layer_input_base;

        active_output_base =
            layer_output_base;

    end


endmodule

module cnn_output_geometry (

    input logic [15:0] input_width,
    input logic [15:0] input_height,

    // Supported:
    // 1 = stride 1
    // 2 = stride 2
    input logic [1:0] stride,

    output logic [15:0] output_width,
    output logic [15:0] output_height,

    output logic valid
);


    always_comb begin

        output_width  = 16'd0;
        output_height = 16'd0;

        valid = 1'b0;


        // =============================================
        // Valid 3x3 convolution requires at least 3x3
        // =============================================

        if (
            (input_width  >= 16'd3) &&
            (input_height >= 16'd3)
        ) begin

            case (stride)

                // =====================================
                // STRIDE 1
                //
                // floor((W - 3)/1) + 1
                // = W - 2
                // =====================================

                2'd1: begin

                    output_width =
                        input_width - 16'd2;

                    output_height =
                        input_height - 16'd2;

                    valid =
                        1'b1;

                end


                // =====================================
                // STRIDE 2
                //
                // floor((W - 3)/2) + 1
                // =====================================

                2'd2: begin

                    output_width =
                        ((input_width - 16'd3) >> 1)
                        + 16'd1;

                    output_height =
                        ((input_height - 16'd3) >> 1)
                        + 16'd1;

                    valid =
                        1'b1;

                end


                // =====================================
                // Unsupported stride
                // =====================================

                default: begin

                    output_width =
                        16'd0;

                    output_height =
                        16'd0;

                    valid =
                        1'b0;

                end

            endcase

        end

    end


endmodule

module cnn_postprocess (

    // 32-bit convolution accumulation
    input  logic signed [31:0] accumulator,

    // One bias per output channel/filter
    input  logic signed [31:0] bias,

    // Power-of-two requantization scale
    input  logic [4:0] quant_shift,

    input  logic valid_in,

    // Quantized feature
    output logic signed [7:0] feature_out,

    output logic valid_out

);

    logic signed [31:0] biased_value;

    logic signed [31:0] relu_value;

    logic signed [7:0] quantized_value;


    // =========================================================
    // BIAS
    // =========================================================

    always_comb begin

        biased_value =
            accumulator + bias;

    end


    // =========================================================
    // ReLU
    // =========================================================

    relu RELU_STAGE (

        .data_in(biased_value),

        .valid_in(valid_in),

        .data_out(relu_value),

        .valid_out()

    );


    // =========================================================
    // REQUANTIZATION
    // =========================================================

    requantize_int8 REQUANTIZER (

        .data_in(relu_value),

        .shift_amount(quant_shift),

        .data_out(quantized_value)

    );


    // =========================================================
    // OUTPUT
    // =========================================================

    always_comb begin

        feature_out = quantized_value;

        valid_out = valid_in;

    end


endmodule

module cnn_weight_memory #(
    parameter integer MAX_INPUT_CHANNELS  = 64,
    parameter integer MAX_OUTPUT_CHANNELS = 64,
    parameter integer FILTER_LANES        = 4,
    parameter integer MAX_LAYERS          = 8
)(
    input logic clk,
    input logic reset,

    // =========================================================
    // ACTIVE EXECUTION LAYER
    //
    // Selects which layer's parameters are READ during inference.
    // =========================================================

    input logic [15:0] active_layer,


    // =========================================================
    // PROGRAMMING LAYER
    //
    // Selects which layer's parameters are WRITTEN by CPU/MMIO.
    // =========================================================

    input logic [15:0] weight_wr_layer,


    // =========================================================
    // WEIGHT WRITE INTERFACE
    // =========================================================

    input logic weight_wr_en,

    input logic [15:0] weight_wr_filter,
    input logic [15:0] weight_wr_channel,

    // Tap index:
    //
    // 0 1 2
    // 3 4 5
    // 6 7 8

    input logic [3:0] weight_wr_tap,

    input logic signed [7:0] weight_wr_data,


    // =========================================================
    // BIAS WRITE
    // =========================================================

    input logic bias_wr_en,

    input logic [15:0] bias_wr_filter,

    input logic signed [31:0] bias_wr_data,


    // =========================================================
    // QUANTIZATION WRITE
    // =========================================================

    input logic quant_wr_en,

    input logic [15:0] quant_wr_filter,

    input logic [4:0] quant_wr_data,


    // =========================================================
    // READ SELECTION
    //
    // filter_base selects first filter of current 4-lane group.
    //
    // Example:
    //
    // filter_base = 0 -> filters 0,1,2,3
    // filter_base = 4 -> filters 4,5,6,7
    // =========================================================

    input logic [15:0] filter_base,

    input logic [15:0] channel_index,


    // =========================================================
    // FILTER 0 WEIGHTS
    // =========================================================

    output logic signed [7:0] f0_k00,
    output logic signed [7:0] f0_k01,
    output logic signed [7:0] f0_k02,

    output logic signed [7:0] f0_k10,
    output logic signed [7:0] f0_k11,
    output logic signed [7:0] f0_k12,

    output logic signed [7:0] f0_k20,
    output logic signed [7:0] f0_k21,
    output logic signed [7:0] f0_k22,


    // =========================================================
    // FILTER 1 WEIGHTS
    // =========================================================

    output logic signed [7:0] f1_k00,
    output logic signed [7:0] f1_k01,
    output logic signed [7:0] f1_k02,

    output logic signed [7:0] f1_k10,
    output logic signed [7:0] f1_k11,
    output logic signed [7:0] f1_k12,

    output logic signed [7:0] f1_k20,
    output logic signed [7:0] f1_k21,
    output logic signed [7:0] f1_k22,


    // =========================================================
    // FILTER 2 WEIGHTS
    // =========================================================

    output logic signed [7:0] f2_k00,
    output logic signed [7:0] f2_k01,
    output logic signed [7:0] f2_k02,

    output logic signed [7:0] f2_k10,
    output logic signed [7:0] f2_k11,
    output logic signed [7:0] f2_k12,

    output logic signed [7:0] f2_k20,
    output logic signed [7:0] f2_k21,
    output logic signed [7:0] f2_k22,


    // =========================================================
    // FILTER 3 WEIGHTS
    // =========================================================

    output logic signed [7:0] f3_k00,
    output logic signed [7:0] f3_k01,
    output logic signed [7:0] f3_k02,

    output logic signed [7:0] f3_k10,
    output logic signed [7:0] f3_k11,
    output logic signed [7:0] f3_k12,

    output logic signed [7:0] f3_k20,
    output logic signed [7:0] f3_k21,
    output logic signed [7:0] f3_k22,


    // =========================================================
    // PER-FILTER POSTPROCESS PARAMETERS
    // =========================================================

    output logic signed [31:0] bias0,
    output logic signed [31:0] bias1,
    output logic signed [31:0] bias2,
    output logic signed [31:0] bias3,

    output logic [4:0] quant_shift0,
    output logic [4:0] quant_shift1,
    output logic [4:0] quant_shift2,
    output logic [4:0] quant_shift3
);


    // =========================================================
    // STORAGE
    //
    // weight_mem[layer][filter][channel][tap]
    //
    // bias_mem[layer][filter]
    //
    // quant_mem[layer][filter]
    // =========================================================

    logic signed [7:0]
        weight_mem
        [0:MAX_LAYERS-1]
        [0:MAX_OUTPUT_CHANNELS-1]
        [0:MAX_INPUT_CHANNELS-1]
        [0:8];


    logic signed [31:0]
        bias_mem
        [0:MAX_LAYERS-1]
        [0:MAX_OUTPUT_CHANNELS-1];


    logic [4:0]
        quant_mem
        [0:MAX_LAYERS-1]
        [0:MAX_OUTPUT_CHANNELS-1];


    integer l;
    integer f;
    integer c;
    integer t;


    // =========================================================
    // INITIALIZATION
    // =========================================================

    initial begin

        for (
            l = 0;
            l < MAX_LAYERS;
            l = l + 1
        ) begin

            for (
                f = 0;
                f < MAX_OUTPUT_CHANNELS;
                f = f + 1
            ) begin

                bias_mem[l][f] =
                    32'sd0;

                quant_mem[l][f] =
                    5'd0;


                for (
                    c = 0;
                    c < MAX_INPUT_CHANNELS;
                    c = c + 1
                ) begin

                    for (
                        t = 0;
                        t < 9;
                        t = t + 1
                    ) begin

                        weight_mem[l][f][c][t] =
                            8'sd0;

                    end

                end

            end

        end

    end


    // =========================================================
    // WRITES
    // =========================================================

    always_ff @(posedge clk) begin

        // =====================================================
        // WEIGHT WRITE
        // =====================================================

        if (weight_wr_en) begin

            if (
                (weight_wr_layer < MAX_LAYERS) &&
                (weight_wr_filter < MAX_OUTPUT_CHANNELS) &&
                (weight_wr_channel < MAX_INPUT_CHANNELS) &&
                (weight_wr_tap < 9)
            ) begin

                weight_mem
                [weight_wr_layer]
                [weight_wr_filter]
                [weight_wr_channel]
                [weight_wr_tap]
                    <= weight_wr_data;

            end

        end


        // =====================================================
        // BIAS WRITE
        //
        // Bias uses same programming-layer selector.
        // =====================================================

        if (bias_wr_en) begin

            if (
                (weight_wr_layer < MAX_LAYERS) &&
                (bias_wr_filter < MAX_OUTPUT_CHANNELS)
            ) begin

                bias_mem
                [weight_wr_layer]
                [bias_wr_filter]
                    <= bias_wr_data;

            end

        end


        // =====================================================
        // QUANTIZATION WRITE
        //
        // Quantization uses same programming-layer selector.
        // =====================================================

        if (quant_wr_en) begin

            if (
                (weight_wr_layer < MAX_LAYERS) &&
                (quant_wr_filter < MAX_OUTPUT_CHANNELS)
            ) begin

                quant_mem
                [weight_wr_layer]
                [quant_wr_filter]
                    <= quant_wr_data;

            end

        end

    end


    // =========================================================
    // COMBINATIONAL READ
    // =========================================================

    always_comb begin

        // =====================================================
        // DEFAULT OUTPUTS
        // =====================================================

        f0_k00 = 8'sd0;
        f0_k01 = 8'sd0;
        f0_k02 = 8'sd0;

        f0_k10 = 8'sd0;
        f0_k11 = 8'sd0;
        f0_k12 = 8'sd0;

        f0_k20 = 8'sd0;
        f0_k21 = 8'sd0;
        f0_k22 = 8'sd0;


        f1_k00 = 8'sd0;
        f1_k01 = 8'sd0;
        f1_k02 = 8'sd0;

        f1_k10 = 8'sd0;
        f1_k11 = 8'sd0;
        f1_k12 = 8'sd0;

        f1_k20 = 8'sd0;
        f1_k21 = 8'sd0;
        f1_k22 = 8'sd0;


        f2_k00 = 8'sd0;
        f2_k01 = 8'sd0;
        f2_k02 = 8'sd0;

        f2_k10 = 8'sd0;
        f2_k11 = 8'sd0;
        f2_k12 = 8'sd0;

        f2_k20 = 8'sd0;
        f2_k21 = 8'sd0;
        f2_k22 = 8'sd0;


        f3_k00 = 8'sd0;
        f3_k01 = 8'sd0;
        f3_k02 = 8'sd0;

        f3_k10 = 8'sd0;
        f3_k11 = 8'sd0;
        f3_k12 = 8'sd0;

        f3_k20 = 8'sd0;
        f3_k21 = 8'sd0;
        f3_k22 = 8'sd0;


        bias0 =
            32'sd0;

        bias1 =
            32'sd0;

        bias2 =
            32'sd0;

        bias3 =
            32'sd0;


        quant_shift0 =
            5'd0;

        quant_shift1 =
            5'd0;

        quant_shift2 =
            5'd0;

        quant_shift3 =
            5'd0;


        // =====================================================
        // VALID ACTIVE LAYER
        // =====================================================

        if (
            active_layer < MAX_LAYERS
        ) begin


            // =================================================
            // LANE 0
            // =================================================

            if (
                (filter_base < MAX_OUTPUT_CHANNELS) &&
                (channel_index < MAX_INPUT_CHANNELS)
            ) begin

                f0_k00 =
                    weight_mem
                    [active_layer]
                    [filter_base]
                    [channel_index]
                    [0];

                f0_k01 =
                    weight_mem
                    [active_layer]
                    [filter_base]
                    [channel_index]
                    [1];

                f0_k02 =
                    weight_mem
                    [active_layer]
                    [filter_base]
                    [channel_index]
                    [2];


                f0_k10 =
                    weight_mem
                    [active_layer]
                    [filter_base]
                    [channel_index]
                    [3];

                f0_k11 =
                    weight_mem
                    [active_layer]
                    [filter_base]
                    [channel_index]
                    [4];

                f0_k12 =
                    weight_mem
                    [active_layer]
                    [filter_base]
                    [channel_index]
                    [5];


                f0_k20 =
                    weight_mem
                    [active_layer]
                    [filter_base]
                    [channel_index]
                    [6];

                f0_k21 =
                    weight_mem
                    [active_layer]
                    [filter_base]
                    [channel_index]
                    [7];

                f0_k22 =
                    weight_mem
                    [active_layer]
                    [filter_base]
                    [channel_index]
                    [8];


                bias0 =
                    bias_mem
                    [active_layer]
                    [filter_base];


                quant_shift0 =
                    quant_mem
                    [active_layer]
                    [filter_base];

            end


            // =================================================
            // LANE 1
            // =================================================

            if (
                ((filter_base + 1) < MAX_OUTPUT_CHANNELS) &&
                (channel_index < MAX_INPUT_CHANNELS)
            ) begin

                f1_k00 =
                    weight_mem
                    [active_layer]
                    [filter_base + 1]
                    [channel_index]
                    [0];

                f1_k01 =
                    weight_mem
                    [active_layer]
                    [filter_base + 1]
                    [channel_index]
                    [1];

                f1_k02 =
                    weight_mem
                    [active_layer]
                    [filter_base + 1]
                    [channel_index]
                    [2];


                f1_k10 =
                    weight_mem
                    [active_layer]
                    [filter_base + 1]
                    [channel_index]
                    [3];

                f1_k11 =
                    weight_mem
                    [active_layer]
                    [filter_base + 1]
                    [channel_index]
                    [4];

                f1_k12 =
                    weight_mem
                    [active_layer]
                    [filter_base + 1]
                    [channel_index]
                    [5];


                f1_k20 =
                    weight_mem
                    [active_layer]
                    [filter_base + 1]
                    [channel_index]
                    [6];

                f1_k21 =
                    weight_mem
                    [active_layer]
                    [filter_base + 1]
                    [channel_index]
                    [7];

                f1_k22 =
                    weight_mem
                    [active_layer]
                    [filter_base + 1]
                    [channel_index]
                    [8];


                bias1 =
                    bias_mem
                    [active_layer]
                    [filter_base + 1];


                quant_shift1 =
                    quant_mem
                    [active_layer]
                    [filter_base + 1];

            end


            // =================================================
            // LANE 2
            // =================================================

            if (
                ((filter_base + 2) < MAX_OUTPUT_CHANNELS) &&
                (channel_index < MAX_INPUT_CHANNELS)
            ) begin

                f2_k00 =
                    weight_mem
                    [active_layer]
                    [filter_base + 2]
                    [channel_index]
                    [0];

                f2_k01 =
                    weight_mem
                    [active_layer]
                    [filter_base + 2]
                    [channel_index]
                    [1];

                f2_k02 =
                    weight_mem
                    [active_layer]
                    [filter_base + 2]
                    [channel_index]
                    [2];


                f2_k10 =
                    weight_mem
                    [active_layer]
                    [filter_base + 2]
                    [channel_index]
                    [3];

                f2_k11 =
                    weight_mem
                    [active_layer]
                    [filter_base + 2]
                    [channel_index]
                    [4];

                f2_k12 =
                    weight_mem
                    [active_layer]
                    [filter_base + 2]
                    [channel_index]
                    [5];


                f2_k20 =
                    weight_mem
                    [active_layer]
                    [filter_base + 2]
                    [channel_index]
                    [6];

                f2_k21 =
                    weight_mem
                    [active_layer]
                    [filter_base + 2]
                    [channel_index]
                    [7];

                f2_k22 =
                    weight_mem
                    [active_layer]
                    [filter_base + 2]
                    [channel_index]
                    [8];


                bias2 =
                    bias_mem
                    [active_layer]
                    [filter_base + 2];


                quant_shift2 =
                    quant_mem
                    [active_layer]
                    [filter_base + 2];

            end


            // =================================================
            // LANE 3
            // =================================================

            if (
                ((filter_base + 3) < MAX_OUTPUT_CHANNELS) &&
                (channel_index < MAX_INPUT_CHANNELS)
            ) begin

                f3_k00 =
                    weight_mem
                    [active_layer]
                    [filter_base + 3]
                    [channel_index]
                    [0];

                f3_k01 =
                    weight_mem
                    [active_layer]
                    [filter_base + 3]
                    [channel_index]
                    [1];

                f3_k02 =
                    weight_mem
                    [active_layer]
                    [filter_base + 3]
                    [channel_index]
                    [2];


                f3_k10 =
                    weight_mem
                    [active_layer]
                    [filter_base + 3]
                    [channel_index]
                    [3];

                f3_k11 =
                    weight_mem
                    [active_layer]
                    [filter_base + 3]
                    [channel_index]
                    [4];

                f3_k12 =
                    weight_mem
                    [active_layer]
                    [filter_base + 3]
                    [channel_index]
                    [5];


                f3_k20 =
                    weight_mem
                    [active_layer]
                    [filter_base + 3]
                    [channel_index]
                    [6];

                f3_k21 =
                    weight_mem
                    [active_layer]
                    [filter_base + 3]
                    [channel_index]
                    [7];

                f3_k22 =
                    weight_mem
                    [active_layer]
                    [filter_base + 3]
                    [channel_index]
                    [8];


                bias3 =
                    bias_mem
                    [active_layer]
                    [filter_base + 3];


                quant_shift3 =
                    quant_mem
                    [active_layer]
                    [filter_base + 3];

            end

        end

    end


endmodule

module control_unit (

    input  logic [6:0] opcode,
    input  logic [2:0] funct3,
    input  logic       funct7_bit5,

    output logic       reg_write,
    output logic       alu_src,

    output logic       mem_read,
    output logic       mem_write,

    output logic       mem_to_reg,

    output logic       branch,
    output logic       jump,
    output logic       jalr,

    // NEW
    output logic       lui,

    output logic [3:0] alu_control

);


    always_comb begin

        // =====================================================
        // DEFAULT VALUES
        // =====================================================

        reg_write   = 1'b0;
        alu_src     = 1'b0;

        mem_read    = 1'b0;
        mem_write   = 1'b0;

        mem_to_reg  = 1'b0;

        branch      = 1'b0;
        jump        = 1'b0;
        jalr        = 1'b0;

        lui         = 1'b0;

        // ADD
        alu_control = 4'b0000;


        case (opcode)

            // =================================================
            // R-TYPE
            // =================================================

            7'b0110011: begin

                reg_write = 1'b1;
                alu_src   = 1'b0;

                case (funct3)

                    // ADD / SUB
                    3'b000: begin

                        if (funct7_bit5)
                            alu_control = 4'b0001;   // SUB
                        else
                            alu_control = 4'b0000;   // ADD

                    end


                    // AND
                    3'b111:
                        alu_control = 4'b0010;


                    // OR
                    3'b110:
                        alu_control = 4'b0011;


                    // XOR
                    3'b100:
                        alu_control = 4'b0100;


                    // SLT
                    3'b010:
                        alu_control = 4'b0101;


                    // SLL
                    3'b001:
                        alu_control = 4'b0110;


                    // SRL / SRA
                    3'b101: begin

                        if (funct7_bit5)
                            alu_control = 4'b1000;   // SRA
                        else
                            alu_control = 4'b0111;   // SRL

                    end


                    default:
                        alu_control = 4'b0000;

                endcase

            end


            // =================================================
            // ADDI
            // =================================================

            7'b0010011: begin

                reg_write   = 1'b1;
                alu_src     = 1'b1;
                alu_control = 4'b0000;

            end


            // =================================================
            // LW
            // address = rs1 + immediate
            // =================================================

            7'b0000011: begin

                reg_write   = 1'b1;
                alu_src     = 1'b1;

                mem_read    = 1'b1;
                mem_to_reg  = 1'b1;

                alu_control = 4'b0000;

            end


            // =================================================
            // SW
            // address = rs1 + immediate
            // =================================================

            7'b0100011: begin

                alu_src     = 1'b1;

                mem_write   = 1'b1;

                alu_control = 4'b0000;

            end


            // =================================================
            // BRANCH
            // BEQ / BNE handled in branch_jump_logic
            // =================================================

            7'b1100011: begin

                branch      = 1'b1;
                alu_src     = 1'b0;

                alu_control = 4'b0001;

            end


            // =================================================
            // JAL
            // =================================================

            7'b1101111: begin

                reg_write = 1'b1;

                jump      = 1'b1;
                jalr      = 1'b0;

            end


            // =================================================
            // JALR
            // =================================================

            7'b1100111: begin

                reg_write = 1'b1;

                jump      = 1'b1;
                jalr      = 1'b1;

                alu_src   = 1'b1;

                alu_control = 4'b0000;

            end


            // =================================================
            // LUI
            //
            // rd = immediate
            //
            // We achieve this using:
            //
            // operand A = 0
            // operand B = U-type immediate
            // ALU = ADD
            // =================================================

            7'b0110111: begin

                reg_write   = 1'b1;

                alu_src     = 1'b1;

                lui         = 1'b1;

                alu_control = 4'b0000;

            end


            default: begin

                // keep defaults

            end

        endcase

    end

endmodule

module conv3x3_engine (

    input  logic clk,
    input  logic reset,

    input  logic window_valid,

    input  logic signed [7:0] w00,
    input  logic signed [7:0] w01,
    input  logic signed [7:0] w02,

    input  logic signed [7:0] w10,
    input  logic signed [7:0] w11,
    input  logic signed [7:0] w12,

    input  logic signed [7:0] w20,
    input  logic signed [7:0] w21,
    input  logic signed [7:0] w22,

    input  logic signed [7:0] k00,
    input  logic signed [7:0] k01,
    input  logic signed [7:0] k02,

    input  logic signed [7:0] k10,
    input  logic signed [7:0] k11,
    input  logic signed [7:0] k12,

    input  logic signed [7:0] k20,
    input  logic signed [7:0] k21,
    input  logic signed [7:0] k22,

    output logic signed [31:0] result,
    output logic               result_valid

);

    // 8-bit x 8-bit = 16-bit signed products
    logic signed [15:0] p0, p1, p2;
    logic signed [15:0] p3, p4, p5;
    logic signed [15:0] p6, p7, p8;

    // Explicit 32-bit sign-extended products
    logic signed [31:0] p0_ext, p1_ext, p2_ext;
    logic signed [31:0] p3_ext, p4_ext, p5_ext;
    logic signed [31:0] p6_ext, p7_ext, p8_ext;

    logic signed [31:0] sum_comb;


    always_comb begin

        p0 = w00 * k00;
        p1 = w01 * k01;
        p2 = w02 * k02;

        p3 = w10 * k10;
        p4 = w11 * k11;
        p5 = w12 * k12;

        p6 = w20 * k20;
        p7 = w21 * k21;
        p8 = w22 * k22;


        // Explicit sign extension prevents accidental
        // truncation during chained additions.

        p0_ext = {{16{p0[15]}}, p0};
        p1_ext = {{16{p1[15]}}, p1};
        p2_ext = {{16{p2[15]}}, p2};

        p3_ext = {{16{p3[15]}}, p3};
        p4_ext = {{16{p4[15]}}, p4};
        p5_ext = {{16{p5[15]}}, p5};

        p6_ext = {{16{p6[15]}}, p6};
        p7_ext = {{16{p7[15]}}, p7};
        p8_ext = {{16{p8[15]}}, p8};


        sum_comb =
            p0_ext +
            p1_ext +
            p2_ext +
            p3_ext +
            p4_ext +
            p5_ext +
            p6_ext +
            p7_ext +
            p8_ext;

    end


    always_ff @(posedge clk) begin

        if (reset) begin

            result       <= 32'sd0;
            result_valid <= 1'b0;

        end

        else begin

            result_valid <= window_valid;

            if (window_valid)
                result <= sum_comb;

        end

    end

endmodule

module data_memory #(
    parameter integer MEM_DEPTH = 262144
)(
    input logic clk,

    // =========================================================
    // CPU PORT
    // =========================================================

    input  logic        cpu_mem_read,
    input  logic        cpu_mem_write,

    input  logic [31:0] cpu_address,
    input  logic [31:0] cpu_write_data,

    output logic [31:0] cpu_read_data,


    // =========================================================
    // DMA READ PORT
    // =========================================================

    input  logic        dma_mem_read_req,
    input  logic [31:0] dma_mem_read_address,

    output logic [31:0] dma_mem_read_data,
    output logic        dma_mem_read_valid,


    // =========================================================
    // DMA WRITE PORT
    // =========================================================

    input  logic        dma_mem_write_req,
    input  logic [31:0] dma_mem_write_address,
    input  logic [31:0] dma_mem_write_data
);


    // =========================================================
    // ADDRESS WIDTH
    //
    // MEM_DEPTH = 16384 words
    //
    // log2(16384) = 14 address bits
    //
    // Since addresses are byte addresses and each word is
    // 4 bytes, bits [1:0] are discarded.
    //
    // Therefore for MEM_DEPTH=16384:
    //
    // word index = address[15:2]
    // =========================================================

    localparam integer ADDR_BITS =
        $clog2(MEM_DEPTH);


    // =========================================================
    // MEMORY
    // =========================================================

    logic [31:0] memory [0:MEM_DEPTH-1];


    integer i;


    // =========================================================
    // WORD INDEX
    // =========================================================

    logic [ADDR_BITS-1:0] cpu_word_index;
    logic [ADDR_BITS-1:0] dma_read_word_index;
    logic [ADDR_BITS-1:0] dma_write_word_index;


    assign cpu_word_index =
        cpu_address[ADDR_BITS+1:2];


    assign dma_read_word_index =
        dma_mem_read_address[ADDR_BITS+1:2];


    assign dma_write_word_index =
        dma_mem_write_address[ADDR_BITS+1:2];


    // =========================================================
    // INITIALIZE MEMORY
    // =========================================================

    initial begin

        for (
            i = 0;
            i < MEM_DEPTH;
            i = i + 1
        ) begin

            memory[i] =
                32'd0;

        end

    end


    // =========================================================
    // CPU READ
    //
    // Combinational read
    // =========================================================

    always_comb begin

        cpu_read_data =
            32'd0;


        if (cpu_mem_read) begin

            if (
                (cpu_address >> 2)
                <
                MEM_DEPTH
            ) begin

                cpu_read_data =
                    memory[
                        cpu_word_index
                    ];

            end

            else begin

                cpu_read_data =
                    32'd0;

            end

        end

    end


    // =========================================================
    // DMA READ
    //
    // Registered one-cycle response
    // =========================================================

    always_ff @(posedge clk) begin

        dma_mem_read_valid <=
            1'b0;


        if (dma_mem_read_req) begin

            if (
                (dma_mem_read_address >> 2)
                <
                MEM_DEPTH
            ) begin

                dma_mem_read_data <=
                    memory[
                        dma_read_word_index
                    ];

            end

            else begin

                dma_mem_read_data <=
                    32'd0;

            end


            dma_mem_read_valid <=
                1'b1;

        end

    end


    // =========================================================
    // CPU WRITE
    // =========================================================

    always_ff @(posedge clk) begin

        if (cpu_mem_write) begin

            if (
                (cpu_address >> 2)
                <
                MEM_DEPTH
            ) begin

                memory[
                    cpu_word_index
                ] <=
                    cpu_write_data;

            end

        end

    end


    // =========================================================
    // DMA / CNN WRITE
    // =========================================================

    always_ff @(posedge clk) begin

        if (dma_mem_write_req) begin

            if (
                (dma_mem_write_address >> 2)
                <
                MEM_DEPTH
            ) begin

                memory[
                    dma_write_word_index
                ] <=
                    dma_mem_write_data;

            end

        end

    end


endmodule

module image_buffer #(

    parameter IMAGE_WIDTH  = 8,
    parameter IMAGE_HEIGHT = 8,
    parameter ADDR_WIDTH   = 6

)(

    input  logic                  clk,
    input  logic                  rst,

    // =========================================================
    // WRITE PORT
    // Used later by CPU/UART to load image pixels
    // =========================================================

    input  logic                  wr_en,
    input  logic [ADDR_WIDTH-1:0] wr_addr,
    input  logic signed [7:0]     wr_data,


    // =========================================================
    // READ PORT
    // Used by sliding-window generator
    // =========================================================

    input  logic [ADDR_WIDTH-1:0] rd_addr,
    output logic signed [7:0]     rd_data

);


    localparam DEPTH = IMAGE_WIDTH * IMAGE_HEIGHT;


    // =========================================================
    // IMAGE MEMORY
    //
    // For default 8x8 image:
    // 64 locations x 8 bits
    // =========================================================

    logic signed [7:0] memory [0:DEPTH-1];


    // =========================================================
    // WRITE
    // =========================================================

    always_ff @(posedge clk) begin

        if (wr_en) begin

            memory[wr_addr] <= wr_data;

        end

    end


    // =========================================================
    // ASYNCHRONOUS READ
    //
    // rd_addr is generated by sliding_window_handshake.
    // The pixel at that address is immediately available.
    // =========================================================

    always_comb begin

        if (rd_addr < DEPTH)
            rd_data = memory[rd_addr];

        else
            rd_data = 8'sd0;

    end


endmodule

module immediate_generator (

    input  logic [31:0] instruction,
    output logic [31:0] immediate

);

    logic [6:0] opcode;

    always_comb begin

        opcode    = instruction[6:0];
        immediate = 32'd0;

        case (opcode)

            // =================================================
            // I-TYPE
            // ADDI / LW / JALR
            // =================================================

            7'b0010011,     // ADDI
            7'b0000011,     // LW
            7'b1100111: begin   // JALR

                immediate =
                    {{20{instruction[31]}},
                     instruction[31:20]};

            end


            // =================================================
            // S-TYPE
            // SW
            // =================================================

            7'b0100011: begin

                immediate =
                    {{20{instruction[31]}},
                     instruction[31:25],
                     instruction[11:7]};

            end


            // =================================================
            // B-TYPE
            // BEQ / BNE
            // =================================================

            7'b1100011: begin

                immediate =
                    {{19{instruction[31]}},
                     instruction[31],
                     instruction[7],
                     instruction[30:25],
                     instruction[11:8],
                     1'b0};

            end


            // =================================================
            // U-TYPE
            // LUI
            //
            // Example:
            //
            // lui x10, 0x40000
            //
            // immediate = 0x40000000
            // =================================================

            7'b0110111: begin

                immediate = {
                    instruction[31:12],
                    12'b0
                };

            end


            // =================================================
            // J-TYPE
            // JAL
            // =================================================

            7'b1101111: begin

                immediate =
                    {{11{instruction[31]}},
                     instruction[31],
                     instruction[19:12],
                     instruction[20],
                     instruction[30:21],
                     1'b0};

            end


            default: begin

                immediate = 32'd0;

            end

        endcase

    end

endmodule

module instruction_decoder (
    input  logic [31:0] instruction,

    output logic [6:0] opcode,
    output logic [4:0] rd,
    output logic [4:0] rs1,
    output logic [4:0] rs2,
    output logic [2:0] funct3,
    output logic [6:0] funct7,

    output logic [2:0] instr_type
);

    // Instruction type encoding
    localparam TYPE_R = 3'b000;
    localparam TYPE_I = 3'b001;
    localparam TYPE_S = 3'b010;
    localparam TYPE_B = 3'b011;
    localparam TYPE_U = 3'b100;
    localparam TYPE_J = 3'b101;
    localparam TYPE_UNKNOWN = 3'b111;

    always_comb begin

        // Extract standard instruction fields
        opcode = instruction[6:0];
        rd     = instruction[11:7];
        funct3 = instruction[14:12];
        rs1    = instruction[19:15];
        rs2    = instruction[24:20];
        funct7 = instruction[31:25];

        // Determine instruction format
        case (opcode)

            // R-type
            7'b0110011:
                instr_type = TYPE_R;

            // I-type
            7'b0010011,   // ADDI, SLTI, ANDI, ORI, XORI...
            7'b0000011,   // Loads
            7'b1100111:   // JALR
                instr_type = TYPE_I;

            // S-type
            7'b0100011:
                instr_type = TYPE_S;

            // B-type
            7'b1100011:
                instr_type = TYPE_B;

            // U-type
            7'b0110111,   // LUI
            7'b0010111:   // AUIPC
                instr_type = TYPE_U;

            // J-type
            7'b1101111:   // JAL
                instr_type = TYPE_J;

            default:
                instr_type = TYPE_UNKNOWN;

        endcase
    end

endmodule

module instruction_memory (
input  logic [31:0] address,
output logic [31:0] instruction
);

logic [31:0] mem [0:4095];
integer i;

initial begin
    for (i = 0; i < 4096; i = i + 1)
        mem[i] = 32'h00000013; // RISC-V NOP

    // Configure full-resolution input: 320 x 240
    mem[0]  = 32'h40000537; // x10 = 0x40000000 (AI MMIO base)
    mem[1]  = 32'h14000593; // x11 = 320
    mem[2]  = 32'h00B52423; // IMAGE WIDTH = 320
    mem[3]  = 32'h0F000593; // x11 = 240
    mem[4]  = 32'h00B52623; // IMAGE HEIGHT = 240

    // Input image base = 0x00001000
    mem[5]  = 32'h000015B7; // x11 = 0x1000
    mem[6]  = 32'h00B52823; // INPUT_BASE

    // Network configuration
    mem[7]  = 32'h00100593; // x11 = 1 input channel
    mem[8]  = 32'h04B52223; // NETWORK Cin
    mem[9]  = 32'h00200593; // x11 = 2 layers
    mem[10] = 32'h04B52023; // NETWORK NUM_LAYERS

    // Buffer A = 0x00014000
    mem[11] = 32'h000145B7; // x11 = 0x14000
    mem[12] = 32'h04B52423; // BUFFER_A

    // Buffer B = 0x00027000
    mem[13] = 32'h000275B7; // x11 = 0x27000
    mem[14] = 32'h04B52623; // BUFFER_B

    // Model image base = 0x000C0000
    mem[15] = 32'h000C05B7; // x11 = 0xC0000
    mem[16] = 32'h08B52E23; // MODEL_LOAD_BASE

    // Start model loader
    mem[17] = 32'h00100593; // x11 = 1
    mem[18] = 32'h0AB52023; // MODEL_LOAD_CONTROL = START
    mem[19] = 32'h00200693; // x13 = MODEL_LOADER_DONE
    mem[20] = 32'h0A452583; // Read MODEL_LOAD_STATUS
    mem[21] = 32'hFED59EE3; // Poll until MODEL_LOADER_DONE

    // Start CNN
    mem[22] = 32'h00100593; // x11 = 1
    mem[23] = 32'h06B52023; // NETWORK_CONTROL = START
    mem[24] = 32'h00200693; // x13 = NETWORK_DONE
    mem[25] = 32'h06452583; // Read NET_STATUS
    mem[26] = 32'hFED59EE3; // Poll until NET_STATUS == 2

    mem[27] = 32'h0000006F; // HALT
end

always_comb begin
    instruction = mem[address[13:2]];
end

endmodule

module multi_channel_conv_top #(
    parameter integer MAX_WIDTH   = 4096,
    parameter integer MAX_OUTPUTS = 8294400
)(
    input logic clk,
    input logic reset,

    // =========================================================
    // IMAGE / CHANNEL CONFIG
    // =========================================================

    input logic [15:0] image_width,
    input logic [15:0] image_height,

    input logic [15:0] input_channels,

    input logic [15:0] channel_index,
    input logic        channel_start,

    // =========================================================
    // PIXEL STREAM
    // =========================================================

    input logic signed [7:0] pixel_in,
    input logic              pixel_valid,

    // =========================================================
    // CURRENT CHANNEL KERNEL
    // =========================================================

    input logic signed [7:0] k00,
    input logic signed [7:0] k01,
    input logic signed [7:0] k02,

    input logic signed [7:0] k10,
    input logic signed [7:0] k11,
    input logic signed [7:0] k12,

    input logic signed [7:0] k20,
    input logic signed [7:0] k21,
    input logic signed [7:0] k22,

    // =========================================================
    // POSTPROCESS
    // =========================================================

    input logic signed [31:0] bias,
    input logic [4:0]         quant_shift,

    // =========================================================
    // FINAL FEATURE STREAM
    // =========================================================

    output logic signed [7:0] feature_out,
    output logic              feature_valid,

    output logic [31:0]       feature_index
);


    // =========================================================
    // WINDOW SIGNALS
    // =========================================================

    logic signed [7:0] w00, w01, w02;
    logic signed [7:0] w10, w11, w12;
    logic signed [7:0] w20, w21, w22;

    logic window_valid;


    // =========================================================
    // CONVOLUTION SIGNALS
    // =========================================================

    logic signed [31:0] channel_conv_result;
    logic               channel_conv_valid;


    // =========================================================
    // METADATA PIPELINE
    //
    // These registers carry the spatial index and channel tag
    // alongside the convolution pipeline.
    // =========================================================

    logic [15:0] conv_channel_index;
    logic [31:0] conv_output_index;

    logic [31:0] output_index_counter;


    // =========================================================
    // CHANNEL ACCUMULATION
    // =========================================================

    logic signed [31:0] accumulated_result;
    logic               accumulated_valid;


    // =========================================================
    // POSTPROCESS
    // =========================================================

    logic signed [7:0] quantized_feature;
    logic              quantized_valid;


    // =========================================================
    // OUTPUT GEOMETRY
    // =========================================================

    logic [31:0] output_width;
    logic [31:0] output_height;
    logic [31:0] outputs_per_channel;


    always_comb begin

        if (
            (image_width >= 16'd3) &&
            (image_height >= 16'd3)
        ) begin

            output_width =
                image_width - 16'd2;

            output_height =
                image_height - 16'd2;

            outputs_per_channel =
                output_width *
                output_height;

        end

        else begin

            output_width =
                32'd0;

            output_height =
                32'd0;

            outputs_per_channel =
                32'd0;

        end

    end


    // =========================================================
    // STREAMING WINDOW GENERATOR
    // =========================================================

    stream_window_3x3 #(
        .MAX_WIDTH(MAX_WIDTH)
    ) WINDOW_GENERATOR (

        .clk(clk),
        .reset(reset),

        .channel_start(channel_start),

        .image_width(image_width),
        .image_height(image_height),

        .pixel_in(pixel_in),
        .pixel_valid(pixel_valid),

        .w00(w00),
        .w01(w01),
        .w02(w02),

        .w10(w10),
        .w11(w11),
        .w12(w12),

        .w20(w20),
        .w21(w21),
        .w22(w22),

        .window_valid(window_valid)

    );


    // =========================================================
    // OUTPUT INDEX + CHANNEL METADATA
    //
    // IMPORTANT:
    //
    // window_valid represents one spatial convolution window.
    //
    // At that moment we capture:
    //
    //     spatial index
    //     channel number
    //
    // conv3x3_engine registers its result one stage later.
    //
    // Therefore these metadata registers are already perfectly
    // aligned with channel_conv_result/channel_conv_valid.
    //
    // DO NOT add another metadata register stage.
    // =========================================================

    always_ff @(posedge clk) begin

        if (reset) begin

            output_index_counter <=
                32'd0;

            conv_output_index <=
                32'd0;

            conv_channel_index <=
                16'd0;

        end

        else begin

            // New channel means its spatial sequence begins at 0.

            if (channel_start) begin

                output_index_counter <=
                    32'd0;

            end


            if (window_valid) begin

                // ---------------------------------------------
                // Metadata belonging to THIS window
                // ---------------------------------------------

                conv_output_index <=
                    output_index_counter;

                conv_channel_index <=
                    channel_index;


                // ---------------------------------------------
                // Advance spatial index for next window
                // ---------------------------------------------

                if (
                    outputs_per_channel == 32'd0
                ) begin

                    output_index_counter <=
                        32'd0;

                end

                else if (
                    (output_index_counter + 1)
                    >= outputs_per_channel
                ) begin

                    output_index_counter <=
                        32'd0;

                end

                else begin

                    output_index_counter <=
                        output_index_counter + 1'b1;

                end

            end

        end

    end


    // =========================================================
    // 3x3 CONVOLUTION
    // =========================================================

    conv3x3_engine CONVOLUTION_ENGINE (

        .clk(clk),
        .reset(reset),

        .window_valid(window_valid),

        .w00(w00),
        .w01(w01),
        .w02(w02),

        .w10(w10),
        .w11(w11),
        .w12(w12),

        .w20(w20),
        .w21(w21),
        .w22(w22),

        .k00(k00),
        .k01(k01),
        .k02(k02),

        .k10(k10),
        .k11(k11),
        .k12(k12),

        .k20(k20),
        .k21(k21),
        .k22(k22),

        .result(channel_conv_result),
        .result_valid(channel_conv_valid)

    );


    // =========================================================
    // MULTI-CHANNEL ACCUMULATION
    // =========================================================

    channel_sum_buffer #(
        .MAX_OUTPUTS(MAX_OUTPUTS)
    ) CHANNEL_SUM (

        .clk(clk),
        .reset(reset),

        .input_channels(
            input_channels
        ),

        .channel_index(
            conv_channel_index
        ),

        .output_index(
            conv_output_index
        ),

        .channel_result(
            channel_conv_result
        ),

        .channel_valid(
            channel_conv_valid
        ),

        .accumulated_result(
            accumulated_result
        ),

        .accumulated_valid(
            accumulated_valid
        )

    );


    // =========================================================
    // CNN POSTPROCESS
    //
    // accumulated channels
    //          ?
    // bias
    //          ?
    // ReLU
    //          ?
    // requantization
    //          ?
    // INT8 feature
    // =========================================================

    cnn_postprocess POSTPROCESS (

        .accumulator(
            accumulated_result
        ),

        .bias(
            bias
        ),

        .quant_shift(
            quant_shift
        ),

        .valid_in(
            accumulated_valid
        ),

        .feature_out(
            quantized_feature
        ),

        .valid_out(
            quantized_valid
        )

    );


    // =========================================================
    // FINAL FEATURE OUTPUT
    // =========================================================

    always_comb begin

        feature_out =
            quantized_feature;

        feature_valid =
            quantized_valid;

    end


    // =========================================================
    // FINAL FEATURE INDEX
    // =========================================================

    always_ff @(posedge clk) begin

        if (reset) begin

            feature_index <=
                32'd0;

        end

        else if (quantized_valid) begin

            if (
                outputs_per_channel == 32'd0
            ) begin

                feature_index <=
                    32'd0;

            end

            else if (
                (feature_index + 1)
                >= outputs_per_channel
            ) begin

                feature_index <=
                    32'd0;

            end

            else begin

                feature_index <=
                    feature_index + 1'b1;

            end

        end

    end


endmodule

module multi_filter_conv_top #(
    parameter integer MAX_WIDTH   = 4096,
    parameter integer MAX_OUTPUTS = 8294400
)(
    input logic clk,
    input logic reset,

    // =========================================================
    // IMAGE CONFIGURATION
    // =========================================================

    input logic [15:0] image_width,
    input logic [15:0] image_height,

    input logic [15:0] input_channels,
    input logic [15:0] output_channels,


    // =========================================================
    // FILTER CONTROL
    //
    // current_filter tells us which output feature map
    // is currently being calculated.
    // =========================================================

    input logic [15:0] current_filter,
    input logic        filter_start,


    // =========================================================
    // INPUT CHANNEL CONTROL
    // =========================================================

    input logic [15:0] channel_index,
    input logic        channel_start,


    // =========================================================
    // PIXEL STREAM
    // =========================================================

    input logic signed [7:0] pixel_in,
    input logic              pixel_valid,


    // =========================================================
    // CURRENT FILTER + CHANNEL 3x3 WEIGHTS
    //
    // External weight controller will eventually provide:
    //
    // W[filter][channel][3][3]
    //
    // For now we directly provide the active 3x3 kernel.
    // =========================================================

    input logic signed [7:0] k00,
    input logic signed [7:0] k01,
    input logic signed [7:0] k02,

    input logic signed [7:0] k10,
    input logic signed [7:0] k11,
    input logic signed [7:0] k12,

    input logic signed [7:0] k20,
    input logic signed [7:0] k21,
    input logic signed [7:0] k22,


    // =========================================================
    // CURRENT FILTER POSTPROCESS PARAMETERS
    //
    // Each output filter eventually has its own:
    //
    // bias[filter]
    // quant_shift[filter]
    // =========================================================

    input logic signed [31:0] bias,
    input logic [4:0]         quant_shift,


    // =========================================================
    // FEATURE OUTPUT
    // =========================================================

    output logic signed [7:0] feature_out,
    output logic              feature_valid,

    // Spatial position inside feature map
    output logic [31:0]       feature_index,

    // Which output channel/filter this belongs to
    output logic [15:0]       feature_channel
);


    // =========================================================
    // INTERNAL FEATURE STREAM
    // =========================================================

    logic signed [7:0] inner_feature;
    logic              inner_feature_valid;

    logic [31:0]       inner_feature_index;


    // =========================================================
    // FILTER TAG
    //
    // current_filter remains constant while an entire
    // filter is being evaluated.
    // =========================================================

    logic [15:0] active_filter;


    always_ff @(posedge clk) begin

        if (reset) begin

            active_filter <=
                16'd0;

        end

        else if (filter_start) begin

            active_filter <=
                current_filter;

        end

    end


    // =========================================================
    // MULTI-CHANNEL CONVOLUTION ENGINE
    //
    // One filter is processed at a time.
    // =========================================================

    multi_channel_conv_top #(

        .MAX_WIDTH(
            MAX_WIDTH
        ),

        .MAX_OUTPUTS(
            MAX_OUTPUTS
        )

    ) MULTI_CHANNEL_ENGINE (

        .clk(clk),
        .reset(reset),

        .image_width(
            image_width
        ),

        .image_height(
            image_height
        ),

        .input_channels(
            input_channels
        ),

        .channel_index(
            channel_index
        ),

        .channel_start(
            channel_start
        ),

        .pixel_in(
            pixel_in
        ),

        .pixel_valid(
            pixel_valid
        ),


        // -----------------------------------------------------
        // Current filter/current channel weights
        // -----------------------------------------------------

        .k00(k00),
        .k01(k01),
        .k02(k02),

        .k10(k10),
        .k11(k11),
        .k12(k12),

        .k20(k20),
        .k21(k21),
        .k22(k22),


        // -----------------------------------------------------
        // Per-filter postprocessing
        // -----------------------------------------------------

        .bias(
            bias
        ),

        .quant_shift(
            quant_shift
        ),


        // -----------------------------------------------------
        // Feature output
        // -----------------------------------------------------

        .feature_out(
            inner_feature
        ),

        .feature_valid(
            inner_feature_valid
        ),

        .feature_index(
            inner_feature_index
        )

    );


    // =========================================================
    // OUTPUT
    // =========================================================

    always_comb begin

        feature_out =
            inner_feature;

        feature_valid =
            inner_feature_valid;

        feature_index =
            inner_feature_index;

        feature_channel =
            active_filter;

    end


endmodule

module nova1_ai_mmio #(
    parameter integer MAX_WIDTH = 4096
)(
    input logic clk,
    input logic reset,

    // =========================================================
    // CPU / MMIO INTERFACE
    // =========================================================

    input  logic        accel_read,
    input  logic        accel_write,

    input  logic [31:0] address,
    input  logic [31:0] write_data,

    output logic [31:0] read_data,


    // =========================================================
    // LEGACY PIXEL STREAM
    // =========================================================

    input logic signed [7:0] pixel_in,
    input logic              pixel_valid,


    // =========================================================
    // LEGACY FEATURE STREAM
    // =========================================================

    output logic signed [31:0] feature_out,
    output logic               feature_valid,


    // =========================================================
    // COMMON IMAGE CONFIG
    // =========================================================

    output logic [31:0] input_base_address,
    output logic [31:0] output_base_address,

    output logic [15:0] image_width,
    output logic [15:0] image_height,

    output logic dma_start,


    // =========================================================
    // LEGACY STATUS
    // =========================================================

    output logic busy,
    output logic done,


    // =========================================================
    // CNN NETWORK CONFIG
    // =========================================================

    output logic [15:0] network_num_layers,
    output logic [15:0] network_input_channels,

    output logic [31:0] network_buffer_a_base,
    output logic [31:0] network_buffer_b_base,

    output logic network_start,


    // =========================================================
    // NETWORK LAYER DESCRIPTOR PROGRAMMING
    // =========================================================

    output logic        layer_descriptor_wr_en,
    output logic [15:0] layer_descriptor_wr_index,
    output logic [15:0] layer_descriptor_wr_cout,
    output logic [1:0]  layer_descriptor_wr_stride,


    // =========================================================
    // MODEL LAYER SELECTOR
    //
    // Selects which layer receives subsequent:
    //
    // weight
    // bias
    // quant
    //
    // programming operations.
    // =========================================================

    output logic [15:0] network_weight_wr_layer,


    // =========================================================
    // NETWORK WEIGHT PROGRAMMING
    // =========================================================

    output logic        network_weight_wr_en,
    output logic [15:0] network_weight_wr_filter,
    output logic [15:0] network_weight_wr_channel,
    output logic [3:0]  network_weight_wr_tap,
    output logic signed [7:0] network_weight_wr_data,


    // =========================================================
    // NETWORK BIAS PROGRAMMING
    // =========================================================

    output logic network_bias_wr_en,

    output logic [15:0] network_bias_wr_filter,
    output logic signed [31:0] network_bias_wr_data,


    // =========================================================
    // NETWORK QUANT PROGRAMMING
    // =========================================================

    output logic network_quant_wr_en,

    output logic [15:0] network_quant_wr_filter,
    output logic [4:0]  network_quant_wr_data,


    // =========================================================
    // NETWORK STATUS INPUT
    // =========================================================

    input logic network_busy,
    input logic network_done,

    // =========================================================
    // MODEL LOADER CONTROL / STATUS
    // =========================================================

    output logic [31:0] model_load_base,
    output logic        model_load_start,

    input logic model_load_busy,
    input logic model_load_done,
    input logic model_load_error
);


    // =========================================================
    // LEGACY MMIO MAP
    // =========================================================

    localparam logic [31:0] CONTROL_ADDR =
        32'h4000_0000;

    localparam logic [31:0] STATUS_ADDR =
        32'h4000_0004;

    localparam logic [31:0] WIDTH_ADDR =
        32'h4000_0008;

    localparam logic [31:0] HEIGHT_ADDR =
        32'h4000_000C;

    localparam logic [31:0] INPUT_BASE_ADDR =
        32'h4000_0010;

    localparam logic [31:0] OUTPUT_BASE_ADDR =
        32'h4000_0014;


    localparam logic [31:0] WEIGHTS03_ADDR =
        32'h4000_0020;

    localparam logic [31:0] WEIGHTS47_ADDR =
        32'h4000_0024;

    localparam logic [31:0] WEIGHT8_ADDR =
        32'h4000_0028;


    localparam logic [31:0] BIAS_ADDR =
        32'h4000_002C;

    localparam logic [31:0] QUANT_SHIFT_ADDR =
        32'h4000_0030;


    // =========================================================
    // NETWORK CONFIG
    // =========================================================

    localparam logic [31:0] NET_NUM_LAYERS_ADDR =
        32'h4000_0040;

    localparam logic [31:0] NET_CIN_ADDR =
        32'h4000_0044;

    localparam logic [31:0] NET_BUFFER_A_ADDR =
        32'h4000_0048;

    localparam logic [31:0] NET_BUFFER_B_ADDR =
        32'h4000_004C;


    // =========================================================
    // LAYER DESCRIPTOR PROGRAMMING
    // =========================================================

    localparam logic [31:0] LAYER_INDEX_ADDR =
        32'h4000_0050;

    localparam logic [31:0] LAYER_COUT_ADDR =
        32'h4000_0054;

    localparam logic [31:0] LAYER_STRIDE_ADDR =
        32'h4000_0058;

    localparam logic [31:0] LAYER_COMMIT_ADDR =
        32'h4000_005C;


    // =========================================================
    // NETWORK CONTROL / STATUS
    // =========================================================

    localparam logic [31:0] NET_CONTROL_ADDR =
        32'h4000_0060;

    localparam logic [31:0] NET_STATUS_ADDR =
        32'h4000_0064;


    // =========================================================
    // MODEL LAYER SELECTION
    //
    // CPU writes the model layer here before loading
    // weights / bias / quantization for that layer.
    // =========================================================

    localparam logic [31:0] MODEL_LAYER_ADDR =
        32'h4000_0068;


    // =========================================================
    // MODEL WEIGHT PROGRAMMING
    // =========================================================

    localparam logic [31:0] MODEL_WEIGHT_FILTER_ADDR =
        32'h4000_0070;

    localparam logic [31:0] MODEL_WEIGHT_CHANNEL_ADDR =
        32'h4000_0074;

    localparam logic [31:0] MODEL_WEIGHT_TAP_ADDR =
        32'h4000_0078;

    localparam logic [31:0] MODEL_WEIGHT_DATA_ADDR =
        32'h4000_007C;

    localparam logic [31:0] MODEL_WEIGHT_COMMIT_ADDR =
        32'h4000_0080;


    // =========================================================
    // MODEL BIAS PROGRAMMING
    // =========================================================

    localparam logic [31:0] MODEL_BIAS_FILTER_ADDR =
        32'h4000_0084;

    localparam logic [31:0] MODEL_BIAS_DATA_ADDR =
        32'h4000_0088;

    localparam logic [31:0] MODEL_BIAS_COMMIT_ADDR =
        32'h4000_008C;


    // =========================================================
    // MODEL QUANT PROGRAMMING
    // =========================================================

    localparam logic [31:0] MODEL_QUANT_FILTER_ADDR =
        32'h4000_0090;

    localparam logic [31:0] MODEL_QUANT_DATA_ADDR =
        32'h4000_0094;

    localparam logic [31:0] MODEL_QUANT_COMMIT_ADDR =
        32'h4000_0098;


    // =========================================================
    // MODEL LOADER
    // =========================================================

    localparam logic [31:0] MODEL_LOAD_BASE_ADDR =
        32'h4000_009C;

    localparam logic [31:0] MODEL_LOAD_CONTROL_ADDR =
        32'h4000_00A0;

    localparam logic [31:0] MODEL_LOAD_STATUS_ADDR =
        32'h4000_00A4;


    // =========================================================
    // LEGACY KERNEL
    // =========================================================

    logic signed [7:0] k00;
    logic signed [7:0] k01;
    logic signed [7:0] k02;

    logic signed [7:0] k10;
    logic signed [7:0] k11;
    logic signed [7:0] k12;

    logic signed [7:0] k20;
    logic signed [7:0] k21;
    logic signed [7:0] k22;


    logic signed [31:0] bias;

    logic [4:0] quant_shift;


    // =========================================================
    // LEGACY OUTPUT COUNT
    // =========================================================

    logic [31:0] expected_outputs;

    logic [31:0] output_count;


    // =========================================================
    // DESCRIPTOR STAGING
    // =========================================================

    logic [15:0] layer_program_index;

    logic [15:0] layer_program_cout;

    logic [1:0] layer_program_stride;


    // =========================================================
    // MODEL LAYER STAGING
    // =========================================================

    logic [15:0] model_layer;


    // =========================================================
    // MODEL WEIGHT STAGING
    // =========================================================

    logic [15:0] model_weight_filter;

    logic [15:0] model_weight_channel;

    logic [3:0] model_weight_tap;

    logic signed [7:0] model_weight_data;


    // =========================================================
    // MODEL BIAS STAGING
    // =========================================================

    logic [15:0] model_bias_filter;

    logic signed [31:0] model_bias_data;


    // =========================================================
    // MODEL QUANT STAGING
    // =========================================================

    logic [15:0] model_quant_filter;

    logic [4:0] model_quant_data;




    // =========================================================
    // LEGACY OUTPUT GEOMETRY
    // =========================================================

    always_comb begin

        if (
            (image_width >= 16'd3) &&
            (image_height >= 16'd3)
        ) begin

            expected_outputs =

                (image_width - 16'd2)

                *

                (image_height - 16'd2);

        end

        else begin

            expected_outputs =
                32'd0;

        end

    end


    // =========================================================
    // LEGACY WHOLE IMAGE ACCELERATOR
    // =========================================================

    whole_image_accelerator #(

        .MAX_WIDTH(
            MAX_WIDTH
        )

    ) ACCELERATOR (

        .clk(
            clk
        ),

        .reset(
            reset
        ),

        .image_width(
            image_width
        ),

        .image_height(
            image_height
        ),

        .pixel_in(
            pixel_in
        ),

        .pixel_valid(
            pixel_valid
        ),

        .k00(
            k00
        ),

        .k01(
            k01
        ),

        .k02(
            k02
        ),

        .k10(
            k10
        ),

        .k11(
            k11
        ),

        .k12(
            k12
        ),

        .k20(
            k20
        ),

        .k21(
            k21
        ),

        .k22(
            k22
        ),

        .bias(
            bias
        ),

        .quant_shift(
            quant_shift
        ),

        .feature_out(
            feature_out
        ),

        .feature_valid(
            feature_valid
        )

    );


    // =========================================================
    // WRITE / CONTROL
    // =========================================================

    always_ff @(posedge clk) begin

        // =====================================================
        // RESET
        // =====================================================

        if (reset) begin

            image_width <=
                16'd8;

            image_height <=
                16'd8;


            input_base_address <=
                32'd0;

            output_base_address <=
                32'd0;


            // =================================================
            // LEGACY IDENTITY KERNEL
            // =================================================

            k00 <=
                8'sd0;

            k01 <=
                8'sd0;

            k02 <=
                8'sd0;


            k10 <=
                8'sd0;

            k11 <=
                8'sd1;

            k12 <=
                8'sd0;


            k20 <=
                8'sd0;

            k21 <=
                8'sd0;

            k22 <=
                8'sd0;


            bias <=
                32'sd0;

            quant_shift <=
                5'd0;


            busy <=
                1'b0;

            done <=
                1'b0;

            dma_start <=
                1'b0;

            output_count <=
                32'd0;


            // =================================================
            // NETWORK CONFIG DEFAULTS
            // =================================================

            network_num_layers <=
                16'd2;

            network_input_channels <=
                16'd3;

            network_buffer_a_base <=
                32'h0000_4000;

            network_buffer_b_base <=
                32'h0000_8000;

            network_start <=
                1'b0;


            // =================================================
            // DESCRIPTOR DEFAULTS
            // =================================================

            layer_program_index <=
                16'd0;

            layer_program_cout <=
                16'd4;

            layer_program_stride <=
                2'd1;


            layer_descriptor_wr_en <=
                1'b0;

            layer_descriptor_wr_index <=
                16'd0;

            layer_descriptor_wr_cout <=
                16'd0;

            layer_descriptor_wr_stride <=
                2'd1;


            // =================================================
            // MODEL LAYER DEFAULT
            // =================================================

            model_layer <=
                16'd0;

            network_weight_wr_layer <=
                16'd0;


            // =================================================
            // MODEL WEIGHT DEFAULTS
            // =================================================

            model_weight_filter <=
                16'd0;

            model_weight_channel <=
                16'd0;

            model_weight_tap <=
                4'd0;

            model_weight_data <=
                8'sd0;


            network_weight_wr_en <=
                1'b0;

            network_weight_wr_filter <=
                16'd0;

            network_weight_wr_channel <=
                16'd0;

            network_weight_wr_tap <=
                4'd0;

            network_weight_wr_data <=
                8'sd0;


            // =================================================
            // MODEL BIAS DEFAULTS
            // =================================================

            model_bias_filter <=
                16'd0;

            model_bias_data <=
                32'sd0;


            network_bias_wr_en <=
                1'b0;

            network_bias_wr_filter <=
                16'd0;

            network_bias_wr_data <=
                32'sd0;


            // =================================================
            // MODEL QUANT DEFAULTS
            // =================================================

            model_quant_filter <=
                16'd0;

            model_quant_data <=
                5'd0;


            network_quant_wr_en <=
                1'b0;

            network_quant_wr_filter <=
                16'd0;

            network_quant_wr_data <=
                5'd0;

            model_load_base <=
                32'd0;

            model_load_start <=
                1'b0;

        end


        // =====================================================
        // NORMAL OPERATION
        // =====================================================

        else begin

            // =================================================
            // DEFAULT ONE-CYCLE PULSES
            // =================================================

            dma_start <=
                1'b0;

            network_start <=
                1'b0;

            layer_descriptor_wr_en <=
                1'b0;

            network_weight_wr_en <=
                1'b0;

            network_bias_wr_en <=
                1'b0;

            network_quant_wr_en <=
                1'b0;

            model_load_start <=
                1'b0;


            // =================================================
            // MMIO WRITES
            // =================================================

            if (accel_write) begin

                case (address)


                    // =========================================
                    // IMAGE WIDTH
                    // =========================================

                    WIDTH_ADDR: begin

                        image_width <=
                            write_data[15:0];

                    end


                    // =========================================
                    // IMAGE HEIGHT
                    // =========================================

                    HEIGHT_ADDR: begin

                        image_height <=
                            write_data[15:0];

                    end


                    // =========================================
                    // INPUT BASE
                    // =========================================

                    INPUT_BASE_ADDR: begin

                        input_base_address <=
                            write_data;

                    end


                    // =========================================
                    // LEGACY OUTPUT BASE
                    // =========================================

                    OUTPUT_BASE_ADDR: begin

                        output_base_address <=
                            write_data;

                    end


                    // =================================================
                    // LEGACY MODEL
                    // =================================================

                    WEIGHTS03_ADDR: begin

                        k00 <=
                            write_data[7:0];

                        k01 <=
                            write_data[15:8];

                        k02 <=
                            write_data[23:16];

                        k10 <=
                            write_data[31:24];

                    end


                    WEIGHTS47_ADDR: begin

                        k11 <=
                            write_data[7:0];

                        k12 <=
                            write_data[15:8];

                        k20 <=
                            write_data[23:16];

                        k21 <=
                            write_data[31:24];

                    end


                    WEIGHT8_ADDR: begin

                        k22 <=
                            write_data[7:0];

                    end


                    BIAS_ADDR: begin

                        bias <=
                            $signed(write_data);

                    end


                    QUANT_SHIFT_ADDR: begin

                        quant_shift <=
                            write_data[4:0];

                    end


                    CONTROL_ADDR: begin

                        if (
                            write_data[0] &&
                            !busy
                        ) begin

                            busy <=
                                1'b1;

                            done <=
                                1'b0;

                            output_count <=
                                32'd0;

                            dma_start <=
                                1'b1;

                        end

                    end


                    // =================================================
                    // NETWORK CONFIG
                    // =================================================

                    NET_NUM_LAYERS_ADDR: begin

                        network_num_layers <=
                            write_data[15:0];

                    end


                    NET_CIN_ADDR: begin

                        network_input_channels <=
                            write_data[15:0];

                    end


                    NET_BUFFER_A_ADDR: begin

                        network_buffer_a_base <=
                            write_data;

                    end


                    NET_BUFFER_B_ADDR: begin

                        network_buffer_b_base <=
                            write_data;

                    end


                    // =================================================
                    // DESCRIPTOR PROGRAMMING
                    // =================================================

                    LAYER_INDEX_ADDR: begin

                        layer_program_index <=
                            write_data[15:0];

                    end


                    LAYER_COUT_ADDR: begin

                        layer_program_cout <=
                            write_data[15:0];

                    end


                    LAYER_STRIDE_ADDR: begin

                        if (
                            write_data[1:0] == 2'd2
                        ) begin

                            layer_program_stride <=
                                2'd2;

                        end

                        else begin

                            layer_program_stride <=
                                2'd1;

                        end

                    end


                    LAYER_COMMIT_ADDR: begin

                        if (
                            write_data[0] &&
                            !network_busy
                        ) begin

                            layer_descriptor_wr_index <=
                                layer_program_index;

                            layer_descriptor_wr_cout <=
                                layer_program_cout;

                            layer_descriptor_wr_stride <=
                                layer_program_stride;

                            layer_descriptor_wr_en <=
                                1'b1;

                        end

                    end


                    // =================================================
                    // NETWORK START
                    // =================================================

                    NET_CONTROL_ADDR: begin

                        if (
                            write_data[0] &&
                            !network_busy
                        ) begin

                            network_start <=
                                1'b1;

                        end

                    end


                    // =================================================
                    // MODEL LAYER SELECTION
                    // =================================================

                    MODEL_LAYER_ADDR: begin

                        model_layer <=
                            write_data[15:0];

                        network_weight_wr_layer <=
                            write_data[15:0];

                    end


                    // =================================================
                    // MODEL WEIGHT STAGING
                    // =================================================

                    MODEL_WEIGHT_FILTER_ADDR: begin

                        model_weight_filter <=
                            write_data[15:0];

                    end


                    MODEL_WEIGHT_CHANNEL_ADDR: begin

                        model_weight_channel <=
                            write_data[15:0];

                    end


                    MODEL_WEIGHT_TAP_ADDR: begin

                        model_weight_tap <=
                            write_data[3:0];

                    end


                    MODEL_WEIGHT_DATA_ADDR: begin

                        model_weight_data <=
                            $signed(write_data[7:0]);

                    end


                    // =================================================
                    // COMMIT MODEL WEIGHT
                    // =================================================

                    MODEL_WEIGHT_COMMIT_ADDR: begin

                        if (
                            write_data[0] &&
                            !network_busy
                        ) begin

                            network_weight_wr_layer <=
                                model_layer;

                            network_weight_wr_filter <=
                                model_weight_filter;

                            network_weight_wr_channel <=
                                model_weight_channel;

                            network_weight_wr_tap <=
                                model_weight_tap;

                            network_weight_wr_data <=
                                model_weight_data;

                            network_weight_wr_en <=
                                1'b1;

                        end

                    end


                    // =================================================
                    // MODEL BIAS
                    // =================================================

                    MODEL_BIAS_FILTER_ADDR: begin

                        model_bias_filter <=
                            write_data[15:0];

                    end


                    MODEL_BIAS_DATA_ADDR: begin

                        model_bias_data <=
                            $signed(write_data);

                    end


                    // =================================================
                    // COMMIT MODEL BIAS
                    // =================================================

                    MODEL_BIAS_COMMIT_ADDR: begin

                        if (
                            write_data[0] &&
                            !network_busy
                        ) begin

                            network_weight_wr_layer <=
                                model_layer;

                            network_bias_wr_filter <=
                                model_bias_filter;

                            network_bias_wr_data <=
                                model_bias_data;

                            network_bias_wr_en <=
                                1'b1;

                        end

                    end


                    // =================================================
                    // MODEL LOADER
                    // =================================================

                    MODEL_LOAD_BASE_ADDR: begin

                        model_load_base <=
                            write_data;

                    end


                    MODEL_LOAD_CONTROL_ADDR: begin

                        if (
                            write_data[0] &&
                            !network_busy &&
                            !model_load_busy
                        ) begin

                            model_load_start <=
                                1'b1;

                        end

                    end


                    // =================================================
                    // MODEL QUANT
                    // =================================================

                    MODEL_QUANT_FILTER_ADDR: begin

                        model_quant_filter <=
                            write_data[15:0];

                    end


                    MODEL_QUANT_DATA_ADDR: begin

                        model_quant_data <=
                            write_data[4:0];

                    end


                    // =================================================
                    // COMMIT MODEL QUANT
                    // =================================================

                    MODEL_QUANT_COMMIT_ADDR: begin

                        if (
                            write_data[0] &&
                            !network_busy
                        ) begin

                            network_weight_wr_layer <=
                                model_layer;

                            network_quant_wr_filter <=
                                model_quant_filter;

                            network_quant_wr_data <=
                                model_quant_data;

                            network_quant_wr_en <=
                                1'b1;

                        end

                    end


                    default: begin
                    end

                endcase

            end


            // =================================================
            // LEGACY FEATURE COUNTING
            // =================================================

            if (
                busy &&
                feature_valid
            ) begin

                if (
                    (output_count + 1'b1)
                    >=
                    expected_outputs
                ) begin

                    output_count <=
                        output_count + 1'b1;

                    busy <=
                        1'b0;

                    done <=
                        1'b1;

                end

                else begin

                    output_count <=
                        output_count + 1'b1;

                end

            end

        end

    end


    // =========================================================
    // MMIO READ
    // =========================================================

    always_comb begin

        read_data =
            32'd0;


        if (accel_read) begin

            case (address)


                CONTROL_ADDR: begin

                    read_data =
                        32'd0;

                end


                STATUS_ADDR: begin

                    read_data = {
                        30'd0,
                        done,
                        busy
                    };

                end


                WIDTH_ADDR: begin

                    read_data = {
                        16'd0,
                        image_width
                    };

                end


                HEIGHT_ADDR: begin

                    read_data = {
                        16'd0,
                        image_height
                    };

                end


                INPUT_BASE_ADDR: begin

                    read_data =
                        input_base_address;

                end


                OUTPUT_BASE_ADDR: begin

                    read_data =
                        output_base_address;

                end


                WEIGHTS03_ADDR: begin

                    read_data = {
                        k10,
                        k02,
                        k01,
                        k00
                    };

                end


                WEIGHTS47_ADDR: begin

                    read_data = {
                        k21,
                        k20,
                        k12,
                        k11
                    };

                end


                WEIGHT8_ADDR: begin

                    read_data = {
                        24'd0,
                        k22
                    };

                end


                BIAS_ADDR: begin

                    read_data =
                        bias;

                end


                QUANT_SHIFT_ADDR: begin

                    read_data = {
                        27'd0,
                        quant_shift
                    };

                end


                // =================================================
                // NETWORK CONFIG READBACK
                // =================================================

                NET_NUM_LAYERS_ADDR: begin

                    read_data = {
                        16'd0,
                        network_num_layers
                    };

                end


                NET_CIN_ADDR: begin

                    read_data = {
                        16'd0,
                        network_input_channels
                    };

                end


                NET_BUFFER_A_ADDR: begin

                    read_data =
                        network_buffer_a_base;

                end


                NET_BUFFER_B_ADDR: begin

                    read_data =
                        network_buffer_b_base;

                end


                // =================================================
                // DESCRIPTOR READBACK
                // =================================================

                LAYER_INDEX_ADDR: begin

                    read_data = {
                        16'd0,
                        layer_program_index
                    };

                end


                LAYER_COUT_ADDR: begin

                    read_data = {
                        16'd0,
                        layer_program_cout
                    };

                end


                LAYER_STRIDE_ADDR: begin

                    read_data = {
                        30'd0,
                        layer_program_stride
                    };

                end


                LAYER_COMMIT_ADDR: begin

                    read_data =
                        32'd0;

                end


                // =================================================
                // NETWORK CONTROL / STATUS
                // =================================================

                NET_CONTROL_ADDR: begin

                    read_data =
                        32'd0;

                end


                NET_STATUS_ADDR: begin

                    read_data = {
                        30'd0,
                        network_done,
                        network_busy
                    };

                end


                // =================================================
                // MODEL LAYER READBACK
                // =================================================

                MODEL_LAYER_ADDR: begin

                    read_data = {
                        16'd0,
                        model_layer
                    };

                end


                // =================================================
                // MODEL WEIGHT READBACK
                // =================================================

                MODEL_WEIGHT_FILTER_ADDR: begin

                    read_data = {
                        16'd0,
                        model_weight_filter
                    };

                end


                MODEL_WEIGHT_CHANNEL_ADDR: begin

                    read_data = {
                        16'd0,
                        model_weight_channel
                    };

                end


                MODEL_WEIGHT_TAP_ADDR: begin

                    read_data = {
                        28'd0,
                        model_weight_tap
                    };

                end


                MODEL_WEIGHT_DATA_ADDR: begin

                    read_data = {
                        24'd0,
                        model_weight_data
                    };

                end


                MODEL_WEIGHT_COMMIT_ADDR: begin

                    read_data =
                        32'd0;

                end


                // =================================================
                // MODEL BIAS READBACK
                // =================================================

                MODEL_BIAS_FILTER_ADDR: begin

                    read_data = {
                        16'd0,
                        model_bias_filter
                    };

                end


                MODEL_BIAS_DATA_ADDR: begin

                    read_data =
                        model_bias_data;

                end


                MODEL_BIAS_COMMIT_ADDR: begin

                    read_data =
                        32'd0;

                end


                // =================================================
                // MODEL QUANT READBACK
                // =================================================

                MODEL_QUANT_FILTER_ADDR: begin

                    read_data = {
                        16'd0,
                        model_quant_filter
                    };

                end


                MODEL_QUANT_DATA_ADDR: begin

                    read_data = {
                        27'd0,
                        model_quant_data
                    };

                end


                MODEL_QUANT_COMMIT_ADDR: begin

                    read_data =
                        32'd0;

                end


                MODEL_LOAD_BASE_ADDR: begin

                    read_data =
                        model_load_base;

                end


                MODEL_LOAD_CONTROL_ADDR: begin

                    read_data =
                        32'd0;

                end


                MODEL_LOAD_STATUS_ADDR: begin

                    read_data = {
                        29'd0,
                        model_load_error,
                        model_load_done,
                        model_load_busy
                    };

                end


                default: begin

                    read_data =
                        32'd0;

                end

            endcase

        end

    end


endmodule

module nova1_ai_subsystem #(
    parameter integer MAX_WIDTH             = 4096,
    parameter integer MAX_OUTPUTS           = 8294400,
    parameter integer MAX_INPUT_CHANNELS    = 64,
    parameter integer MAX_OUTPUT_CHANNELS   = 64,
    parameter integer FILTER_LANES          = 4,
    parameter integer MAX_LAYERS            = 8,
    parameter integer PIPELINE_DRAIN_CYCLES = 4
)(
    input logic clk,
    input logic reset,

    // =========================================================
    // CPU / MMIO INTERFACE
    // =========================================================

    input  logic        accel_read,
    input  logic        accel_write,

    input  logic [31:0] address,
    input  logic [31:0] write_data,

    output logic [31:0] read_data,


    // =========================================================
    // SHARED MEMORY INTERFACE
    // =========================================================

    output logic        dma_mem_read_req,
    output logic [31:0] dma_mem_read_address,

    input logic [31:0] dma_mem_read_data,
    input logic        dma_mem_read_valid,

    output logic        dma_mem_write_req,
    output logic [31:0] dma_mem_write_address,
    output logic [31:0] dma_mem_write_data,


    // =========================================================
    // AI STATUS
    // =========================================================

    output logic busy,
    output logic done
);


    // =========================================================
    // COMMON IMAGE CONFIGURATION FROM MMIO
    // =========================================================

    logic [15:0] image_width;
    logic [15:0] image_height;

    logic [31:0] input_base_address;
    logic [31:0] legacy_output_base_address;


    // =========================================================
    // LEGACY MMIO PATH
    // =========================================================

    logic legacy_dma_start;

    logic legacy_busy;
    logic legacy_done;

    logic signed [31:0] legacy_feature_out;
    logic               legacy_feature_valid;


    // =========================================================
    // NETWORK CONFIGURATION
    // =========================================================

    logic [15:0] network_num_layers;
    logic [15:0] network_input_channels;

    logic [31:0] network_buffer_a_base;
    logic [31:0] network_buffer_b_base;

    logic network_start;


    // =========================================================
    // NETWORK STATUS
    // =========================================================

    logic network_busy;
    logic network_done;


    // =========================================================
    // LAYER DESCRIPTOR PROGRAMMING
    // =========================================================

    logic        layer_descriptor_wr_en;
    logic [15:0] layer_descriptor_wr_index;
    logic [15:0] layer_descriptor_wr_cout;
    logic [1:0]  layer_descriptor_wr_stride;


    // =========================================================
    // MODEL PROGRAMMING LAYER
    // =========================================================

    logic [15:0] network_weight_wr_layer;


    // =========================================================
    // NETWORK WEIGHT PROGRAMMING
    // =========================================================

    logic network_weight_wr_en;

    logic [15:0] network_weight_wr_filter;
    logic [15:0] network_weight_wr_channel;

    logic [3:0] network_weight_wr_tap;

    logic signed [7:0] network_weight_wr_data;


    // =========================================================
    // NETWORK BIAS PROGRAMMING
    // =========================================================

    logic network_bias_wr_en;

    logic [15:0] network_bias_wr_filter;

    logic signed [31:0] network_bias_wr_data;


    // =========================================================
    // NETWORK QUANTIZATION PROGRAMMING
    // =========================================================

    logic network_quant_wr_en;

    logic [15:0] network_quant_wr_filter;

    logic [4:0] network_quant_wr_data;


    // =========================================================
    // MODEL LOADER
    // =========================================================

    logic [31:0] model_load_base;
    logic        model_load_start;
    logic        model_load_busy;
    logic        model_load_done;
    logic        model_load_error;

    logic        loader_mem_read_req;
    logic [31:0] loader_mem_read_address;
    logic [31:0] loader_mem_read_data;
    logic        loader_mem_read_valid;

    logic        loader_descriptor_wr_en;
    logic [15:0] loader_descriptor_wr_index;
    logic [15:0] loader_descriptor_wr_cout;
    logic [1:0]  loader_descriptor_wr_stride;

    logic        loader_weight_wr_en;
    logic [15:0] loader_weight_wr_layer;
    logic [15:0] loader_weight_wr_filter;
    logic [15:0] loader_weight_wr_channel;
    logic [3:0]  loader_weight_wr_tap;
    logic signed [7:0] loader_weight_wr_data;

    logic        loader_bias_wr_en;
    logic [15:0] loader_bias_wr_layer;
    logic [15:0] loader_bias_wr_filter;
    logic signed [31:0] loader_bias_wr_data;

    logic        loader_quant_wr_en;
    logic [15:0] loader_quant_wr_layer;
    logic [15:0] loader_quant_wr_filter;
    logic [4:0]  loader_quant_wr_data;

    logic        effective_descriptor_wr_en;
    logic [15:0] effective_descriptor_wr_index;
    logic [15:0] effective_descriptor_wr_cout;
    logic [1:0]  effective_descriptor_wr_stride;

    logic        effective_weight_wr_en;
    logic [15:0] effective_weight_wr_layer;
    logic [15:0] effective_weight_wr_filter;
    logic [15:0] effective_weight_wr_channel;
    logic [3:0]  effective_weight_wr_tap;
    logic signed [7:0] effective_weight_wr_data;

    logic        effective_bias_wr_en;
    logic [15:0] effective_bias_wr_layer;
    logic [15:0] effective_bias_wr_filter;
    logic signed [31:0] effective_bias_wr_data;

    logic        effective_quant_wr_en;
    logic [15:0] effective_quant_wr_layer;
    logic [15:0] effective_quant_wr_filter;
    logic [4:0]  effective_quant_wr_data;


    // =========================================================
    // NETWORK DEBUG
    // =========================================================

    logic [15:0] current_layer;

    logic [15:0] active_width;
    logic [15:0] active_height;

    logic [15:0] active_cin;
    logic [15:0] active_cout;

    logic active_layout_c4;

    logic [1:0] active_stride;

    logic [15:0] active_output_width;
    logic [15:0] active_output_height;

    logic [31:0] active_input_base;
    logic [31:0] active_output_base;


    // =========================================================
    // MMIO
    // =========================================================

    nova1_ai_mmio #(
        .MAX_WIDTH(
            MAX_WIDTH
        )
    ) MMIO_ACCEL (

        .clk(
            clk
        ),

        .reset(
            reset
        ),


        // =====================================================
        // CPU BUS
        // =====================================================

        .accel_read(
            accel_read
        ),

        .accel_write(
            accel_write
        ),

        .address(
            address
        ),

        .write_data(
            write_data
        ),

        .read_data(
            read_data
        ),


        // =====================================================
        // LEGACY STREAMING ACCELERATOR INPUT
        // =====================================================

        .pixel_in(
            8'sd0
        ),

        .pixel_valid(
            1'b0
        ),

        .feature_out(
            legacy_feature_out
        ),

        .feature_valid(
            legacy_feature_valid
        ),


        // =====================================================
        // COMMON IMAGE CONFIG
        // =====================================================

        .input_base_address(
            input_base_address
        ),

        .output_base_address(
            legacy_output_base_address
        ),

        .image_width(
            image_width
        ),

        .image_height(
            image_height
        ),

        .dma_start(
            legacy_dma_start
        ),


        // =====================================================
        // LEGACY STATUS
        // =====================================================

        .busy(
            legacy_busy
        ),

        .done(
            legacy_done
        ),


        // =====================================================
        // NETWORK CONFIGURATION
        // =====================================================

        .network_num_layers(
            network_num_layers
        ),

        .network_input_channels(
            network_input_channels
        ),

        .network_buffer_a_base(
            network_buffer_a_base
        ),

        .network_buffer_b_base(
            network_buffer_b_base
        ),

        .network_start(
            network_start
        ),


        // =====================================================
        // LAYER DESCRIPTORS
        // =====================================================

        .layer_descriptor_wr_en(
            layer_descriptor_wr_en
        ),

        .layer_descriptor_wr_index(
            layer_descriptor_wr_index
        ),

        .layer_descriptor_wr_cout(
            layer_descriptor_wr_cout
        ),

        .layer_descriptor_wr_stride(
            layer_descriptor_wr_stride
        ),


        // =====================================================
        // MODEL PROGRAMMING LAYER
        // =====================================================

        .network_weight_wr_layer(
            network_weight_wr_layer
        ),


        // =====================================================
        // WEIGHTS
        // =====================================================

        .network_weight_wr_en(
            network_weight_wr_en
        ),

        .network_weight_wr_filter(
            network_weight_wr_filter
        ),

        .network_weight_wr_channel(
            network_weight_wr_channel
        ),

        .network_weight_wr_tap(
            network_weight_wr_tap
        ),

        .network_weight_wr_data(
            network_weight_wr_data
        ),


        // =====================================================
        // BIAS
        // =====================================================

        .network_bias_wr_en(
            network_bias_wr_en
        ),

        .network_bias_wr_filter(
            network_bias_wr_filter
        ),

        .network_bias_wr_data(
            network_bias_wr_data
        ),


        // =====================================================
        // QUANTIZATION
        // =====================================================

        .network_quant_wr_en(
            network_quant_wr_en
        ),

        .network_quant_wr_filter(
            network_quant_wr_filter
        ),

        .network_quant_wr_data(
            network_quant_wr_data
        ),


        // =====================================================
        // REAL NETWORK STATUS
        // =====================================================

        .network_busy(
            network_busy
        ),

        .network_done(
            network_done
        ),

        .model_load_base(
            model_load_base
        ),

        .model_load_start(
            model_load_start
        ),

        .model_load_busy(
            model_load_busy
        ),

        .model_load_done(
            model_load_done
        ),

        .model_load_error(
            model_load_error
        )

    );


    logic        network_mem_read_req;
    logic [31:0] network_mem_read_address;
    logic [31:0] network_mem_read_data;
    logic        network_mem_read_valid;


    // =========================================================
    // HARDWARE MODEL LOADER
    // =========================================================

    nova1_model_loader #(
        .MAX_INPUT_CHANNELS(
            MAX_INPUT_CHANNELS
        ),
        .MAX_OUTPUT_CHANNELS(
            MAX_OUTPUT_CHANNELS
        ),
        .MAX_LAYERS(
            MAX_LAYERS
        )
    ) MODEL_LOADER (

        .clk(clk),
        .reset(reset),

        .start(model_load_start),
        .base_address(model_load_base),

        .busy(model_load_busy),
        .done(model_load_done),
        .error(model_load_error),

        .mem_read_req(loader_mem_read_req),
        .mem_read_address(loader_mem_read_address),
        .mem_read_data(loader_mem_read_data),
        .mem_read_valid(loader_mem_read_valid),

        .descriptor_wr_en(loader_descriptor_wr_en),
        .descriptor_wr_index(loader_descriptor_wr_index),
        .descriptor_wr_cout(loader_descriptor_wr_cout),
        .descriptor_wr_stride(loader_descriptor_wr_stride),

        .weight_wr_en(loader_weight_wr_en),
        .weight_wr_layer(loader_weight_wr_layer),
        .weight_wr_filter(loader_weight_wr_filter),
        .weight_wr_channel(loader_weight_wr_channel),
        .weight_wr_tap(loader_weight_wr_tap),
        .weight_wr_data(loader_weight_wr_data),

        .bias_wr_en(loader_bias_wr_en),
        .bias_wr_layer(loader_bias_wr_layer),
        .bias_wr_filter(loader_bias_wr_filter),
        .bias_wr_data(loader_bias_wr_data),

        .quant_wr_en(loader_quant_wr_en),
        .quant_wr_layer(loader_quant_wr_layer),
        .quant_wr_filter(loader_quant_wr_filter),
        .quant_wr_data(loader_quant_wr_data)

    );


    // =========================================================
    // LOADER / CPU PROGRAMMING ARBITRATION
    //
    // While the loader is active it owns the parameter-programming
    // interface. Outside loader activity the legacy CPU/MMIO path
    // remains fully functional.
    // =========================================================

    always_comb begin
        if (model_load_busy) begin
            effective_descriptor_wr_en = loader_descriptor_wr_en;
            effective_descriptor_wr_index = loader_descriptor_wr_index;
            effective_descriptor_wr_cout = loader_descriptor_wr_cout;
            effective_descriptor_wr_stride = loader_descriptor_wr_stride;

            effective_weight_wr_en = loader_weight_wr_en;
            effective_weight_wr_layer = loader_weight_wr_layer;
            effective_weight_wr_filter = loader_weight_wr_filter;
            effective_weight_wr_channel = loader_weight_wr_channel;
            effective_weight_wr_tap = loader_weight_wr_tap;
            effective_weight_wr_data = loader_weight_wr_data;

            effective_bias_wr_en = loader_bias_wr_en;
            effective_bias_wr_layer = loader_bias_wr_layer;
            effective_bias_wr_filter = loader_bias_wr_filter;
            effective_bias_wr_data = loader_bias_wr_data;

            effective_quant_wr_en = loader_quant_wr_en;
            effective_quant_wr_layer = loader_quant_wr_layer;
            effective_quant_wr_filter = loader_quant_wr_filter;
            effective_quant_wr_data = loader_quant_wr_data;
        end
        else begin
            effective_descriptor_wr_en = layer_descriptor_wr_en;
            effective_descriptor_wr_index = layer_descriptor_wr_index;
            effective_descriptor_wr_cout = layer_descriptor_wr_cout;
            effective_descriptor_wr_stride = layer_descriptor_wr_stride;

            effective_weight_wr_en = network_weight_wr_en;
            effective_weight_wr_layer = network_weight_wr_layer;
            effective_weight_wr_filter = network_weight_wr_filter;
            effective_weight_wr_channel = network_weight_wr_channel;
            effective_weight_wr_tap = network_weight_wr_tap;
            effective_weight_wr_data = network_weight_wr_data;

            effective_bias_wr_en = network_bias_wr_en;
            effective_bias_wr_layer = network_weight_wr_layer;
            effective_bias_wr_filter = network_bias_wr_filter;
            effective_bias_wr_data = network_bias_wr_data;

            effective_quant_wr_en = network_quant_wr_en;
            effective_quant_wr_layer = network_weight_wr_layer;
            effective_quant_wr_filter = network_quant_wr_filter;
            effective_quant_wr_data = network_quant_wr_data;
        end
    end


    // =========================================================
    // SHARED MEMORY READ ARBITRATION
    //
    // The loader runs before the network, so a simple ownership
    // mux is sufficient and avoids changing the external SoC bus.
    // =========================================================

    always_comb begin
        if (model_load_busy) begin
            dma_mem_read_req = loader_mem_read_req;
            dma_mem_read_address = loader_mem_read_address;

            loader_mem_read_data = dma_mem_read_data;
            loader_mem_read_valid = dma_mem_read_valid;

            network_mem_read_data = 32'd0;
            network_mem_read_valid = 1'b0;
        end
        else begin
            dma_mem_read_req = network_mem_read_req;
            dma_mem_read_address = network_mem_read_address;

            loader_mem_read_data = 32'd0;
            loader_mem_read_valid = 1'b0;

            network_mem_read_data = dma_mem_read_data;
            network_mem_read_valid = dma_mem_read_valid;
        end
    end


    // =========================================================
    // REAL PROGRAMMABLE CNN NETWORK ENGINE
    // =========================================================

    cnn_network_engine #(

        .MAX_WIDTH(
            MAX_WIDTH
        ),

        .MAX_OUTPUTS(
            MAX_OUTPUTS
        ),

        .MAX_INPUT_CHANNELS(
            MAX_INPUT_CHANNELS
        ),

        .MAX_OUTPUT_CHANNELS(
            MAX_OUTPUT_CHANNELS
        ),

        .FILTER_LANES(
            FILTER_LANES
        ),

        .MAX_LAYERS(
            MAX_LAYERS
        ),

        .PIPELINE_DRAIN_CYCLES(
            PIPELINE_DRAIN_CYCLES
        )

    ) NETWORK_ENGINE (

        .clk(
            clk
        ),

        .reset(
            reset
        ),


        // =====================================================
        // NETWORK CONTROL
        // =====================================================

        .start(
            network_start
        ),

        .num_layers(
            network_num_layers
        ),


        // =====================================================
        // ORIGINAL INPUT TENSOR
        // =====================================================

        .original_width(
            image_width
        ),

        .original_height(
            image_height
        ),

        .original_channels(
            network_input_channels
        ),

        .original_input_base(
            input_base_address
        ),


        // =====================================================
        // PING-PONG FEATURE BUFFERS
        // =====================================================

        .buffer_a_base(
            network_buffer_a_base
        ),

        .buffer_b_base(
            network_buffer_b_base
        ),


        // =====================================================
        // NETWORK STATUS
        // =====================================================

        .busy(
            network_busy
        ),

        .done(
            network_done
        ),


        // =====================================================
        // SHARED MEMORY
        // =====================================================

        .mem_read_req(
            network_mem_read_req
        ),

        .mem_read_address(
            network_mem_read_address
        ),

        .mem_read_data(
            network_mem_read_data
        ),

        .mem_read_valid(
            network_mem_read_valid
        ),

        .mem_write_req(
            dma_mem_write_req
        ),

        .mem_write_address(
            dma_mem_write_address
        ),

        .mem_write_data(
            dma_mem_write_data
        ),


        // =====================================================
        // MODEL PROGRAMMING LAYER
        // =====================================================

        .weight_wr_layer(
            effective_weight_wr_layer
        ),


        // =====================================================
        // MODEL WEIGHTS FROM CPU/MMIO
        // =====================================================

        .weight_wr_en(
            effective_weight_wr_en
        ),

        .weight_wr_filter(
            effective_weight_wr_filter
        ),

        .weight_wr_channel(
            effective_weight_wr_channel
        ),

        .weight_wr_tap(
            effective_weight_wr_tap
        ),

        .weight_wr_data(
            effective_weight_wr_data
        ),


        // =====================================================
        // MODEL BIAS FROM CPU/MMIO
        // =====================================================

        .bias_wr_en(
            effective_bias_wr_en
        ),

        .bias_wr_filter(
            effective_bias_wr_filter
        ),

        .bias_wr_data(
            effective_bias_wr_data
        ),


        // =====================================================
        // MODEL QUANTIZATION FROM CPU/MMIO
        // =====================================================

        .quant_wr_en(
            effective_quant_wr_en
        ),

        .quant_wr_filter(
            effective_quant_wr_filter
        ),

        .quant_wr_data(
            effective_quant_wr_data
        ),


        // =====================================================
        // CPU-PROGRAMMABLE LAYER DESCRIPTORS
        // =====================================================

        .descriptor_wr_en(
            effective_descriptor_wr_en
        ),

        .descriptor_wr_index(
            effective_descriptor_wr_index
        ),

        .descriptor_wr_cout(
            effective_descriptor_wr_cout
        ),

        .descriptor_wr_stride(
            effective_descriptor_wr_stride
        ),


        // =====================================================
        // DEBUG
        // =====================================================

        .current_layer(
            current_layer
        ),

        .active_width(
            active_width
        ),

        .active_height(
            active_height
        ),

        .active_cin(
            active_cin
        ),

        .active_cout(
            active_cout
        ),

        .active_layout_c4(
            active_layout_c4
        ),

        .active_stride(
            active_stride
        ),

        .active_output_width(
            active_output_width
        ),

        .active_output_height(
            active_output_height
        ),

        .active_input_base(
            active_input_base
        ),

        .active_output_base(
            active_output_base
        )

    );


    // =========================================================
    // TOP-LEVEL STATUS
    // =========================================================

    always_comb begin

        busy =
            model_load_busy || network_busy;

        done =
            network_done;

    end


endmodule

module nova1_dma (

    input  logic clk,
    input  logic reset,

    // =========================================================
    // CHANNEL REQUEST
    // =========================================================

    input logic        channel_request,
    input logic [15:0] requested_channel,


    // =========================================================
    // TENSOR CONFIGURATION
    // =========================================================

    input logic [15:0] image_width,
    input logic [15:0] image_height,

    // Number of channels contained in input tensor
    input logic [15:0] tensor_channels,

    // 0 = planar INT8
    // 1 = C4 packed
    input logic input_layout_c4,

    input logic [31:0] input_base_address,


    // =========================================================
    // MEMORY READ INTERFACE
    // =========================================================

    output logic        mem_read_req,
    output logic [31:0] mem_read_address,

    input logic [31:0] mem_read_data,
    input logic        mem_read_valid,


    // =========================================================
    // PIXEL STREAM
    // =========================================================

    output logic signed [7:0] pixel_out,
    output logic              pixel_valid,

    output logic [15:0] channel_index,

    output logic channel_start,


    // =========================================================
    // STATUS
    // =========================================================

    output logic busy,

    output logic channel_done
);


    // =========================================================
    // GEOMETRY
    // =========================================================

    logic [31:0] pixels_per_channel;

    logic [31:0] planar_words_per_channel;

    logic [31:0] planar_channel_stride_bytes;


    always_comb begin

        pixels_per_channel =
            image_width * image_height;


        // Planar representation packs four INT8 pixels
        // into each 32-bit word.

        planar_words_per_channel =
            (pixels_per_channel + 32'd3)
            >> 2;


        planar_channel_stride_bytes =
            planar_words_per_channel << 2;

    end


    // =========================================================
    // ACTIVE REQUEST
    // =========================================================

    logic [15:0] active_channel;

    logic active_layout_c4;

    logic [1:0] active_lane;

    logic [31:0] active_group;

    logic [31:0] words_needed;


    // =========================================================
    // COUNTERS
    // =========================================================

    logic [31:0] pixel_count;

    logic [31:0] words_requested;


    // =========================================================
    // READ ADDRESS
    // =========================================================

    logic [31:0] first_read_address;

    logic [31:0] next_read_address;


    // =========================================================
    // TWO-WORD PREFETCH BUFFER
    // =========================================================

    logic [31:0] current_word;
    logic [31:0] next_word;

    logic current_valid;
    logic next_valid;

    logic [1:0] byte_index;

    logic read_pending;


    // =========================================================
    // REQUEST ADDRESS CALCULATION
    // =========================================================

    always_comb begin

        active_group =
            requested_channel >> 2;


        // -----------------------------------------------------
        // PLANAR
        //
        // BASE +
        // channel * planar_stride
        // -----------------------------------------------------

        if (!input_layout_c4) begin

            first_read_address =

                input_base_address

                +

                (
                    requested_channel
                    *
                    planar_channel_stride_bytes
                );


            words_needed =
                planar_words_per_channel;

        end


        // -----------------------------------------------------
        // C4 PACKED
        //
        // Layout is group-major:
        //
        // group0:
        // spatial0 [C3 C2 C1 C0]
        // spatial1 [C3 C2 C1 C0]
        // ...
        //
        // group1:
        // spatial0 [C7 C6 C5 C4]
        // ...
        //
        // Address of first word for requested channel group:
        //
        // BASE +
        // group * pixels_per_channel * 4
        // -----------------------------------------------------

        else begin

            first_read_address =

                input_base_address

                +

                (
                    active_group
                    *
                    pixels_per_channel
                    *
                    32'd4
                );


            // One 32-bit C4 word per spatial position.

            words_needed =
                pixels_per_channel;

        end

    end


    // =========================================================
    // DMA CONTROLLER
    // =========================================================

    always_ff @(posedge clk) begin

        if (reset) begin

            busy <=
                1'b0;

            channel_done <=
                1'b0;


            mem_read_req <=
                1'b0;

            mem_read_address <=
                32'd0;


            pixel_out <=
                8'sd0;

            pixel_valid <=
                1'b0;


            channel_index <=
                16'd0;

            channel_start <=
                1'b0;


            active_channel <=
                16'd0;

            active_layout_c4 <=
                1'b0;

            active_lane <=
                2'd0;


            pixel_count <=
                32'd0;

            words_requested <=
                32'd0;


            current_word <=
                32'd0;

            next_word <=
                32'd0;


            current_valid <=
                1'b0;

            next_valid <=
                1'b0;


            byte_index <=
                2'd0;


            read_pending <=
                1'b0;

            next_read_address <=
                32'd0;

        end

        else begin

            // =================================================
            // DEFAULT PULSES
            // =================================================

            mem_read_req <=
                1'b0;

            pixel_valid <=
                1'b0;

            channel_start <=
                1'b0;

            channel_done <=
                1'b0;


            // =================================================
            // ACCEPT CHANNEL REQUEST
            // =================================================

            if (
                channel_request &&
                !busy
            ) begin

                active_channel <=
                    requested_channel;

                active_layout_c4 <=
                    input_layout_c4;

                active_lane <=
                    requested_channel[1:0];


                channel_index <=
                    requested_channel;


                pixel_count <=
                    32'd0;

                byte_index <=
                    2'd0;


                current_valid <=
                    1'b0;

                next_valid <=
                    1'b0;


                // -------------------------------------------------
                // Reject invalid configuration.
                // -------------------------------------------------

                if (
                    (pixels_per_channel == 32'd0) ||
                    (requested_channel >= tensor_channels) ||
                    (tensor_channels == 16'd0)
                ) begin

                    busy <=
                        1'b0;

                    channel_done <=
                        1'b1;

                    read_pending <=
                        1'b0;

                    words_requested <=
                        32'd0;

                end

                else begin

                    busy <=
                        1'b1;


                    // =============================================
                    // REQUEST FIRST WORD
                    // =============================================

                    mem_read_req <=
                        1'b1;

                    mem_read_address <=
                        first_read_address;


                    read_pending <=
                        1'b1;

                    words_requested <=
                        32'd1;


                    next_read_address <=
                        first_read_address
                        +
                        32'd4;

                end

            end


            // =================================================
            // MEMORY RESPONSE
            // =================================================

            if (
                busy &&
                read_pending &&
                mem_read_valid
            ) begin

                if (!current_valid) begin

                    current_word <=
                        mem_read_data;

                    current_valid <=
                        1'b1;

                    byte_index <=
                        2'd0;

                end

                else if (!next_valid) begin

                    next_word <=
                        mem_read_data;

                    next_valid <=
                        1'b1;

                end


                read_pending <=
                    1'b0;

            end


            // =================================================
            // PREFETCH NEXT WORD
            // =================================================

            if (
                busy &&
                current_valid &&
                !next_valid &&
                !read_pending &&
                (words_requested < words_needed)
            ) begin

                mem_read_req <=
                    1'b1;


                mem_read_address <=
                    next_read_address;


                next_read_address <=
                    next_read_address
                    +
                    32'd4;


                words_requested <=
                    words_requested
                    +
                    1'b1;


                read_pending <=
                    1'b1;

            end


            // =================================================
            // PROMOTE NEXT WORD
            // =================================================

            if (
                busy &&
                !current_valid &&
                next_valid
            ) begin

                current_word <=
                    next_word;

                current_valid <=
                    1'b1;

                next_valid <=
                    1'b0;

                byte_index <=
                    2'd0;

            end


            // =================================================
            // STREAM PIXEL
            // =================================================

            if (
                busy &&
                current_valid &&
                (pixel_count < pixels_per_channel)
            ) begin

                channel_index <=
                    active_channel;


                // First pixel of requested channel

                if (pixel_count == 32'd0) begin

                    channel_start <=
                        1'b1;

                end


                // =================================================
                // PLANAR INPUT
                //
                // Each word contains:
                //
                // P0 P1 P2 P3
                // =================================================

                if (!active_layout_c4) begin

                    case (byte_index)

                        2'd0:
                            pixel_out <=
                                $signed(
                                    current_word[7:0]
                                );

                        2'd1:
                            pixel_out <=
                                $signed(
                                    current_word[15:8]
                                );

                        2'd2:
                            pixel_out <=
                                $signed(
                                    current_word[23:16]
                                );

                        2'd3:
                            pixel_out <=
                                $signed(
                                    current_word[31:24]
                                );

                    endcase

                end


                // =================================================
                // C4 INPUT
                //
                // Each word contains:
                //
                // byte0 = channel group + 0
                // byte1 = channel group + 1
                // byte2 = channel group + 2
                // byte3 = channel group + 3
                //
                // We select one requested channel lane.
                // =================================================

                else begin

                    case (active_lane)

                        2'd0:
                            pixel_out <=
                                $signed(
                                    current_word[7:0]
                                );

                        2'd1:
                            pixel_out <=
                                $signed(
                                    current_word[15:8]
                                );

                        2'd2:
                            pixel_out <=
                                $signed(
                                    current_word[23:16]
                                );

                        2'd3:
                            pixel_out <=
                                $signed(
                                    current_word[31:24]
                                );

                    endcase

                end


                pixel_valid <=
                    1'b1;


                // =================================================
                // FINAL PIXEL
                // =================================================

                if (
                    (pixel_count + 1)
                    >=
                    pixels_per_channel
                ) begin

                    pixel_count <=
                        pixel_count + 1'b1;


                    current_valid <=
                        1'b0;

                    next_valid <=
                        1'b0;

                    read_pending <=
                        1'b0;


                    byte_index <=
                        2'd0;


                    busy <=
                        1'b0;

                    channel_done <=
                        1'b1;

                end


                // =================================================
                // MORE PIXELS
                // =================================================

                else begin

                    pixel_count <=
                        pixel_count + 1'b1;


                    // =============================================
                    // PLANAR MODE
                    //
                    // Consume four bytes before changing word.
                    // =============================================

                    if (!active_layout_c4) begin

                        if (
                            byte_index == 2'd3
                        ) begin

                            byte_index <=
                                2'd0;


                            if (next_valid) begin

                                current_word <=
                                    next_word;

                                current_valid <=
                                    1'b1;

                                next_valid <=
                                    1'b0;

                            end

                            else begin

                                current_valid <=
                                    1'b0;

                            end

                        end

                        else begin

                            byte_index <=
                                byte_index + 1'b1;

                        end

                    end


                    // =============================================
                    // C4 MODE
                    //
                    // One requested-channel pixel per 32-bit word.
                    // Move to next word every pixel.
                    // =============================================

                    else begin

                        byte_index <=
                            2'd0;


                        if (next_valid) begin

                            current_word <=
                                next_word;

                            current_valid <=
                                1'b1;

                            next_valid <=
                                1'b0;

                        end

                        else begin

                            current_valid <=
                                1'b0;

                        end

                    end

                end

            end

        end

    end


endmodule

module nova1_model_loader #(
    parameter integer MAX_INPUT_CHANNELS  = 64,
    parameter integer MAX_OUTPUT_CHANNELS = 64,
    parameter integer MAX_LAYERS          = 8
)(
    input  logic clk,
    input  logic reset,

    input  logic        start,
    input  logic [31:0] base_address,

    output logic busy,
    output logic done,
    output logic error,

    // Shared-memory read port.
    output logic        mem_read_req,
    output logic [31:0] mem_read_address,
    input  logic [31:0] mem_read_data,
    input  logic        mem_read_valid,

    // Layer descriptor programming.
    output logic        descriptor_wr_en,
    output logic [15:0] descriptor_wr_index,
    output logic [15:0] descriptor_wr_cout,
    output logic [1:0]  descriptor_wr_stride,

    // Weight programming.
    output logic        weight_wr_en,
    output logic [15:0] weight_wr_layer,
    output logic [15:0] weight_wr_filter,
    output logic [15:0] weight_wr_channel,
    output logic [3:0]  weight_wr_tap,
    output logic signed [7:0] weight_wr_data,

    // Bias programming.
    output logic        bias_wr_en,
    output logic [15:0] bias_wr_layer,
    output logic [15:0] bias_wr_filter,
    output logic signed [31:0] bias_wr_data,

    // Quantization programming.
    output logic        quant_wr_en,
    output logic [15:0] quant_wr_layer,
    output logic [15:0] quant_wr_filter,
    output logic [4:0]  quant_wr_data
);

    localparam logic [31:0] MAGIC = 32'h4E4F5641; // "NOVA"

    typedef enum logic [3:0] {
        S_IDLE,
        S_MAGIC_REQ,
        S_MAGIC_WAIT,
        S_LAYERS_REQ,
        S_LAYERS_WAIT,
        S_HEADER_REQ,
        S_HEADER_WAIT,
        S_WEIGHT_REQ,
        S_WEIGHT_WAIT,
        S_BIAS_REQ,
        S_BIAS_WAIT,
        S_QUANT_REQ,
        S_QUANT_WAIT,
        S_DONE,
        S_ERROR
    } state_t;

    state_t state;

    logic [31:0] read_address_reg;
    logic [15:0] num_layers;
    logic [15:0] current_layer;

    logic [15:0] current_cin;
    logic [15:0] current_cout;
    logic [1:0]  current_stride;

    logic [15:0] weight_filter;
    logic [15:0] weight_channel;
    logic [3:0]  weight_tap;
    logic [15:0] bias_filter;
    logic [15:0] quant_filter;

    always_comb begin
        mem_read_req = 1'b0;
        mem_read_address = read_address_reg;

        descriptor_wr_en = 1'b0;
        descriptor_wr_index = current_layer;
        descriptor_wr_cout = current_cout;
        descriptor_wr_stride = current_stride;

        weight_wr_en = 1'b0;
        weight_wr_layer = current_layer;
        weight_wr_filter = weight_filter;
        weight_wr_channel = weight_channel;
        weight_wr_tap = weight_tap;
        weight_wr_data = $signed(mem_read_data[7:0]);

        bias_wr_en = 1'b0;
        bias_wr_layer = current_layer;
        bias_wr_filter = bias_filter;
        bias_wr_data = $signed(mem_read_data);

        quant_wr_en = 1'b0;
        quant_wr_layer = current_layer;
        quant_wr_filter = quant_filter;
        quant_wr_data = mem_read_data[4:0];

        case (state)
            S_MAGIC_REQ,
            S_LAYERS_REQ,
            S_HEADER_REQ,
            S_WEIGHT_REQ,
            S_BIAS_REQ,
            S_QUANT_REQ: begin
                mem_read_req = 1'b1;
            end
            default: begin
            end
        endcase

        if (state == S_HEADER_WAIT && mem_read_valid) begin
            descriptor_wr_en = 1'b1;
            descriptor_wr_index = current_layer;
            descriptor_wr_cout = {8'd0, mem_read_data[31:24]};
            descriptor_wr_stride = mem_read_data[1:0];
        end

        if (state == S_WEIGHT_WAIT && mem_read_valid) begin
            weight_wr_en = 1'b1;
        end

        if (state == S_BIAS_WAIT && mem_read_valid) begin
            bias_wr_en = 1'b1;
        end

        if (state == S_QUANT_WAIT && mem_read_valid) begin
            quant_wr_en = 1'b1;
        end
    end

    always_ff @(posedge clk) begin
        if (reset) begin
            state <= S_IDLE;
            busy <= 1'b0;
            done <= 1'b0;
            error <= 1'b0;

            read_address_reg <= 32'd0;
            num_layers <= 16'd0;
            current_layer <= 16'd0;
            current_cin <= 16'd0;
            current_cout <= 16'd0;
            current_stride <= 2'd1;

            weight_filter <= 16'd0;
            weight_channel <= 16'd0;
            weight_tap <= 4'd0;
            bias_filter <= 16'd0;
            quant_filter <= 16'd0;
        end
        else begin
            case (state)
                S_IDLE: begin
                    if (start) begin
                        busy <= 1'b1;
                        done <= 1'b0;
                        error <= 1'b0;
                        read_address_reg <= base_address;
                        current_layer <= 16'd0;
                        state <= S_MAGIC_REQ;
                    end
                end

                S_MAGIC_REQ: begin
                    state <= S_MAGIC_WAIT;
                end

                S_MAGIC_WAIT: begin
                    if (mem_read_valid) begin
                        if (mem_read_data == MAGIC) begin
                            read_address_reg <= read_address_reg + 32'd4;
                            state <= S_LAYERS_REQ;
                        end
                        else begin
                            busy <= 1'b0;
                            error <= 1'b1;
                            state <= S_ERROR;
                        end
                    end
                end

                S_LAYERS_REQ: begin
                    state <= S_LAYERS_WAIT;
                end

                S_LAYERS_WAIT: begin
                    if (mem_read_valid) begin
                        if ((mem_read_data[15:0] != 16'd0) &&
                            (mem_read_data[15:0] <= MAX_LAYERS)) begin
                            num_layers <= mem_read_data[15:0];
                            read_address_reg <= read_address_reg + 32'd4;
                            current_layer <= 16'd0;
                            state <= S_HEADER_REQ;
                        end
                        else begin
                            busy <= 1'b0;
                            error <= 1'b1;
                            state <= S_ERROR;
                        end
                    end
                end

                S_HEADER_REQ: begin
                    state <= S_HEADER_WAIT;
                end

                S_HEADER_WAIT: begin
                    if (mem_read_valid) begin
                        current_cout <= mem_read_data[31:24];
                        current_cin <= mem_read_data[23:16];
                        current_stride <= mem_read_data[1:0];

                        if ((mem_read_data[31:24] != 8'd0) &&
                            (mem_read_data[23:16] != 8'd0) &&
                            (mem_read_data[31:24] <= MAX_OUTPUT_CHANNELS) &&
                            (mem_read_data[23:16] <= MAX_INPUT_CHANNELS) &&
                            ((mem_read_data[1:0] == 2'd1) ||
                             (mem_read_data[1:0] == 2'd2))) begin
                            read_address_reg <= read_address_reg + 32'd4;
                            weight_filter <= 16'd0;
                            weight_channel <= 16'd0;
                            weight_tap <= 4'd0;
                            state <= S_WEIGHT_REQ;
                        end
                        else begin
                            busy <= 1'b0;
                            error <= 1'b1;
                            state <= S_ERROR;
                        end
                    end
                end

                S_WEIGHT_REQ: begin
                    state <= S_WEIGHT_WAIT;
                end

                S_WEIGHT_WAIT: begin
                    if (mem_read_valid) begin
                        read_address_reg <= read_address_reg + 32'd4;

                        if ((weight_filter == current_cout - 1'b1) &&
                            (weight_channel == current_cin - 1'b1) &&
                            (weight_tap == 4'd8)) begin
                            bias_filter <= 16'd0;
                            state <= S_BIAS_REQ;
                        end
                        else if (weight_tap == 4'd8) begin
                            weight_tap <= 4'd0;
                            if (weight_channel == current_cin - 1'b1) begin
                                weight_channel <= 16'd0;
                                weight_filter <= weight_filter + 16'd1;
                            end
                            else begin
                                weight_channel <= weight_channel + 16'd1;
                            end
                            state <= S_WEIGHT_REQ;
                        end
                        else begin
                            weight_tap <= weight_tap + 4'd1;
                            state <= S_WEIGHT_REQ;
                        end
                    end
                end

                S_BIAS_REQ: begin
                    state <= S_BIAS_WAIT;
                end

                S_BIAS_WAIT: begin
                    if (mem_read_valid) begin
                        read_address_reg <= read_address_reg + 32'd4;

                        if (bias_filter == current_cout - 1'b1) begin
                            quant_filter <= 16'd0;
                            state <= S_QUANT_REQ;
                        end
                        else begin
                            bias_filter <= bias_filter + 16'd1;
                            state <= S_BIAS_REQ;
                        end
                    end
                end

                S_QUANT_REQ: begin
                    state <= S_QUANT_WAIT;
                end

                S_QUANT_WAIT: begin
                    if (mem_read_valid) begin
                        read_address_reg <= read_address_reg + 32'd4;

                        if (quant_filter == current_cout - 1'b1) begin
                            if ((current_layer + 16'd1) >= num_layers) begin
                                busy <= 1'b0;
                                done <= 1'b1;
                                state <= S_DONE;
                            end
                            else begin
                                current_layer <= current_layer + 16'd1;
                                state <= S_HEADER_REQ;
                            end
                        end
                        else begin
                            quant_filter <= quant_filter + 16'd1;
                            state <= S_QUANT_REQ;
                        end
                    end
                end

                S_DONE: begin
                    // Sticky DONE until the next START.
                    state <= S_DONE;
                end

                S_ERROR: begin
                    // Sticky ERROR until the next START/reset.
                    state <= S_ERROR;
                end

                default: begin
                    busy <= 1'b0;
                    error <= 1'b1;
                    state <= S_ERROR;
                end
            endcase
        end
    end

endmodule

module nova1_soc (

    input logic clk,
    input logic reset

);

    // =========================================================
    // CPU DATA BUS
    // =========================================================

    logic        cpu_mem_read;
    logic        cpu_mem_write;

    logic [31:0] cpu_address;
    logic [31:0] cpu_write_data;
    logic [31:0] cpu_read_data;


    // =========================================================
    // ADDRESS DECODE
    // =========================================================

    logic accel_select;
    logic dmem_select;

    logic accel_read;
    logic accel_write;

    logic dmem_read;
    logic dmem_write;


    // =========================================================
    // DATA MEMORY CPU PORT
    // =========================================================

    logic [31:0] dmem_cpu_read_data;


    // =========================================================
    // AI MMIO
    // =========================================================

    logic [31:0] accel_read_data;

    logic ai_busy;
    logic ai_done;


    // =========================================================
    // DMA <-> MEMORY
    // =========================================================

    logic        dma_mem_read_req;
    logic [31:0] dma_mem_read_address;

    logic [31:0] dma_mem_read_data;
    logic        dma_mem_read_valid;


    logic        dma_mem_write_req;
    logic [31:0] dma_mem_write_address;
    logic [31:0] dma_mem_write_data;


    // =========================================================
    // RISC-V CPU
    // =========================================================

    riscv_cpu_bus CPU (

        .clk(clk),
        .reset(reset),

        .data_mem_read(cpu_mem_read),
        .data_mem_write(cpu_mem_write),

        .data_address(cpu_address),
        .data_write_data(cpu_write_data),

        .data_read_data(cpu_read_data)

    );


    // =========================================================
    // ADDRESS DECODER
    //
    // AI accelerator:
    //
    // 0x4000_0000 - 0x4000_00FF
    //
    // Everything else goes to normal data memory.
    // =========================================================

    always_comb begin

        if (
            (cpu_address >= 32'h4000_0000) &&
            (cpu_address <= 32'h4000_00FF)
        ) begin

            accel_select = 1'b1;
            dmem_select  = 1'b0;

        end

        else begin

            accel_select = 1'b0;
            dmem_select  = 1'b1;

        end

    end


    // =========================================================
    // CPU CONTROL SIGNAL ROUTING
    // =========================================================

    assign accel_read =
        cpu_mem_read &&
        accel_select;

    assign accel_write =
        cpu_mem_write &&
        accel_select;


    assign dmem_read =
        cpu_mem_read &&
        dmem_select;

    assign dmem_write =
        cpu_mem_write &&
        dmem_select;


    // =========================================================
    // CPU READ DATA MUX
    // =========================================================

    always_comb begin

        if (accel_select)

            cpu_read_data =
                accel_read_data;

        else

            cpu_read_data =
                dmem_cpu_read_data;

    end


    // =========================================================
// AI SUBSYSTEM
//
// Contains:
//
// MMIO register block
// programmable CNN network engine
// layer controller
// channel-request DMA
// stride support
// multi-channel convolution
// parallel filter lanes
// bias / ReLU / INT8 requantization
// ping-pong feature memory interface
// =========================================================

    nova1_ai_subsystem #(
        .MAX_WIDTH(4096),
	.MAX_OUTPUTS(64)
    ) AI_SUBSYSTEM (

        .clk(clk),
        .reset(reset),

        // CPU MMIO

        .accel_read(accel_read),
        .accel_write(accel_write),

        .address(cpu_address),
        .write_data(cpu_write_data),

        .read_data(accel_read_data),


        // DMA memory READ

        .dma_mem_read_req(
            dma_mem_read_req
        ),

        .dma_mem_read_address(
            dma_mem_read_address
        ),

        .dma_mem_read_data(
            dma_mem_read_data
        ),

        .dma_mem_read_valid(
            dma_mem_read_valid
        ),


        // DMA memory WRITE

        .dma_mem_write_req(
            dma_mem_write_req
        ),

        .dma_mem_write_address(
            dma_mem_write_address
        ),

        .dma_mem_write_data(
            dma_mem_write_data
        ),


        // AI status

        .busy(ai_busy),
        .done(ai_done)

    );


    // =========================================================
    // SHARED DATA MEMORY
    //
    // CPU:
    //     LW / SW
    //
    // DMA:
    //     reads image
    //     writes CNN feature map
    // =========================================================

    data_memory #(
        .MEM_DEPTH(262144)
    ) DMEM (

        .clk(clk),


        // -----------------------------------------------------
        // CPU PORT
        // -----------------------------------------------------

        .cpu_mem_read(
            dmem_read
        ),

        .cpu_mem_write(
            dmem_write
        ),

        .cpu_address(
            cpu_address
        ),

        .cpu_write_data(
            cpu_write_data
        ),

        .cpu_read_data(
            dmem_cpu_read_data
        ),


        // -----------------------------------------------------
        // DMA READ PORT
        // -----------------------------------------------------

        .dma_mem_read_req(
            dma_mem_read_req
        ),

        .dma_mem_read_address(
            dma_mem_read_address
        ),

        .dma_mem_read_data(
            dma_mem_read_data
        ),

        .dma_mem_read_valid(
            dma_mem_read_valid
        ),


        // -----------------------------------------------------
        // DMA WRITE PORT
        // -----------------------------------------------------

        .dma_mem_write_req(
            dma_mem_write_req
        ),

        .dma_mem_write_address(
            dma_mem_write_address
        ),

        .dma_mem_write_data(
            dma_mem_write_data
        )

    );


endmodule

module parallel_filter_bank #(
    parameter integer FILTER_LANES = 4
)(
    input logic clk,
    input logic reset,

    input logic window_valid,

    // =========================================================
    // 3x3 WINDOW
    // =========================================================

    input logic signed [7:0] w00,
    input logic signed [7:0] w01,
    input logic signed [7:0] w02,

    input logic signed [7:0] w10,
    input logic signed [7:0] w11,
    input logic signed [7:0] w12,

    input logic signed [7:0] w20,
    input logic signed [7:0] w21,
    input logic signed [7:0] w22,

    // =========================================================
    // FILTER 0 WEIGHTS
    // =========================================================

    input logic signed [7:0] f0_k00,
    input logic signed [7:0] f0_k01,
    input logic signed [7:0] f0_k02,

    input logic signed [7:0] f0_k10,
    input logic signed [7:0] f0_k11,
    input logic signed [7:0] f0_k12,

    input logic signed [7:0] f0_k20,
    input logic signed [7:0] f0_k21,
    input logic signed [7:0] f0_k22,

    // =========================================================
    // FILTER 1 WEIGHTS
    // =========================================================

    input logic signed [7:0] f1_k00,
    input logic signed [7:0] f1_k01,
    input logic signed [7:0] f1_k02,

    input logic signed [7:0] f1_k10,
    input logic signed [7:0] f1_k11,
    input logic signed [7:0] f1_k12,

    input logic signed [7:0] f1_k20,
    input logic signed [7:0] f1_k21,
    input logic signed [7:0] f1_k22,

    // =========================================================
    // FILTER 2 WEIGHTS
    // =========================================================

    input logic signed [7:0] f2_k00,
    input logic signed [7:0] f2_k01,
    input logic signed [7:0] f2_k02,

    input logic signed [7:0] f2_k10,
    input logic signed [7:0] f2_k11,
    input logic signed [7:0] f2_k12,

    input logic signed [7:0] f2_k20,
    input logic signed [7:0] f2_k21,
    input logic signed [7:0] f2_k22,

    // =========================================================
    // FILTER 3 WEIGHTS
    // =========================================================

    input logic signed [7:0] f3_k00,
    input logic signed [7:0] f3_k01,
    input logic signed [7:0] f3_k02,

    input logic signed [7:0] f3_k10,
    input logic signed [7:0] f3_k11,
    input logic signed [7:0] f3_k12,

    input logic signed [7:0] f3_k20,
    input logic signed [7:0] f3_k21,
    input logic signed [7:0] f3_k22,

    // =========================================================
    // OUTPUTS
    // =========================================================

    output logic signed [31:0] result0,
    output logic signed [31:0] result1,
    output logic signed [31:0] result2,
    output logic signed [31:0] result3,

    output logic result_valid
);


    // =========================================================
    // FILTER 0 INTERNAL
    // =========================================================

    logic signed [31:0] result0_i;
    logic valid0;


    // =========================================================
    // FILTER 1 INTERNAL
    // =========================================================

    logic signed [31:0] result1_i;
    logic valid1;


    // =========================================================
    // FILTER 2 INTERNAL
    // =========================================================

    logic signed [31:0] result2_i;
    logic valid2;


    // =========================================================
    // FILTER 3 INTERNAL
    // =========================================================

    logic signed [31:0] result3_i;
    logic valid3;


    // =========================================================
    // FILTER 0
    // =========================================================

    conv3x3_engine FILTER0 (

        .clk(clk),
        .reset(reset),

        .window_valid(window_valid),

        .w00(w00),
        .w01(w01),
        .w02(w02),

        .w10(w10),
        .w11(w11),
        .w12(w12),

        .w20(w20),
        .w21(w21),
        .w22(w22),

        .k00(f0_k00),
        .k01(f0_k01),
        .k02(f0_k02),

        .k10(f0_k10),
        .k11(f0_k11),
        .k12(f0_k12),

        .k20(f0_k20),
        .k21(f0_k21),
        .k22(f0_k22),

        .result(result0_i),
        .result_valid(valid0)

    );


    // =========================================================
    // FILTER 1
    // =========================================================

    conv3x3_engine FILTER1 (

        .clk(clk),
        .reset(reset),

        .window_valid(window_valid),

        .w00(w00),
        .w01(w01),
        .w02(w02),

        .w10(w10),
        .w11(w11),
        .w12(w12),

        .w20(w20),
        .w21(w21),
        .w22(w22),

        .k00(f1_k00),
        .k01(f1_k01),
        .k02(f1_k02),

        .k10(f1_k10),
        .k11(f1_k11),
        .k12(f1_k12),

        .k20(f1_k20),
        .k21(f1_k21),
        .k22(f1_k22),

        .result(result1_i),
        .result_valid(valid1)

    );


    // =========================================================
    // FILTER 2
    // =========================================================

    conv3x3_engine FILTER2 (

        .clk(clk),
        .reset(reset),

        .window_valid(window_valid),

        .w00(w00),
        .w01(w01),
        .w02(w02),

        .w10(w10),
        .w11(w11),
        .w12(w12),

        .w20(w20),
        .w21(w21),
        .w22(w22),

        .k00(f2_k00),
        .k01(f2_k01),
        .k02(f2_k02),

        .k10(f2_k10),
        .k11(f2_k11),
        .k12(f2_k12),

        .k20(f2_k20),
        .k21(f2_k21),
        .k22(f2_k22),

        .result(result2_i),
        .result_valid(valid2)

    );


    // =========================================================
    // FILTER 3
    // =========================================================

    conv3x3_engine FILTER3 (

        .clk(clk),
        .reset(reset),

        .window_valid(window_valid),

        .w00(w00),
        .w01(w01),
        .w02(w02),

        .w10(w10),
        .w11(w11),
        .w12(w12),

        .w20(w20),
        .w21(w21),
        .w22(w22),

        .k00(f3_k00),
        .k01(f3_k01),
        .k02(f3_k02),

        .k10(f3_k10),
        .k11(f3_k11),
        .k12(f3_k12),

        .k20(f3_k20),
        .k21(f3_k21),
        .k22(f3_k22),

        .result(result3_i),
        .result_valid(valid3)

    );


    // =========================================================
    // OUTPUT
    // =========================================================

    always_comb begin

        result0 =
            result0_i;

        result1 =
            result1_i;

        result2 =
            result2_i;

        result3 =
            result3_i;


        // All four engines receive same window_valid and have
        // identical latency, so their valid signals should align.

        result_valid =
            valid0 &
            valid1 &
            valid2 &
            valid3;

    end


endmodule

module parallel_multi_channel_conv_top #(
    parameter integer MAX_WIDTH   = 4096,
    parameter integer MAX_OUTPUTS = 8294400
)(
    input logic clk,
    input logic reset,

    input logic [15:0] image_width,
    input logic [15:0] image_height,

    input logic [15:0] input_channels,

    // NEW
    input logic [1:0] stride,

    input logic [15:0] channel_index,
    input logic        channel_start,

    input logic signed [7:0] pixel_in,
    input logic              pixel_valid,


    // =========================================================
    // FILTER 0
    // =========================================================

    input logic signed [7:0] f0_k00,
    input logic signed [7:0] f0_k01,
    input logic signed [7:0] f0_k02,
    input logic signed [7:0] f0_k10,
    input logic signed [7:0] f0_k11,
    input logic signed [7:0] f0_k12,
    input logic signed [7:0] f0_k20,
    input logic signed [7:0] f0_k21,
    input logic signed [7:0] f0_k22,


    // =========================================================
    // FILTER 1
    // =========================================================

    input logic signed [7:0] f1_k00,
    input logic signed [7:0] f1_k01,
    input logic signed [7:0] f1_k02,
    input logic signed [7:0] f1_k10,
    input logic signed [7:0] f1_k11,
    input logic signed [7:0] f1_k12,
    input logic signed [7:0] f1_k20,
    input logic signed [7:0] f1_k21,
    input logic signed [7:0] f1_k22,


    // =========================================================
    // FILTER 2
    // =========================================================

    input logic signed [7:0] f2_k00,
    input logic signed [7:0] f2_k01,
    input logic signed [7:0] f2_k02,
    input logic signed [7:0] f2_k10,
    input logic signed [7:0] f2_k11,
    input logic signed [7:0] f2_k12,
    input logic signed [7:0] f2_k20,
    input logic signed [7:0] f2_k21,
    input logic signed [7:0] f2_k22,


    // =========================================================
    // FILTER 3
    // =========================================================

    input logic signed [7:0] f3_k00,
    input logic signed [7:0] f3_k01,
    input logic signed [7:0] f3_k02,
    input logic signed [7:0] f3_k10,
    input logic signed [7:0] f3_k11,
    input logic signed [7:0] f3_k12,
    input logic signed [7:0] f3_k20,
    input logic signed [7:0] f3_k21,
    input logic signed [7:0] f3_k22,


    input logic signed [31:0] bias0,
    input logic signed [31:0] bias1,
    input logic signed [31:0] bias2,
    input logic signed [31:0] bias3,

    input logic [4:0] quant_shift0,
    input logic [4:0] quant_shift1,
    input logic [4:0] quant_shift2,
    input logic [4:0] quant_shift3,


    output logic signed [7:0] feature0,
    output logic signed [7:0] feature1,
    output logic signed [7:0] feature2,
    output logic signed [7:0] feature3,

    output logic feature_valid,

    output logic [31:0] feature_index
);


    // =========================================================
    // WINDOW
    // =========================================================

    logic signed [7:0] w00, w01, w02;
    logic signed [7:0] w10, w11, w12;
    logic signed [7:0] w20, w21, w22;

    logic window_valid;

    logic stride_window_valid;


    logic [15:0] stride_window_row;
    logic [15:0] stride_window_col;


    // =========================================================
    // OUTPUT GEOMETRY
    // =========================================================

    logic [15:0] base_output_width;
    logic [15:0] base_output_height;

    logic [31:0] outputs_per_channel;


    always_comb begin

        if (
            (image_width >= 16'd3) &&
            (image_height >= 16'd3)
        ) begin

            base_output_width =
                image_width - 16'd2;

            base_output_height =
                image_height - 16'd2;


            // =============================================
            // STRIDE 2:
            //
            // floor((W-3)/2)+1
            //
            // equivalent for valid 3x3:
            //
            // ceil((W-2)/2)
            // =============================================

            if (stride == 2'd2) begin

                outputs_per_channel =

                    (
                        (base_output_width + 1)
                        >> 1
                    )

                    *

                    (
                        (base_output_height + 1)
                        >> 1
                    );

            end

            else begin

                outputs_per_channel =

                    base_output_width
                    *
                    base_output_height;

            end

        end

        else begin

            base_output_width =
                16'd0;

            base_output_height =
                16'd0;

            outputs_per_channel =
                32'd0;

        end

    end


    // =========================================================
    // WINDOW GENERATOR
    // =========================================================

    stream_window_3x3 #(
        .MAX_WIDTH(MAX_WIDTH)
    ) WINDOW_GENERATOR (

        .clk(clk),
        .reset(reset),

        .channel_start(channel_start),

        .image_width(image_width),
        .image_height(image_height),

        .pixel_in(pixel_in),
        .pixel_valid(pixel_valid),

        .w00(w00),
        .w01(w01),
        .w02(w02),

        .w10(w10),
        .w11(w11),
        .w12(w12),

        .w20(w20),
        .w21(w21),
        .w22(w22),

        .window_valid(window_valid)

    );


    // =========================================================
    // STRIDE SELECTOR
    // =========================================================

    stride_control STRIDE_CONTROL (

        .clk(clk),
        .reset(reset),

        .window_valid(window_valid),

        .channel_start(channel_start),

        .base_output_width(
            base_output_width
        ),

        .base_output_height(
            base_output_height
        ),

        .stride(stride),

        .stride_window_valid(
            stride_window_valid
        ),

        .window_row(
            stride_window_row
        ),

        .window_col(
            stride_window_col
        )

    );


    // =========================================================
    // PARALLEL CONVOLUTION
    // =========================================================

    logic signed [31:0] conv0;
    logic signed [31:0] conv1;
    logic signed [31:0] conv2;
    logic signed [31:0] conv3;

    logic conv_valid;


    parallel_filter_bank #(
        .FILTER_LANES(4)
    ) FILTER_BANK (

        .clk(clk),
        .reset(reset),

        // IMPORTANT:
        // Only accepted stride windows enter the MAC array.

        .window_valid(
            stride_window_valid
        ),

        .w00(w00), .w01(w01), .w02(w02),
        .w10(w10), .w11(w11), .w12(w12),
        .w20(w20), .w21(w21), .w22(w22),

        .f0_k00(f0_k00), .f0_k01(f0_k01), .f0_k02(f0_k02),
        .f0_k10(f0_k10), .f0_k11(f0_k11), .f0_k12(f0_k12),
        .f0_k20(f0_k20), .f0_k21(f0_k21), .f0_k22(f0_k22),

        .f1_k00(f1_k00), .f1_k01(f1_k01), .f1_k02(f1_k02),
        .f1_k10(f1_k10), .f1_k11(f1_k11), .f1_k12(f1_k12),
        .f1_k20(f1_k20), .f1_k21(f1_k21), .f1_k22(f1_k22),

        .f2_k00(f2_k00), .f2_k01(f2_k01), .f2_k02(f2_k02),
        .f2_k10(f2_k10), .f2_k11(f2_k11), .f2_k12(f2_k12),
        .f2_k20(f2_k20), .f2_k21(f2_k21), .f2_k22(f2_k22),

        .f3_k00(f3_k00), .f3_k01(f3_k01), .f3_k02(f3_k02),
        .f3_k10(f3_k10), .f3_k11(f3_k11), .f3_k12(f3_k12),
        .f3_k20(f3_k20), .f3_k21(f3_k21), .f3_k22(f3_k22),

        .result0(conv0),
        .result1(conv1),
        .result2(conv2),
        .result3(conv3),

        .result_valid(conv_valid)

    );


    // =========================================================
    // METADATA
    // =========================================================

    logic [31:0] output_index_counter;
    logic [31:0] conv_output_index;

    logic [15:0] conv_channel_index;


    always_ff @(posedge clk) begin

        if (reset) begin

            output_index_counter <=
                32'd0;

            conv_output_index <=
                32'd0;

            conv_channel_index <=
                16'd0;

        end

        else begin

            if (channel_start) begin

                output_index_counter <=
                    32'd0;

            end


            if (stride_window_valid) begin

                conv_output_index <=
                    output_index_counter;

                conv_channel_index <=
                    channel_index;


                if (
                    (output_index_counter + 1)
                    >=
                    outputs_per_channel
                ) begin

                    output_index_counter <=
                        32'd0;

                end

                else begin

                    output_index_counter <=
                        output_index_counter + 1'b1;

                end

            end

        end

    end


    // =========================================================
    // FOUR CHANNEL ACCUMULATORS
    // =========================================================

    logic signed [31:0] sum0, sum1, sum2, sum3;

    logic sum_valid0;
    logic sum_valid1;
    logic sum_valid2;
    logic sum_valid3;


    channel_sum_buffer #(
        .MAX_OUTPUTS(MAX_OUTPUTS)
    ) SUM0 (
        .clk(clk),
        .reset(reset),
        .input_channels(input_channels),
        .channel_index(conv_channel_index),
        .output_index(conv_output_index),
        .channel_result(conv0),
        .channel_valid(conv_valid),
        .accumulated_result(sum0),
        .accumulated_valid(sum_valid0)
    );


    channel_sum_buffer #(
        .MAX_OUTPUTS(MAX_OUTPUTS)
    ) SUM1 (
        .clk(clk),
        .reset(reset),
        .input_channels(input_channels),
        .channel_index(conv_channel_index),
        .output_index(conv_output_index),
        .channel_result(conv1),
        .channel_valid(conv_valid),
        .accumulated_result(sum1),
        .accumulated_valid(sum_valid1)
    );


    channel_sum_buffer #(
        .MAX_OUTPUTS(MAX_OUTPUTS)
    ) SUM2 (
        .clk(clk),
        .reset(reset),
        .input_channels(input_channels),
        .channel_index(conv_channel_index),
        .output_index(conv_output_index),
        .channel_result(conv2),
        .channel_valid(conv_valid),
        .accumulated_result(sum2),
        .accumulated_valid(sum_valid2)
    );


    channel_sum_buffer #(
        .MAX_OUTPUTS(MAX_OUTPUTS)
    ) SUM3 (
        .clk(clk),
        .reset(reset),
        .input_channels(input_channels),
        .channel_index(conv_channel_index),
        .output_index(conv_output_index),
        .channel_result(conv3),
        .channel_valid(conv_valid),
        .accumulated_result(sum3),
        .accumulated_valid(sum_valid3)
    );


    // =========================================================
    // POSTPROCESS
    // =========================================================

    logic signed [7:0] q0, q1, q2, q3;

    logic qv0, qv1, qv2, qv3;


    cnn_postprocess POST0 (
        .accumulator(sum0),
        .bias(bias0),
        .quant_shift(quant_shift0),
        .valid_in(sum_valid0),
        .feature_out(q0),
        .valid_out(qv0)
    );


    cnn_postprocess POST1 (
        .accumulator(sum1),
        .bias(bias1),
        .quant_shift(quant_shift1),
        .valid_in(sum_valid1),
        .feature_out(q1),
        .valid_out(qv1)
    );


    cnn_postprocess POST2 (
        .accumulator(sum2),
        .bias(bias2),
        .quant_shift(quant_shift2),
        .valid_in(sum_valid2),
        .feature_out(q2),
        .valid_out(qv2)
    );


    cnn_postprocess POST3 (
        .accumulator(sum3),
        .bias(bias3),
        .quant_shift(quant_shift3),
        .valid_in(sum_valid3),
        .feature_out(q3),
        .valid_out(qv3)
    );


    // =========================================================
    // FINAL FEATURE INDEX
    // =========================================================

    logic [31:0] feature_counter;


    always_ff @(posedge clk) begin

        if (reset) begin

            feature_counter <=
                32'd0;

        end

        else if (
            qv0 && qv1 && qv2 && qv3
        ) begin

            if (
                (feature_counter + 1)
                >=
                outputs_per_channel
            ) begin

                feature_counter <=
                    32'd0;

            end

            else begin

                feature_counter <=
                    feature_counter + 1'b1;

            end

        end

    end


    always_comb begin

        feature0 =
            q0;

        feature1 =
            q1;

        feature2 =
            q2;

        feature3 =
            q3;


        feature_valid =
            qv0 & qv1 & qv2 & qv3;


        feature_index =
            feature_counter;

    end


endmodule

module program_counter (
    input  logic        clk,
    input  logic        reset,
    input  logic [31:0] next_pc,
    output logic [31:0] pc
);

    always_ff @(posedge clk) begin
        if (reset)
            pc <= 32'h00000000;
        else
            pc <= next_pc;
    end

endmodule

module register_file (
    input  logic        clk,
    input  logic        reset,

    // Read ports
    input  logic [4:0]  rs1,
    input  logic [4:0]  rs2,
    output logic [31:0] read_data1,
    output logic [31:0] read_data2,

    // Write port
    input  logic [4:0]  rd,
    input  logic [31:0] write_data,
    input  logic        reg_write
);

    // 32 registers, each 32 bits wide
    logic [31:0] registers [0:31];

    integer i;

    // --------------------------------
    // WRITE LOGIC
    // --------------------------------
    always_ff @(posedge clk or posedge reset) begin

        if (reset) begin

            // Reset all registers to 0
            for (i = 0; i < 32; i = i + 1)
                registers[i] <= 32'b0;

        end

        else if (reg_write && (rd != 5'd0)) begin

            // x0 cannot be written
            registers[rd] <= write_data;

        end

    end


    // --------------------------------
    // READ PORT 1
    // --------------------------------
    always_comb begin

        if (rs1 == 5'd0)
            read_data1 = 32'b0;
        else
            read_data1 = registers[rs1];

    end


    // --------------------------------
    // READ PORT 2
    // --------------------------------
    always_comb begin

        if (rs2 == 5'd0)
            read_data2 = 32'b0;
        else
            read_data2 = registers[rs2];

    end

endmodule

module relu (

    input  logic signed [31:0] data_in,
    input  logic               valid_in,

    output logic signed [31:0] data_out,
    output logic               valid_out

);

    always_comb begin

        valid_out = valid_in;

        if (data_in < 0)
            data_out = 32'sd0;
        else
            data_out = data_in;

    end

endmodule

module requantize_int8 (

    input  logic signed [31:0] data_in,

    // Scaling:
    // output ? data_in / (2^shift_amount)
    input  logic [4:0] shift_amount,

    output logic signed [7:0] data_out

);

    logic signed [31:0] scaled_value;


    always_comb begin

        // =====================================================
        // FIXED-POINT SCALING
        // =====================================================

        // Arithmetic right shift preserves the sign.
        //
        // Example:
        // data_in = 400
        // shift_amount = 2
        //
        // 400 / 4 = 100

        scaled_value = data_in >>> shift_amount;


        // =====================================================
        // INT8 SATURATION
        // =====================================================

        if (scaled_value > 32'sd127) begin

            data_out = 8'sd127;

        end

        else if (scaled_value < -32'sd128) begin

            data_out = -8'sd128;

        end

        else begin

            data_out = scaled_value[7:0];

        end

    end

endmodule

module result_buffer #(

    parameter DEPTH      = 36,
    parameter ADDR_WIDTH = 6,
    parameter DATA_WIDTH = 32

)(

    input logic clk,
    input logic rst,

    // Write port
    input logic                      wr_en,
    input logic [ADDR_WIDTH-1:0]     wr_addr,
    input logic signed [DATA_WIDTH-1:0] wr_data,

    // Read port
    input  logic [ADDR_WIDTH-1:0]       rd_addr,
    output logic signed [DATA_WIDTH-1:0] rd_data

);

    // =========================================================
    // RESULT MEMORY
    //
    // For 8x8 image + 3x3 convolution:
    //
    // (8-3+1) x (8-3+1)
    // = 6 x 6
    // = 36 results
    // =========================================================

    logic signed [DATA_WIDTH-1:0] memory [0:DEPTH-1];


    // =========================================================
    // WRITE
    // =========================================================

    always_ff @(posedge clk) begin

        if (wr_en) begin

            if (wr_addr < DEPTH)
                memory[wr_addr] <= wr_data;

        end

    end


    // =========================================================
    // ASYNCHRONOUS READ
    // =========================================================

    always_comb begin

        if (rd_addr < DEPTH)
            rd_data = memory[rd_addr];

        else
            rd_data = '0;

    end


endmodule

module riscv_cpu_bus (

    input logic clk,
    input logic reset,

    // =========================================================
    // EXTERNAL DATA BUS
    // =========================================================

    output logic        data_mem_read,
    output logic        data_mem_write,

    output logic [31:0] data_address,
    output logic [31:0] data_write_data,

    input  logic [31:0] data_read_data

);


    // =========================================================
    // PROGRAM COUNTER
    // =========================================================

    logic [31:0] pc;
    logic [31:0] next_pc;
    logic [31:0] pc_plus_4;


    // =========================================================
    // INSTRUCTION
    // =========================================================

    logic [31:0] instruction;


    // =========================================================
    // DECODER SIGNALS
    // =========================================================

    logic [6:0] opcode;

    logic [4:0] rd;
    logic [4:0] rs1;
    logic [4:0] rs2;

    logic [2:0] funct3;
    logic [6:0] funct7;

    logic [2:0] instr_type;


    // =========================================================
    // CONTROL SIGNALS
    // =========================================================

    logic reg_write;
    logic alu_src;

    logic mem_read;
    logic mem_write;

    logic mem_to_reg;

    logic branch;
    logic jump;
    logic jalr;

    // NEW
    logic lui;

    logic [3:0] alu_control;


    // =========================================================
    // REGISTER FILE
    // =========================================================

    logic [31:0] read_data1;
    logic [31:0] read_data2;

    logic [31:0] write_back_data;


    // =========================================================
    // IMMEDIATE
    // =========================================================

    logic [31:0] immediate;


    // =========================================================
    // ALU
    // =========================================================

    logic [31:0] alu_operand_a;
    logic [31:0] alu_operand_b;

    logic [31:0] alu_result;

    logic zero;


    // =========================================================
    // WRITEBACK
    // =========================================================

    logic [1:0] wb_sel;

    logic [31:0] pc_plus_4_value;


    // =========================================================
    // PROGRAM COUNTER
    // =========================================================

    program_counter PC (

        .clk     (clk),
        .reset   (reset),

        .next_pc (next_pc),

        .pc      (pc)

    );


    assign pc_plus_4 = pc + 32'd4;


    // =========================================================
    // INSTRUCTION MEMORY
    // =========================================================

    instruction_memory IMEM (

        .address     (pc),

        .instruction (instruction)

    );


    // =========================================================
    // INSTRUCTION DECODER
    // =========================================================

    instruction_decoder DECODER (

        .instruction (instruction),

        .opcode      (opcode),

        .rd          (rd),
        .rs1         (rs1),
        .rs2         (rs2),

        .funct3      (funct3),
        .funct7      (funct7),

        .instr_type  (instr_type)

    );


    // =========================================================
    // CONTROL UNIT
    // =========================================================

    control_unit CONTROL (

        .opcode       (opcode),

        .funct3       (funct3),

        .funct7_bit5  (funct7[5]),

        .reg_write    (reg_write),
        .alu_src      (alu_src),

        .mem_read     (mem_read),
        .mem_write    (mem_write),

        .mem_to_reg   (mem_to_reg),

        .branch       (branch),

        .jump         (jump),
        .jalr         (jalr),

        .lui          (lui),

        .alu_control  (alu_control)

    );


    // =========================================================
    // REGISTER FILE
    // =========================================================

    register_file REGFILE (

        .clk         (clk),
        .reset       (reset),

        .rs1         (rs1),
        .rs2         (rs2),

        .read_data1  (read_data1),
        .read_data2  (read_data2),

        .rd          (rd),

        .write_data  (write_back_data),

        .reg_write   (reg_write)

    );


    // =========================================================
    // IMMEDIATE GENERATOR
    // =========================================================

    immediate_generator IMM_GEN (

        .instruction (instruction),

        .immediate   (immediate)

    );


    // =========================================================
    // ALU OPERAND SELECTION
    //
    // Normal:
    //      operand A = rs1
    //
    // LUI:
    //      operand A = 0
    //
    // Operand B:
    //      register or immediate
    // =========================================================

    always_comb begin

        if (lui)
            alu_operand_a = 32'd0;
        else
            alu_operand_a = read_data1;


        if (alu_src)
            alu_operand_b = immediate;
        else
            alu_operand_b = read_data2;

    end


    // =========================================================
    // ALU
    // =========================================================

    alu ALU (

        .operand_a   (alu_operand_a),

        .operand_b   (alu_operand_b),

        .alu_control (alu_control),

        .result      (alu_result),

        .zero        (zero)

    );


    // =========================================================
    // EXTERNAL DATA BUS
    // =========================================================

    assign data_address =
        alu_result;


    assign data_write_data =
        read_data2;


    assign data_mem_read =
        mem_read;


    assign data_mem_write =
        mem_write;


    // =========================================================
    // WRITEBACK SELECT
    //
    // 00 = ALU
    // 01 = memory
    // 10 = PC + 4
    // =========================================================

    always_comb begin

        if (jump)
            wb_sel = 2'b10;

        else if (mem_to_reg)
            wb_sel = 2'b01;

        else
            wb_sel = 2'b00;

    end


    // =========================================================
    // WRITE BACK
    // =========================================================

    write_back_logic WB (

        .alu_result       (alu_result),

        .memory_data      (data_read_data),

        .pc_plus_4        (pc_plus_4),

        .wb_sel           (wb_sel),

        .write_back_data  (write_back_data),

        .pc_plus_4_value  (pc_plus_4_value)

    );


    // =========================================================
    // BRANCH / JUMP
    // =========================================================

    branch_jump_logic BJ (

        .pc               (pc),

        .rs1_value        (read_data1),
        .rs2_value        (read_data2),

        .branch_immediate (immediate),
        .jump_immediate   (immediate),

        .funct3           (funct3),

        .branch           (branch),

        .jump             (jump),
        .jalr             (jalr),

        .next_pc          (next_pc),

        .branch_taken     ()

    );


endmodule

module riscv_cpu (

    input  logic clk,
    input  logic reset

);

    // =========================================================
    // PC SIGNALS
    // =========================================================

    logic [31:0] pc;
    logic [31:0] next_pc;
    logic [31:0] pc_plus_4;


    // =========================================================
    // INSTRUCTION MEMORY
    // =========================================================

    logic [31:0] instruction;


    // =========================================================
    // INSTRUCTION DECODER SIGNALS
    // =========================================================

    logic [6:0] opcode;
    logic [4:0] rd;
    logic [4:0] rs1;
    logic [4:0] rs2;
    logic [2:0] funct3;
    logic [6:0] funct7;
    logic [2:0] instr_type;


    // =========================================================
    // CONTROL SIGNALS
    // =========================================================

    logic       reg_write;
    logic       alu_src;
    logic       mem_read;
    logic       mem_write;
    logic       mem_to_reg;
    logic       branch;
    logic       jump;
    logic       jalr;

    logic [3:0] alu_control;


    // =========================================================
    // REGISTER FILE SIGNALS
    // =========================================================

    logic [31:0] read_data1;
    logic [31:0] read_data2;

    logic [31:0] write_back_data;


    // =========================================================
    // IMMEDIATE
    // =========================================================

    logic [31:0] immediate;


    // =========================================================
    // ALU
    // =========================================================

    logic [31:0] alu_operand_b;
    logic [31:0] alu_result;
    logic        zero;


    // =========================================================
    // DATA MEMORY
    // =========================================================

    logic [31:0] memory_read_data;


    // =========================================================
    // WRITE-BACK
    // =========================================================

    logic [1:0] wb_sel;
    logic [31:0] pc_plus_4_value;


    // =========================================================
    // PROGRAM COUNTER
    // =========================================================

    program_counter PC (
        .clk     (clk),
        .reset   (reset),
        .next_pc (next_pc),
        .pc      (pc)
    );


    // PC + 4
    assign pc_plus_4 = pc + 32'd4;


    // =========================================================
    // INSTRUCTION MEMORY
    // =========================================================

    instruction_memory IMEM (
        .address     (pc),
        .instruction (instruction)
    );


    // =========================================================
    // INSTRUCTION DECODER
    // =========================================================

    instruction_decoder DECODER (
        .instruction (instruction),

        .opcode      (opcode),
        .rd          (rd),
        .rs1         (rs1),
        .rs2         (rs2),
        .funct3      (funct3),
        .funct7      (funct7),
        .instr_type  (instr_type)
    );


    // =========================================================
    // CONTROL UNIT
    // =========================================================

    control_unit CONTROL (
        .opcode       (opcode),
        .funct3       (funct3),
        .funct7_bit5  (funct7[5]),

        .reg_write    (reg_write),
        .alu_src      (alu_src),
        .mem_read     (mem_read),
        .mem_write    (mem_write),
        .mem_to_reg   (mem_to_reg),
        .branch       (branch),
        .jump         (jump),
        .jalr         (jalr),
        .alu_control  (alu_control)
    );


    // =========================================================
    // REGISTER FILE
    // =========================================================

    register_file REGFILE (
        .clk        (clk),
        .reset      (reset),

        .rs1        (rs1),
        .rs2        (rs2),

        .read_data1 (read_data1),
        .read_data2 (read_data2),

        .rd         (rd),
        .write_data (write_back_data),
        .reg_write  (reg_write)
    );


    // =========================================================
    // IMMEDIATE GENERATOR
    // =========================================================

    immediate_generator IMM_GEN (
        .instruction (instruction),
        .immediate   (immediate)
    );


    // =========================================================
    // ALU INPUT MUX
    // =========================================================

    always_comb begin

        if (alu_src)
            alu_operand_b = immediate;
        else
            alu_operand_b = read_data2;

    end


    // =========================================================
    // ALU
    // =========================================================

    alu ALU (
        .operand_a   (read_data1),
        .operand_b   (alu_operand_b),
        .alu_control (alu_control),

        .result      (alu_result),
        .zero        (zero)
    );


    // =========================================================
    // DATA MEMORY
    // =========================================================

    data_memory DMEM (
        .clk        (clk),
        .mem_read   (mem_read),
        .mem_write  (mem_write),

        .address    (alu_result),
        .write_data (read_data2),

        .read_data  (memory_read_data)
    );


    // =========================================================
    // WRITE-BACK SELECT
    // =========================================================

    always_comb begin

        if (jump)
            wb_sel = 2'b10;

        else if (mem_to_reg)
            wb_sel = 2'b01;

        else
            wb_sel = 2'b00;

    end


    // =========================================================
    // WRITE-BACK LOGIC
    // =========================================================

    write_back_logic WB (
        .alu_result       (alu_result),
        .memory_data      (memory_read_data),
        .pc_plus_4        (pc_plus_4),

        .wb_sel           (wb_sel),

        .write_back_data  (write_back_data)
    );


    // =========================================================
    // BRANCH / JUMP LOGIC
    // =========================================================

    branch_jump_logic BJ (
        .pc               (pc),

        .rs1_value        (read_data1),
        .rs2_value        (read_data2),

        .branch_immediate (immediate),
        .jump_immediate   (immediate),

        .funct3           (funct3),

        .branch           (branch),
        .jump             (jump),
        .jalr             (jalr),

        .next_pc          (next_pc),
        .branch_taken     (/* unused */)
    );

endmodule

module sliding_window_handshake #(

    parameter IMAGE_WIDTH  = 8,
    parameter IMAGE_HEIGHT = 8,
    parameter ADDR_WIDTH   = 6

)(

    input  logic                  clk,
    input  logic                  rst,

    // Start processing complete image
    input  logic                  start,


    // =========================================================
    // IMAGE BUFFER INTERFACE
    // =========================================================

    output logic [ADDR_WIDTH-1:0] rd_addr,
    input  logic signed [7:0]     rd_data,


    // =========================================================
    // 3x3 WINDOW
    // =========================================================

    output logic signed [7:0] p0,
    output logic signed [7:0] p1,
    output logic signed [7:0] p2,

    output logic signed [7:0] p3,
    output logic signed [7:0] p4,
    output logic signed [7:0] p5,

    output logic signed [7:0] p6,
    output logic signed [7:0] p7,
    output logic signed [7:0] p8,


    // =========================================================
    // HANDSHAKE
    // =========================================================

    // 1 = p0-p8 contain a valid window
    output logic window_valid,

    // Accelerator asserts this after accepting the window
    input  logic window_ready,


    // Complete image finished
    output logic done

);


    localparam OUTPUT_WIDTH  = IMAGE_WIDTH  - 2;
    localparam OUTPUT_HEIGHT = IMAGE_HEIGHT - 2;


    localparam IDLE  = 3'd0;
    localparam READ  = 3'd1;
    localparam VALID = 3'd2;
    localparam DONE  = 3'd3;


    logic [2:0] state;

    logic [ADDR_WIDTH-1:0] pixel_index;

    logic [ADDR_WIDTH-1:0] window_row;
    logic [ADDR_WIDTH-1:0] window_col;


    // =========================================================
    // IMAGE BUFFER ADDRESS GENERATION
    // =========================================================

    always_comb begin

        case (pixel_index)

            0:
                rd_addr =
                    (window_row * IMAGE_WIDTH)
                    + window_col;

            1:
                rd_addr =
                    (window_row * IMAGE_WIDTH)
                    + window_col + 1;

            2:
                rd_addr =
                    (window_row * IMAGE_WIDTH)
                    + window_col + 2;


            3:
                rd_addr =
                    ((window_row + 1) * IMAGE_WIDTH)
                    + window_col;

            4:
                rd_addr =
                    ((window_row + 1) * IMAGE_WIDTH)
                    + window_col + 1;

            5:
                rd_addr =
                    ((window_row + 1) * IMAGE_WIDTH)
                    + window_col + 2;


            6:
                rd_addr =
                    ((window_row + 2) * IMAGE_WIDTH)
                    + window_col;

            7:
                rd_addr =
                    ((window_row + 2) * IMAGE_WIDTH)
                    + window_col + 1;

            8:
                rd_addr =
                    ((window_row + 2) * IMAGE_WIDTH)
                    + window_col + 2;


            default:
                rd_addr = '0;

        endcase

    end


    // =========================================================
    // CONTROLLER
    // =========================================================

    always_ff @(posedge clk) begin

        if (rst) begin

            state       <= IDLE;

            pixel_index <= 0;

            window_row  <= 0;
            window_col  <= 0;


            p0 <= 0;
            p1 <= 0;
            p2 <= 0;

            p3 <= 0;
            p4 <= 0;
            p5 <= 0;

            p6 <= 0;
            p7 <= 0;
            p8 <= 0;


            window_valid <= 1'b0;

            done <= 1'b0;

        end

        else begin

            done <= 1'b0;


            case (state)


                // =================================================
                // IDLE
                // =================================================

                IDLE: begin

                    window_valid <= 1'b0;

                    if (start) begin

                        window_row  <= 0;
                        window_col  <= 0;

                        pixel_index <= 0;

                        state <= READ;

                    end

                end


                // =================================================
                // READ 9 PIXELS
                // =================================================

                READ: begin

                    window_valid <= 1'b0;


                    case (pixel_index)

                        0: p0 <= rd_data;
                        1: p1 <= rd_data;
                        2: p2 <= rd_data;

                        3: p3 <= rd_data;
                        4: p4 <= rd_data;
                        5: p5 <= rd_data;

                        6: p6 <= rd_data;
                        7: p7 <= rd_data;
                        8: p8 <= rd_data;

                        default: begin
                        end

                    endcase


                    if (pixel_index == 8) begin

                        pixel_index <= 0;

                        state <= VALID;

                    end

                    else begin

                        pixel_index <= pixel_index + 1;

                    end

                end


                // =================================================
                // WINDOW READY
                //
                // IMPORTANT:
                //
                // Remain here until convolution controller
                // accepts this window.
                // =================================================

                VALID: begin

                    window_valid <= 1'b1;


                    if (window_ready) begin

                        window_valid <= 1'b0;


                        // -----------------------------------------
                        // NEXT COLUMN
                        // -----------------------------------------

                        if (window_col < OUTPUT_WIDTH - 1) begin

                            window_col <= window_col + 1;

                            state <= READ;

                        end


                        // -----------------------------------------
                        // NEXT ROW
                        // -----------------------------------------

                        else if (
                            window_row < OUTPUT_HEIGHT - 1
                        ) begin

                            window_col <= 0;

                            window_row <= window_row + 1;

                            state <= READ;

                        end


                        // -----------------------------------------
                        // LAST WINDOW
                        // -----------------------------------------

                        else begin

                            state <= DONE;

                        end

                    end

                end


                // =================================================
                // DONE
                // =================================================

                DONE: begin

                    window_valid <= 1'b0;

                    done <= 1'b1;

                    state <= IDLE;

                end


                default: begin

                    state <= IDLE;

                    window_valid <= 1'b0;

                end

            endcase

        end

    end

endmodule

module stream_window_3x3 #(
    parameter integer MAX_WIDTH = 4096
)(
    input  logic clk,
    input  logic reset,

    // Pulse aligned with the first pixel of a new channel plane
    input  logic channel_start,

    input  logic [15:0] image_width,
    input  logic [15:0] image_height,

    input  logic signed [7:0] pixel_in,
    input  logic              pixel_valid,

    output logic signed [7:0] w00,
    output logic signed [7:0] w01,
    output logic signed [7:0] w02,

    output logic signed [7:0] w10,
    output logic signed [7:0] w11,
    output logic signed [7:0] w12,

    output logic signed [7:0] w20,
    output logic signed [7:0] w21,
    output logic signed [7:0] w22,

    output logic window_valid
);

    // =========================================================
    // TWO LINE BUFFERS
    // =========================================================

    logic signed [7:0] line1 [0:MAX_WIDTH-1];
    logic signed [7:0] line2 [0:MAX_WIDTH-1];


    // =========================================================
    // CURRENT POSITION
    // =========================================================

    logic [15:0] row;
    logic [15:0] col;


    // =========================================================
    // HORIZONTAL HISTORY
    // =========================================================

    logic signed [7:0] top_left;
    logic signed [7:0] top_mid;

    logic signed [7:0] mid_left;
    logic signed [7:0] mid_mid;

    logic signed [7:0] bot_left;
    logic signed [7:0] bot_mid;


    logic signed [7:0] prev_row_pixel;
    logic signed [7:0] prev2_row_pixel;


    // =========================================================
    // MAIN WINDOW GENERATOR
    // =========================================================

    always_ff @(posedge clk) begin

        if (reset) begin

            row <= 16'd0;
            col <= 16'd0;

            top_left <= 8'sd0;
            top_mid  <= 8'sd0;

            mid_left <= 8'sd0;
            mid_mid  <= 8'sd0;

            bot_left <= 8'sd0;
            bot_mid  <= 8'sd0;

            w00 <= 8'sd0;
            w01 <= 8'sd0;
            w02 <= 8'sd0;

            w10 <= 8'sd0;
            w11 <= 8'sd0;
            w12 <= 8'sd0;

            w20 <= 8'sd0;
            w21 <= 8'sd0;
            w22 <= 8'sd0;

            window_valid <= 1'b0;

        end

        else begin

            // Default: window-valid is a pulse
            window_valid <= 1'b0;


            // =================================================
            // NEW CHANNEL + FIRST PIXEL
            //
            // IMPORTANT:
            // channel_start arrives together with the first
            // valid pixel, so we must NOT throw that pixel away.
            // =================================================

            if (channel_start && pixel_valid) begin

                row <= 16'd0;

                // First pixel belongs to column 0.
                // Next incoming pixel will be column 1.
                if (image_width > 16'd1)
                    col <= 16'd1;
                else
                    col <= 16'd0;


                // Clear horizontal history from previous channel.
                top_left <= 8'sd0;
                top_mid  <= 8'sd0;

                mid_left <= 8'sd0;
                mid_mid  <= 8'sd0;

                bot_left <= 8'sd0;
                bot_mid  <= pixel_in;


                // Start new channel's line-buffer history.
                //
                // No need to clear all 4096 entries:
                // by the time row 2 becomes valid, rows 0 and 1
                // of the new channel have overwritten the stale
                // entries from the previous channel.

                line2[0] <= line1[0];
                line1[0] <= pixel_in;


                // No valid window on first pixel.
                window_valid <= 1'b0;

            end


            // =================================================
            // NORMAL PIXEL PROCESSING
            // =================================================

            else if (pixel_valid) begin

                // Existing contents represent previous rows.

                prev_row_pixel  = line1[col];
                prev2_row_pixel = line2[col];


                // Shift vertical line-buffer history.

                line2[col] <= prev_row_pixel;
                line1[col] <= pixel_in;


                // Shift horizontal history.

                top_left <= top_mid;
                top_mid  <= prev2_row_pixel;

                mid_left <= mid_mid;
                mid_mid  <= prev_row_pixel;

                bot_left <= bot_mid;
                bot_mid  <= pixel_in;


                // Construct current 3x3 window.

                w00 <= top_left;
                w01 <= top_mid;
                w02 <= prev2_row_pixel;

                w10 <= mid_left;
                w11 <= mid_mid;
                w12 <= prev_row_pixel;

                w20 <= bot_left;
                w21 <= bot_mid;
                w22 <= pixel_in;


                // Valid after at least 3 rows and 3 columns.

                if (
                    (row >= 16'd2) &&
                    (col >= 16'd2)
                )
                    window_valid <= 1'b1;


                // =================================================
                // ADVANCE POSITION
                // =================================================

                if (col == image_width - 1'b1) begin

                    col <= 16'd0;


                    // New row:
                    // horizontal history must restart.

                    top_left <= 8'sd0;
                    top_mid  <= 8'sd0;

                    mid_left <= 8'sd0;
                    mid_mid  <= 8'sd0;

                    bot_left <= 8'sd0;
                    bot_mid  <= 8'sd0;


                    if (row == image_height - 1'b1)
                        row <= 16'd0;
                    else
                        row <= row + 1'b1;

                end

                else begin

                    col <= col + 1'b1;

                end

            end

        end

    end

endmodule

module stride_control (

    input logic clk,
    input logic reset,

    // Valid 3x3 window from stream_window_3x3
    input logic window_valid,

    // New input-channel plane starts
    input logic channel_start,

    // Number of valid stride-1 convolution positions
    //
    // For valid 3x3:
    // base_output_width  = image_width  - 2
    // base_output_height = image_height - 2
    input logic [15:0] base_output_width,
    input logic [15:0] base_output_height,

    // Supported:
    // 1 = normal convolution
    // 2 = stride-2 convolution
    input logic [1:0] stride,

    // Window accepted by convolution engine
    output logic stride_window_valid,

    // Coordinates in the stride-1 output grid
    output logic [15:0] window_row,
    output logic [15:0] window_col
);


    logic [15:0] row_counter;
    logic [15:0] col_counter;


    // =========================================================
    // ACCEPT / DROP CURRENT WINDOW
    // =========================================================

    always_comb begin

        stride_window_valid =
            1'b0;


        if (window_valid) begin

            case (stride)

                // =============================================
                // STRIDE 1
                // =============================================

                2'd1: begin

                    stride_window_valid =
                        1'b1;

                end


                // =============================================
                // STRIDE 2
                //
                // Keep:
                //
                // row 0,2,4,...
                // col 0,2,4,...
                // =============================================

                2'd2: begin

                    if (
                        (row_counter[0] == 1'b0)
                        &&
                        (col_counter[0] == 1'b0)
                    ) begin

                        stride_window_valid =
                            1'b1;

                    end

                end


                // =============================================
                // SAFETY
                //
                // Treat unsupported values as stride 1.
                // =============================================

                default: begin

                    stride_window_valid =
                        1'b1;

                end

            endcase

        end

    end


    // =========================================================
    // WINDOW COORDINATE TRACKER
    //
    // This counts EVERY stride-1 window generated by the
    // streaming window block.
    // =========================================================

    always_ff @(posedge clk) begin

        if (reset) begin

            row_counter <=
                16'd0;

            col_counter <=
                16'd0;

            window_row <=
                16'd0;

            window_col <=
                16'd0;

        end

        else begin

            if (channel_start) begin

                row_counter <=
                    16'd0;

                col_counter <=
                    16'd0;

            end


            if (window_valid) begin

                // Export coordinates belonging to this window.

                window_row <=
                    row_counter;

                window_col <=
                    col_counter;


                // =============================================
                // ADVANCE THROUGH STRIDE-1 OUTPUT GRID
                // =============================================

                if (
                    col_counter + 1
                    >=
                    base_output_width
                ) begin

                    col_counter <=
                        16'd0;


                    if (
                        row_counter + 1
                        >=
                        base_output_height
                    ) begin

                        row_counter <=
                            16'd0;

                    end

                    else begin

                        row_counter <=
                            row_counter + 1'b1;

                    end

                end

                else begin

                    col_counter <=
                        col_counter + 1'b1;

                end

            end

        end

    end


endmodule

module whole_image_accelerator #(

    parameter integer MAX_WIDTH = 4096

)(

    input logic clk,
    input logic reset,

    input logic [15:0] image_width,
    input logic [15:0] image_height,

    input logic signed [7:0] pixel_in,
    input logic              pixel_valid,


    // =========================================================
    // 3x3 KERNEL
    // =========================================================

    input logic signed [7:0] k00,
    input logic signed [7:0] k01,
    input logic signed [7:0] k02,

    input logic signed [7:0] k10,
    input logic signed [7:0] k11,
    input logic signed [7:0] k12,

    input logic signed [7:0] k20,
    input logic signed [7:0] k21,
    input logic signed [7:0] k22,


    // =========================================================
    // CNN POSTPROCESS CONFIGURATION
    // =========================================================

    input logic signed [31:0] bias,

    input logic [4:0] quant_shift,


    // =========================================================
    // OUTPUT
    //
    // Still 32-bit externally for current DMA compatibility.
    //
    // Internally the actual feature is INT8.
    // =========================================================

    output logic signed [31:0] feature_out,
    output logic               feature_valid

);


    // =========================================================
    // WINDOW SIGNALS
    // =========================================================

    logic signed [7:0] w00, w01, w02;

    logic signed [7:0] w10, w11, w12;

    logic signed [7:0] w20, w21, w22;

    logic window_valid;


    // =========================================================
    // CONVOLUTION SIGNALS
    // =========================================================

    logic signed [31:0] conv_result;

    logic conv_valid;


    // =========================================================
    // POSTPROCESS SIGNALS
    // =========================================================

    logic signed [7:0] quantized_feature;

    logic quantized_valid;


    // =========================================================
    // STREAMING WINDOW GENERATOR
    // =========================================================

    stream_window_3x3 #(

        .MAX_WIDTH(MAX_WIDTH)

    ) WINDOW_GENERATOR (

        .clk(clk),
        .reset(reset),

        // This legacy wrapper has no channel-boundary input.
        // Keep the single-channel interface behavior explicit.
        .channel_start(1'b0),

        .image_width(image_width),
        .image_height(image_height),

        .pixel_in(pixel_in),
        .pixel_valid(pixel_valid),

        .w00(w00),
        .w01(w01),
        .w02(w02),

        .w10(w10),
        .w11(w11),
        .w12(w12),

        .w20(w20),
        .w21(w21),
        .w22(w22),

        .window_valid(window_valid)

    );


    // =========================================================
    // 3x3 CONVOLUTION
    // =========================================================

    conv3x3_engine CONVOLUTION_ENGINE (

        .clk(clk),
        .reset(reset),

        .window_valid(window_valid),

        .w00(w00),
        .w01(w01),
        .w02(w02),

        .w10(w10),
        .w11(w11),
        .w12(w12),

        .w20(w20),
        .w21(w21),
        .w22(w22),

        .k00(k00),
        .k01(k01),
        .k02(k02),

        .k10(k10),
        .k11(k11),
        .k12(k12),

        .k20(k20),
        .k21(k21),
        .k22(k22),

        .result(conv_result),
        .result_valid(conv_valid)

    );


    // =========================================================
    // CNN POSTPROCESS
    //
    // accumulation
    //      ?
    // bias
    //      ?
    // ReLU
    //      ?
    // requantization
    //      ?
    // INT8
    // =========================================================

    cnn_postprocess POSTPROCESS (

        .accumulator(conv_result),

        .bias(bias),

        .quant_shift(quant_shift),

        .valid_in(conv_valid),

        .feature_out(quantized_feature),

        .valid_out(quantized_valid)

    );


    // =========================================================
    // CURRENT DMA COMPATIBILITY
    //
    // Store INT8 result as sign-extended 32-bit value.
    // =========================================================

    always_comb begin

        feature_out =
            {{24{quantized_feature[7]}},
             quantized_feature};

        feature_valid =
            quantized_valid;

    end


endmodule

module write_back_logic (

    input  logic [31:0] alu_result,
    input  logic [31:0] memory_data,
    input  logic [31:0] pc_plus_4,

    input  logic [1:0]  wb_sel,

    output logic [31:0] write_back_data,

    // Optional debug/output copy
    output logic [31:0] pc_plus_4_value

);

    // =========================================================
    // PC + 4 DEBUG / FORWARD OUTPUT
    // =========================================================

    always_comb begin
        pc_plus_4_value = pc_plus_4;
    end


    // =========================================================
    // WRITE-BACK MUX
    //
    // 00 = ALU result
    //      ADD / ADDI / LUI / other ALU instructions
    //
    // 01 = Memory data
    //      LW
    //
    // 10 = PC + 4
    //      JAL / JALR
    //
    // 11 = default 0
    // =========================================================

    always_comb begin

        case (wb_sel)

            2'b00: begin
                write_back_data = alu_result;
            end

            2'b01: begin
                write_back_data = memory_data;
            end

            2'b10: begin
                write_back_data = pc_plus_4;
            end

            default: begin
                write_back_data = 32'd0;
            end

        endcase

    end

endmodule
