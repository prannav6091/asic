import numpy as np

data = np.load("nova1_4class_demo_dataset.npz")
X = data["X"]

labels = ["cat", "dog", "car", "motorcycle",
          "cat", "dog", "car", "motorcycle"]

for i in range(8):
    pixels = np.rint(X[i, 0].reshape(-1) * 127)
    pixels = pixels.astype(np.int8).view(np.uint8)

    words = [
        int(pixels[j])
        | (int(pixels[j+1]) << 8)
        | (int(pixels[j+2]) << 16)
        | (int(pixels[j+3]) << 24)
        for j in range(0, 64, 4)
    ]

    filename = f"nova1_4class_input_{i}.mem"
    with open(filename, "w") as f:
        f.write("\n".join(f"{word:08X}" for word in words) + "\n")

    print(f"{filename}: {labels[i]}, {len(words)} words")
