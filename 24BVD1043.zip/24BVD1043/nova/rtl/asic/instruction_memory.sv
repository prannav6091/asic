module instruction_memory (
    input logic [31:0] address,
    output logic [31:0] instruction
);

    logic [31:0] mem [0:4095];
    integer i;

    initial begin
        for (i = 0; i < 4096; i = i + 1)
            mem[i] = 32'h00000013;

        mem[0] = 32'h40000537; // x10 = NOVA-1 AI MMIO base [upper 0x40000]
        mem[1] = 32'h00800593; // x11 = 8
        mem[2] = 32'h00B52423; // IMAGE WIDTH = 8
        mem[3] = 32'h00800593; // x11 = 8
        mem[4] = 32'h00B52623; // IMAGE HEIGHT = 8
        mem[5] = 32'h000015B7; // x11 = 4096 [upper 0x00001]
        mem[6] = 32'h00B52823; // INPUT_BASE = 0x00001000
        mem[7] = 32'h00100593; // x11 = 1
        mem[8] = 32'h04B52223; // NETWORK Cin = 1
        mem[9] = 32'h00200593; // x11 = 2
        mem[10] = 32'h04B52023; // NETWORK NUM_LAYERS = 2
        mem[11] = 32'h000045B7; // x11 = 16384 [upper 0x00004]
        mem[12] = 32'h04B52423; // BUFFER_A = 0x00004000
        mem[13] = 32'h000085B7; // x11 = 32768 [upper 0x00008]
        mem[14] = 32'h04B52623; // BUFFER_B = 0x00008000
        mem[15] = 32'h0000C5B7; // x11 = 49152 [upper 0x0000C]
        mem[16] = 32'h08B52E23; // MODEL_LOAD_BASE = 0x0000C000
        mem[17] = 32'h00100593; // x11 = 1
        mem[18] = 32'h0AB52023; // START HARDWARE MODEL LOADER
        mem[19] = 32'h00200693; // x13 = MODEL_LOADER_DONE
        mem[20] = 32'h0A452583; // Read MODEL_LOAD_STATUS
        mem[21] = 32'hFED59EE3; // Poll until MODEL_LOADER_DONE
        mem[22] = 32'h00100593; // x11 = 1
        mem[23] = 32'h06B52023; // START TRAINED CNN AFTER MODEL LOAD
        mem[24] = 32'h00200693; // x13 = NETWORK_DONE
        mem[25] = 32'h06452583; // Read NET_STATUS
        mem[26] = 32'hFED59EE3; // Poll until NET_STATUS == 2
        mem[27] = 32'h0000006F; // HALT
    end

    always_comb begin
        instruction = mem[address[13:2]];
    end

endmodule
