from pathlib import Path
import re
import sys

BASE = Path("/home/vlsi35/24BVD1043/nova/rtl/asic")
SOURCE = BASE / "nova1_all_sources.txt"
OUTPUT = BASE / "nova1_soc_all_rtl.sv"
BACKUP = BASE / "nova1_soc_all_rtl.sv.bak"

EXCLUDE = {
    "instruction_memory.sv",
    "mac_array_4.sv",
    "mac_pe.sv",
    "program_counter_tb.sv",
}


def main():
    print("NOVA-1 RTL consolidation started.", flush=True)

    if not SOURCE.is_file():
        sys.exit(f"ERROR: Source file not found: {SOURCE}")

    print(f"Reading {SOURCE.name}...", flush=True)
    text = SOURCE.read_text(encoding="utf-8")
    print(f"Read {len(text)} characters.", flush=True)

    print("Splitting source collection into sections...", flush=True)
    sections = re.split(
        r"(?m)^========== FILE: (.*?) ==========\s*\n",
        text,
    )

    modules = []

    for i in range(1, len(sections), 2):
        filename = Path(sections[i].strip()).name
        body = sections[i + 1]

        if not filename.endswith(".sv"):
            continue

        if filename in EXCLUDE:
            print(f"Skipping excluded file: {filename}", flush=True)
            continue

        # Remove per-file timescale directives.
        body = re.sub(
            r"(?m)^[ \t]*`timescale[^\n]*\n",
            "",
            body,
        ).strip()

        if re.search(r"(?m)^[ \t]*module[ \t]+", body):
            modules.append((filename, body))

    print(f"Found {len(modules)} RTL module files.", flush=True)

    if len(modules) != 41:
        sys.exit(
            f"ERROR: Expected 41 RTL files, found {len(modules)}. "
            "Output was not replaced."
        )

    names = []

    for filename, body in modules:
        found = re.findall(
            r"(?m)^[ \t]*module[ \t]+([A-Za-z_]\w*)",
            body,
        )
        if not found:
            sys.exit(f"ERROR: No module definition found in {filename}.")
        names.extend(found)

    duplicates = sorted({
        name for name in names if names.count(name) > 1
    })

    if duplicates:
        sys.exit(
            "ERROR: Duplicate module definitions: "
            + ", ".join(duplicates)
            + ". Output was not replaced."
        )

    if names.count("nova1_soc") != 1:
        sys.exit(
            "ERROR: Expected exactly one nova1_soc module; "
            f"found {names.count('nova1_soc')}. Output was not replaced."
        )

    consolidated = (
        "// Consolidated NOVA-1 RTL. Top module: nova1_soc.\n\n"
        + "\n\n".join(body for _, body in modules)
        + "\n"
    )

    # Preserve the previous output before replacing it.
    if OUTPUT.exists():
        print("Backing up existing consolidated RTL...", flush=True)
        BACKUP.write_bytes(OUTPUT.read_bytes())
        print(f"Backup saved as {BACKUP.name}", flush=True)

    print("Writing consolidated RTL...", flush=True)
    OUTPUT.write_text(consolidated, encoding="utf-8")

    print("\nSUCCESS", flush=True)
    print(f"Output: {OUTPUT}", flush=True)
    print(f"RTL files included: {len(modules)}", flush=True)
    print(f"Unique module definitions: {len(names)}", flush=True)
    print(f"nova1_soc definitions: {names.count('nova1_soc')}", flush=True)
    print(f"Output size: {OUTPUT.stat().st_size} bytes", flush=True)
    print("Next: verify the file before running Genus.", flush=True)


if __name__ == "__main__":
    main()

