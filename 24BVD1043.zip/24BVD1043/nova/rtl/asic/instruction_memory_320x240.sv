module instruction_memory (
input  logic [31:0] address,
output logic [31:0] instruction
);

logic [31:0] mem [0:4095];
integer i;

initial begin
    for (i = 0; i < 4096; i = i + 1)
        mem[i] = 32'h00000013; // RISC-V NOP

    // Configure full-resolution input: 320 x 240
    mem[0]  = 32'h40000537; // x10 = 0x40000000 (AI MMIO base)
    mem[1]  = 32'h14000593; // x11 = 320
    mem[2]  = 32'h00B52423; // IMAGE WIDTH = 320
    mem[3]  = 32'h0F000593; // x11 = 240
    mem[4]  = 32'h00B52623; // IMAGE HEIGHT = 240

    // Input image base = 0x00001000
    mem[5]  = 32'h000015B7; // x11 = 0x1000
    mem[6]  = 32'h00B52823; // INPUT_BASE

    // Network configuration
    mem[7]  = 32'h00100593; // x11 = 1 input channel
    mem[8]  = 32'h04B52223; // NETWORK Cin
    mem[9]  = 32'h00200593; // x11 = 2 layers
    mem[10] = 32'h04B52023; // NETWORK NUM_LAYERS

    // Buffer A = 0x00014000
    mem[11] = 32'h000145B7; // x11 = 0x14000
    mem[12] = 32'h04B52423; // BUFFER_A

    // Buffer B = 0x00027000
    mem[13] = 32'h000275B7; // x11 = 0x27000
    mem[14] = 32'h04B52623; // BUFFER_B

    // Model image base = 0x000C0000
    mem[15] = 32'h000C05B7; // x11 = 0xC0000
    mem[16] = 32'h08B52E23; // MODEL_LOAD_BASE

    // Start model loader
    mem[17] = 32'h00100593; // x11 = 1
    mem[18] = 32'h0AB52023; // MODEL_LOAD_CONTROL = START
    mem[19] = 32'h00200693; // x13 = MODEL_LOADER_DONE
    mem[20] = 32'h0A452583; // Read MODEL_LOAD_STATUS
    mem[21] = 32'hFED59EE3; // Poll until MODEL_LOADER_DONE

    // Start CNN
    mem[22] = 32'h00100593; // x11 = 1
    mem[23] = 32'h06B52023; // NETWORK_CONTROL = START
    mem[24] = 32'h00200693; // x13 = NETWORK_DONE
    mem[25] = 32'h06452583; // Read NET_STATUS
    mem[26] = 32'hFED59EE3; // Poll until NET_STATUS == 2

    mem[27] = 32'h0000006F; // HALT
end

always_comb begin
    instruction = mem[address[13:2]];
end

endmodule
