# ============================================================
# NOVA-1 SoC - Hierarchical Genus Synthesis
# Cadence Genus 21.14
# ============================================================

set TOP nova1_synthesis_top

set LIB_FILES [list \
    "/home/install/FOUNDRY/digital/180nm/dig/lib/typical.lib" \
]

set CLOCK_PERIOD 10.0
set CLOCK_PORT clk

set OUT_DIR "genus_output_top"
set REPORT_DIR "$OUT_DIR/reports"

file mkdir $OUT_DIR
file mkdir $REPORT_DIR

if {![file exists [lindex $LIB_FILES 0]]} {
    error "Liberty file not found: [lindex $LIB_FILES 0]"
}

set_db init_lib_search_path [list [file dirname [lindex $LIB_FILES 0]]]
set_db library $LIB_FILES

# Read the original separate RTL source files; skip consolidated and excluded files.
set rtl_files [list]
foreach f [lsort [glob -nocomplain *.sv]] {
    set base [file tail $f]
    if {$base eq "nova1_soc_all_rtl.sv"} { continue }
    if {$base eq "instruction_memory.sv"} { continue }
    if {$base eq "mac_array_4.sv"} { continue }
    if {$base eq "mac_pe.sv"} { continue }
    if {$base eq "program_counter_tb.sv"} { continue }
    lappend rtl_files $f
}

if {[llength $rtl_files] == 0} {
    error "No RTL source files found in the current directory."
}

puts "TOP: $TOP"
puts "RTL files: [llength $rtl_files]"
foreach f $rtl_files { puts "RTL: $f" }

# Retained from the prior flow; does not make oversized arrays inexpensive.
set_db hdl_max_memory_address_range 16777216

puts "INFO: Reading RTL..."
read_hdl -sv $rtl_files

puts "INFO: Elaborating $TOP..."
elaborate $TOP

puts "INFO: Checking design..."
check_design -unresolved

puts "INFO: Applying timing constraints..."
source nova1_top_constraints.sdc
write_sdc "$OUT_DIR/nova1_top_constraints.sdc"

puts "INFO: Generic synthesis..."
syn_generic
puts "INFO: Technology mapping..."
syn_map
puts "INFO: Synthesis optimization..."
syn_opt

puts "INFO: Writing mapped Verilog..."
write_hdl > "$OUT_DIR/nova1_synthesis_top_mapped.v"
write_sdc "$OUT_DIR/nova1_top_constraints.sdc"

puts "INFO: Generating reports..."
report_area > "$REPORT_DIR/area.rpt"
report_timing -max_paths 50 > "$REPORT_DIR/timing.rpt"
report_power > "$REPORT_DIR/power.rpt"
report_qor > "$REPORT_DIR/qor.rpt"
report_gates > "$REPORT_DIR/gates.rpt"

puts "INFO: Saving Genus database..."
write_db "$OUT_DIR/nova1_synthesis_top.db"

puts "NOVA-1 HIERARCHICAL SYNTHESIS SCRIPT FINISHED"
puts "Output directory: $OUT_DIR"
