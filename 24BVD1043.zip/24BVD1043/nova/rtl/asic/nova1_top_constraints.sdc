# NOVA-1 SoC timing constraints
# Top-level ports: clk, reset
# Clock period: 10 ns (100 MHz)

create_clock \
    -name core_clk \
    -period 10.000 \
    [get_ports {clk}]

set_clock_uncertainty 0.2 [get_clocks core_clk]

# Basic I/O assumptions; replace with interface-specific values before signoff.
set_input_delay 1.0 \
    -clock core_clk \
    [remove_from_collection [all_inputs] [get_ports {clk}]]

set_output_delay 1.0 \
    -clock core_clk \
    [all_outputs]
