module program_counter_tb;

    logic        clk;
    logic        reset;
    logic [31:0] next_pc;
    logic [31:0] pc;

    // Instantiate the Program Counter
    program_counter dut (
        .clk     (clk),
        .reset   (reset),
        .next_pc (next_pc),
        .pc      (pc)
    );

    // Clock generation
    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin

        // -----------------------------
        // TEST 1: RESET
        // -----------------------------

        reset   = 1'b1;
        next_pc = 32'h00000000;

        @(posedge clk);
        #1;

        if (pc === 32'h00000000)
            $display("PASS: Reset -> PC = 0");
        else
            $error("FAIL: Reset -> Expected PC = 0, Got PC = %h", pc);


        // -----------------------------
        // TEST 2: PC = 4
        // -----------------------------

        reset   = 1'b0;
        next_pc = 32'h00000004;

        @(posedge clk);
        #1;

        if (pc === 32'h00000004)
            $display("PASS: PC = 4");
        else
            $error("FAIL: Expected PC = 4, Got PC = %h", pc);


        // -----------------------------
        // TEST 3: PC = 8
        // -----------------------------

        next_pc = 32'h00000008;

        @(posedge clk);
        #1;

        if (pc === 32'h00000008)
            $display("PASS: PC = 8");
        else
            $error("FAIL: Expected PC = 8, Got PC = %h", pc);


        // -----------------------------
        // TEST 4: PC = 12
        // -----------------------------

        next_pc = 32'h0000000C;

        @(posedge clk);
        #1;

        if (pc === 32'h0000000C)
            $display("PASS: PC = 12");
        else
            $error("FAIL: Expected PC = 12, Got PC = %h", pc);


        // -----------------------------
        // TEST 5: PC = 16
        // -----------------------------

        next_pc = 32'h00000010;

        @(posedge clk);
        #1;

        if (pc === 32'h00000010)
            $display("PASS: PC = 16");
        else
            $error("FAIL: Expected PC = 16, Got PC = %h", pc);


        // -----------------------------
        // TEST COMPLETE
        // -----------------------------

        $display("");
        $display("========================================");
        $display(" PROGRAM COUNTER VERIFICATION COMPLETE ");
        $display("========================================");
        $display("");

        $stop;

    end

endmodule