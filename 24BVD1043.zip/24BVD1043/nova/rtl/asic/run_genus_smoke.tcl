# ============================================================
# NOVA-1 SoC - Cadence Genus Synthesis Script
# Cadence Genus 21.14
#
# Outputs:
#   1. Technology-mapped Verilog netlist
#   2. SDC timing constraints
#   3. Area report
#   4. Timing report
#   5. Power report
#   6. QoR and gate reports
#   7. Genus synthesis database
# ============================================================

# ----------------------------
# USER CONFIGURATION
# ----------------------------

set TOP nova1_soc

# 180nm standard-cell Liberty library
set LIB_FILES [list \
    "/home/install/FOUNDRY/digital/180nm/dig/lib/typical.lib" \
]

# Clock period in nanoseconds
set CLOCK_PERIOD 10.0
set CLOCK_PORT clk

# Output directories
set OUT_DIR "genus_output_smoke"
set REPORT_DIR "$OUT_DIR/reports"

file mkdir $OUT_DIR
file mkdir $REPORT_DIR

# ----------------------------
# LIBRARY SETUP
# ----------------------------

set_db init_lib_search_path [list \
    [file dirname [lindex $LIB_FILES 0]]]

set_db library $LIB_FILES

# ----------------------------
# RTL FILE COLLECTION
# ----------------------------

puts "INFO: Collecting RTL files..."

set rtl_files [list]

foreach f [glob -nocomplain *.sv] {
    set base [file tail $f]

    # Exclude duplicate instruction memory definition
    if {$base eq "instruction_memory.sv"} {
        continue
    }

    # Exclude duplicate/stale MAC definitions
    if {$base eq "mac_array_4.sv"} {
        continue
    }

    if {$base eq "mac_pe.sv"} {
        continue
    }

    # Exclude testbench
    if {$base eq "program_counter_tb.sv"} {
        continue
    }

    lappend rtl_files $f
}

foreach f $rtl_files {
    puts "RTL: $f"
}

# ----------------------------
# RTL READ AND ELABORATION
# ----------------------------

puts "INFO: Setting HDL memory address range..."

set_db hdl_max_memory_address_range 16777216

puts "INFO: Reading RTL..."

read_hdl -sv $rtl_files

puts "INFO: Elaborating top module $TOP..."

elaborate $TOP

puts "INFO: Checking design..."

check_design -unresolved

# ----------------------------
# TIMING CONSTRAINTS
# ----------------------------

puts "INFO: Applying timing constraints..."

create_clock \
    -name core_clk \
    -period $CLOCK_PERIOD \
    [get_ports $CLOCK_PORT]

set_clock_uncertainty 0.2 [get_clocks core_clk]

# Basic I/O delay assumptions.
# Replace with interface-specific values for signoff.
set_input_delay 1.0 \
    -clock core_clk \
    [remove_from_collection [all_inputs] [get_ports $CLOCK_PORT]]

set_output_delay 1.0 \
    -clock core_clk \
    [all_outputs]

# Save initial SDC
puts "INFO: Writing initial SDC..."

write_sdc "$OUT_DIR/nova1_soc_constraints.sdc"

# ----------------------------
# GENERIC SYNTHESIS
# ----------------------------

puts "INFO: Running generic synthesis..."

syn_generic

# ----------------------------
# TECHNOLOGY MAPPING
# ----------------------------

puts "INFO: Running technology mapping..."

syn_map

# ----------------------------
# OPTIMIZATION
# ----------------------------

puts "INFO: Running synthesis optimization..."

syn_opt

# ----------------------------
# MAPPED NETLIST
# ----------------------------

puts "INFO: Writing mapped Verilog..."

write_hdl > "$OUT_DIR/nova1_soc_mapped.v"

# Save final SDC
write_sdc "$OUT_DIR/nova1_soc_constraints.sdc"

# ----------------------------
# AREA REPORT
# ----------------------------

puts "INFO: Generating area report..."

report_area > "$REPORT_DIR/area.rpt"

# ----------------------------
# TIMING REPORT
# ----------------------------

puts "INFO: Generating timing report..."

report_timing -max_paths 50 \
    > "$REPORT_DIR/timing.rpt"

# ----------------------------
# POWER REPORT
# ----------------------------

puts "INFO: Generating power report..."

report_power > "$REPORT_DIR/power.rpt"

# ----------------------------
# QUALITY OF RESULTS
# ----------------------------

puts "INFO: Generating QoR report..."

report_qor > "$REPORT_DIR/qor.rpt"

# ----------------------------
# GATE REPORT
# ----------------------------

puts "INFO: Generating gate report..."

report_gates > "$REPORT_DIR/gates.rpt"

# ----------------------------
# SAVE GENUS DATABASE
# ----------------------------

puts "INFO: Saving synthesis database..."

write_db "$OUT_DIR/nova1_soc_synthesis.db"

# ----------------------------
# COMPLETION
# ----------------------------

puts "============================================================"
puts "NOVA-1 SYNTHESIS SCRIPT FINISHED"
puts "Review genus.log for warnings and errors."
puts "Output directory: $OUT_DIR"
puts "============================================================"

# ----------------------------
# OPEN GENUS GUI
# ----------------------------

gui_show
