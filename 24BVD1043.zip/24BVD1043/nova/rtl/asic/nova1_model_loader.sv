module nova1_model_loader #(
    parameter integer MAX_INPUT_CHANNELS  = 64,
    parameter integer MAX_OUTPUT_CHANNELS = 64,
    parameter integer MAX_LAYERS          = 8
)(
    input  logic clk,
    input  logic reset,

    input  logic        start,
    input  logic [31:0] base_address,

    output logic busy,
    output logic done,
    output logic error,

    // Shared-memory read port.
    output logic        mem_read_req,
    output logic [31:0] mem_read_address,
    input  logic [31:0] mem_read_data,
    input  logic        mem_read_valid,

    // Layer descriptor programming.
    output logic        descriptor_wr_en,
    output logic [15:0] descriptor_wr_index,
    output logic [15:0] descriptor_wr_cout,
    output logic [1:0]  descriptor_wr_stride,

    // Weight programming.
    output logic        weight_wr_en,
    output logic [15:0] weight_wr_layer,
    output logic [15:0] weight_wr_filter,
    output logic [15:0] weight_wr_channel,
    output logic [3:0]  weight_wr_tap,
    output logic signed [7:0] weight_wr_data,

    // Bias programming.
    output logic        bias_wr_en,
    output logic [15:0] bias_wr_layer,
    output logic [15:0] bias_wr_filter,
    output logic signed [31:0] bias_wr_data,

    // Quantization programming.
    output logic        quant_wr_en,
    output logic [15:0] quant_wr_layer,
    output logic [15:0] quant_wr_filter,
    output logic [4:0]  quant_wr_data
);

    localparam logic [31:0] MAGIC = 32'h4E4F5641; // "NOVA"

    typedef enum logic [3:0] {
        S_IDLE,
        S_MAGIC_REQ,
        S_MAGIC_WAIT,
        S_LAYERS_REQ,
        S_LAYERS_WAIT,
        S_HEADER_REQ,
        S_HEADER_WAIT,
        S_WEIGHT_REQ,
        S_WEIGHT_WAIT,
        S_BIAS_REQ,
        S_BIAS_WAIT,
        S_QUANT_REQ,
        S_QUANT_WAIT,
        S_DONE,
        S_ERROR
    } state_t;

    state_t state;

    logic [31:0] read_address_reg;
    logic [15:0] num_layers;
    logic [15:0] current_layer;

    logic [15:0] current_cin;
    logic [15:0] current_cout;
    logic [1:0]  current_stride;

    logic [15:0] weight_filter;
    logic [15:0] weight_channel;
    logic [3:0]  weight_tap;
    logic [15:0] bias_filter;
    logic [15:0] quant_filter;

    always_comb begin
        mem_read_req = 1'b0;
        mem_read_address = read_address_reg;

        descriptor_wr_en = 1'b0;
        descriptor_wr_index = current_layer;
        descriptor_wr_cout = current_cout;
        descriptor_wr_stride = current_stride;

        weight_wr_en = 1'b0;
        weight_wr_layer = current_layer;
        weight_wr_filter = weight_filter;
        weight_wr_channel = weight_channel;
        weight_wr_tap = weight_tap;
        weight_wr_data = $signed(mem_read_data[7:0]);

        bias_wr_en = 1'b0;
        bias_wr_layer = current_layer;
        bias_wr_filter = bias_filter;
        bias_wr_data = $signed(mem_read_data);

        quant_wr_en = 1'b0;
        quant_wr_layer = current_layer;
        quant_wr_filter = quant_filter;
        quant_wr_data = mem_read_data[4:0];

        case (state)
            S_MAGIC_REQ,
            S_LAYERS_REQ,
            S_HEADER_REQ,
            S_WEIGHT_REQ,
            S_BIAS_REQ,
            S_QUANT_REQ: begin
                mem_read_req = 1'b1;
            end
            default: begin
            end
        endcase

        if (state == S_HEADER_WAIT && mem_read_valid) begin
            descriptor_wr_en = 1'b1;
            descriptor_wr_index = current_layer;
            descriptor_wr_cout = {8'd0, mem_read_data[31:24]};
            descriptor_wr_stride = mem_read_data[1:0];
        end

        if (state == S_WEIGHT_WAIT && mem_read_valid) begin
            weight_wr_en = 1'b1;
        end

        if (state == S_BIAS_WAIT && mem_read_valid) begin
            bias_wr_en = 1'b1;
        end

        if (state == S_QUANT_WAIT && mem_read_valid) begin
            quant_wr_en = 1'b1;
        end
    end

    always_ff @(posedge clk) begin
        if (reset) begin
            state <= S_IDLE;
            busy <= 1'b0;
            done <= 1'b0;
            error <= 1'b0;

            read_address_reg <= 32'd0;
            num_layers <= 16'd0;
            current_layer <= 16'd0;
            current_cin <= 16'd0;
            current_cout <= 16'd0;
            current_stride <= 2'd1;

            weight_filter <= 16'd0;
            weight_channel <= 16'd0;
            weight_tap <= 4'd0;
            bias_filter <= 16'd0;
            quant_filter <= 16'd0;
        end
        else begin
            case (state)
                S_IDLE: begin
                    if (start) begin
                        busy <= 1'b1;
                        done <= 1'b0;
                        error <= 1'b0;
                        read_address_reg <= base_address;
                        current_layer <= 16'd0;
                        state <= S_MAGIC_REQ;
                    end
                end

                S_MAGIC_REQ: begin
                    state <= S_MAGIC_WAIT;
                end

                S_MAGIC_WAIT: begin
                    if (mem_read_valid) begin
                        if (mem_read_data == MAGIC) begin
                            read_address_reg <= read_address_reg + 32'd4;
                            state <= S_LAYERS_REQ;
                        end
                        else begin
                            busy <= 1'b0;
                            error <= 1'b1;
                            state <= S_ERROR;
                        end
                    end
                end

                S_LAYERS_REQ: begin
                    state <= S_LAYERS_WAIT;
                end

                S_LAYERS_WAIT: begin
                    if (mem_read_valid) begin
                        if ((mem_read_data[15:0] != 16'd0) &&
                            (mem_read_data[15:0] <= MAX_LAYERS)) begin
                            num_layers <= mem_read_data[15:0];
                            read_address_reg <= read_address_reg + 32'd4;
                            current_layer <= 16'd0;
                            state <= S_HEADER_REQ;
                        end
                        else begin
                            busy <= 1'b0;
                            error <= 1'b1;
                            state <= S_ERROR;
                        end
                    end
                end

                S_HEADER_REQ: begin
                    state <= S_HEADER_WAIT;
                end

                S_HEADER_WAIT: begin
                    if (mem_read_valid) begin
                        current_cout <= mem_read_data[31:24];
                        current_cin <= mem_read_data[23:16];
                        current_stride <= mem_read_data[1:0];

                        if ((mem_read_data[31:24] != 8'd0) &&
                            (mem_read_data[23:16] != 8'd0) &&
                            (mem_read_data[31:24] <= MAX_OUTPUT_CHANNELS) &&
                            (mem_read_data[23:16] <= MAX_INPUT_CHANNELS) &&
                            ((mem_read_data[1:0] == 2'd1) ||
                             (mem_read_data[1:0] == 2'd2))) begin
                            read_address_reg <= read_address_reg + 32'd4;
                            weight_filter <= 16'd0;
                            weight_channel <= 16'd0;
                            weight_tap <= 4'd0;
                            state <= S_WEIGHT_REQ;
                        end
                        else begin
                            busy <= 1'b0;
                            error <= 1'b1;
                            state <= S_ERROR;
                        end
                    end
                end

                S_WEIGHT_REQ: begin
                    state <= S_WEIGHT_WAIT;
                end

                S_WEIGHT_WAIT: begin
                    if (mem_read_valid) begin
                        read_address_reg <= read_address_reg + 32'd4;

                        if ((weight_filter == current_cout - 1'b1) &&
                            (weight_channel == current_cin - 1'b1) &&
                            (weight_tap == 4'd8)) begin
                            bias_filter <= 16'd0;
                            state <= S_BIAS_REQ;
                        end
                        else if (weight_tap == 4'd8) begin
                            weight_tap <= 4'd0;
                            if (weight_channel == current_cin - 1'b1) begin
                                weight_channel <= 16'd0;
                                weight_filter <= weight_filter + 16'd1;
                            end
                            else begin
                                weight_channel <= weight_channel + 16'd1;
                            end
                            state <= S_WEIGHT_REQ;
                        end
                        else begin
                            weight_tap <= weight_tap + 4'd1;
                            state <= S_WEIGHT_REQ;
                        end
                    end
                end

                S_BIAS_REQ: begin
                    state <= S_BIAS_WAIT;
                end

                S_BIAS_WAIT: begin
                    if (mem_read_valid) begin
                        read_address_reg <= read_address_reg + 32'd4;

                        if (bias_filter == current_cout - 1'b1) begin
                            quant_filter <= 16'd0;
                            state <= S_QUANT_REQ;
                        end
                        else begin
                            bias_filter <= bias_filter + 16'd1;
                            state <= S_BIAS_REQ;
                        end
                    end
                end

                S_QUANT_REQ: begin
                    state <= S_QUANT_WAIT;
                end

                S_QUANT_WAIT: begin
                    if (mem_read_valid) begin
                        read_address_reg <= read_address_reg + 32'd4;

                        if (quant_filter == current_cout - 1'b1) begin
                            if ((current_layer + 16'd1) >= num_layers) begin
                                busy <= 1'b0;
                                done <= 1'b1;
                                state <= S_DONE;
                            end
                            else begin
                                current_layer <= current_layer + 16'd1;
                                state <= S_HEADER_REQ;
                            end
                        end
                        else begin
                            quant_filter <= quant_filter + 16'd1;
                            state <= S_QUANT_REQ;
                        end
                    end
                end

                S_DONE: begin
                    // Sticky DONE until the next START.
                    state <= S_DONE;
                end

                S_ERROR: begin
                    // Sticky ERROR until the next START/reset.
                    state <= S_ERROR;
                end

                default: begin
                    busy <= 1'b0;
                    error <= 1'b1;
                    state <= S_ERROR;
                end
            endcase
        end
    end

endmodule
