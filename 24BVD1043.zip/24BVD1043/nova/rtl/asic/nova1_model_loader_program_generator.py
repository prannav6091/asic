import numpy as np

ROM_WORDS = 4096
MODEL_BASE = 0x0000C000
MMIO_BASE = 0x40000000

WIDTH = 0x08
HEIGHT = 0x0C
INPUT_BASE = 0x10
NET_NUM_LAYERS = 0x40
NET_CIN = 0x44
NET_BUFFER_A = 0x48
NET_BUFFER_B = 0x4C
NET_CONTROL = 0x60
NET_STATUS = 0x64
MODEL_LOAD_BASE = 0x9C
MODEL_LOAD_CONTROL = 0xA0
MODEL_LOAD_STATUS = 0xA4

model = np.load("nova1_tinycnn_int8.npz")
W1 = model["W1"].astype(np.int32)
b1 = model["b1"].astype(np.int32)
W2 = model["W2"].astype(np.int32)
b2 = model["b2"].astype(np.int32)
SHIFT1 = int(model["shift1"])
SHIFT2 = int(model["shift2"])

assert W1.shape == (4, 1, 3, 3)
assert b1.shape == (4,)
assert W2.shape == (8, 4, 3, 3)
assert b2.shape == (8,)
assert 0 <= SHIFT1 <= 31
assert 0 <= SHIFT2 <= 31


def u32(v):
    return v & 0xFFFFFFFF


def fits12(v):
    return -2048 <= v <= 2047


def enc_lui(rd, imm20):
    return u32(((imm20 & 0xFFFFF) << 12) | ((rd & 31) << 7) | 0x37)


def enc_addi(rd, rs1, imm):
    if not fits12(imm):
        raise ValueError(imm)
    return u32(((imm & 0xFFF) << 20) | ((rs1 & 31) << 15) | ((rd & 31) << 7) | 0x13)


def enc_sw(rs2, rs1, imm):
    if not fits12(imm):
        raise ValueError(imm)
    imm &= 0xFFF
    return u32((((imm >> 5) & 0x7F) << 25) |
               ((rs2 & 31) << 20) |
               ((rs1 & 31) << 15) |
               (2 << 12) |
               ((imm & 0x1F) << 7) |
               0x23)


def enc_lw(rd, rs1, imm):
    if not fits12(imm):
        raise ValueError(imm)
    return u32(((imm & 0xFFF) << 20) | ((rs1 & 31) << 15) | (2 << 12) | ((rd & 31) << 7) | 0x03)


def enc_bne(rs1, rs2, offset):
    if offset % 2 or not (-4096 <= offset <= 4094):
        raise ValueError(offset)
    imm = offset & 0x1FFF
    return u32((((imm >> 12) & 1) << 31) |
               (((imm >> 5) & 0x3F) << 25) |
               ((rs2 & 31) << 20) |
               ((rs1 & 31) << 15) |
               (1 << 12) |
               (((imm >> 1) & 0xF) << 8) |
               (((imm >> 11) & 1) << 7) |
               0x63)


def enc_jal(rd, offset):
    if offset % 2:
        raise ValueError(offset)
    imm = offset & 0x1FFFFF
    return u32((((imm >> 20) & 1) << 31) |
               (((imm >> 1) & 0x3FF) << 21) |
               (((imm >> 11) & 1) << 20) |
               (((imm >> 12) & 0xFF) << 12) |
               ((rd & 31) << 7) |
               0x6F)


program = []
comments = []


def emit(insn, comment):
    program.append(u32(insn))
    comments.append(comment)


def load_imm32(rd, value, comment):
    value = u32(value)
    signed = value if value < 0x80000000 else value - 0x100000000
    if fits12(signed):
        emit(enc_addi(rd, 0, signed), comment)
        return
    upper = ((value + 0x800) >> 12) & 0xFFFFF
    lower = value - (upper << 12)
    if lower >= 0x80000000:
        lower -= 0x100000000
    emit(enc_lui(rd, upper), f"{comment} [upper 0x{upper:05X}]")
    if lower:
        emit(enc_addi(rd, rd, lower), f"{comment} lower immediate {lower}")


def mmio_write(offset, value, comment):
    load_imm32(11, value, f"x11 = {value}")
    emit(enc_sw(11, 10, offset), comment)


# ------------------------------------------------------------
# CPU program
# ------------------------------------------------------------

load_imm32(10, MMIO_BASE, "x10 = NOVA-1 AI MMIO base")
mmio_write(WIDTH, 8, "IMAGE WIDTH = 8")
mmio_write(HEIGHT, 8, "IMAGE HEIGHT = 8")
mmio_write(INPUT_BASE, 0x1000, "INPUT_BASE = 0x00001000")
mmio_write(NET_CIN, 1, "NETWORK Cin = 1")
mmio_write(NET_NUM_LAYERS, 2, "NETWORK NUM_LAYERS = 2")
mmio_write(NET_BUFFER_A, 0x4000, "BUFFER_A = 0x00004000")
mmio_write(NET_BUFFER_B, 0x8000, "BUFFER_B = 0x00008000")

# Start hardware model loader.
mmio_write(MODEL_LOAD_BASE, MODEL_BASE, "MODEL_LOAD_BASE = 0x0000C000")
mmio_write(MODEL_LOAD_CONTROL, 1, "START HARDWARE MODEL LOADER")

# Poll MODEL_LOAD_STATUS until DONE == 2.
load_imm32(13, 2, "x13 = MODEL_LOADER_DONE")
poll_loader_pc = len(program) * 4
emit(enc_lw(11, 10, MODEL_LOAD_STATUS), "Read MODEL_LOAD_STATUS")
branch_loader_pc = len(program) * 4
emit(enc_bne(11, 13, poll_loader_pc - branch_loader_pc), "Poll until MODEL_LOADER_DONE")

# Start CNN only after loader completion.
mmio_write(NET_CONTROL, 1, "START TRAINED CNN AFTER MODEL LOAD")

# Poll NET_STATUS until DONE == 2.
load_imm32(13, 2, "x13 = NETWORK_DONE")
poll_net_pc = len(program) * 4
emit(enc_lw(11, 10, NET_STATUS), "Read NET_STATUS")
branch_net_pc = len(program) * 4
emit(enc_bne(11, 13, poll_net_pc - branch_net_pc), "Poll until NET_STATUS == 2")

emit(enc_jal(0, 0), "HALT")

assert len(program) <= ROM_WORDS

# ------------------------------------------------------------
# Model image format
# ------------------------------------------------------------
# word0 MAGIC = 0x4E4F5641
# word1 NUM_LAYERS
# per layer:
#   header [31:24]=Cout, [23:16]=Cin, [1:0]=stride
#   Cout*Cin*9 weight words, low byte signed INT8
#   Cout bias words
#   Cout quant words, low 5 bits

image = [0x4E4F5641, 2]

image.append((4 << 24) | (1 << 16) | 2)
for f in range(4):
    for c in range(1):
        for ky in range(3):
            for kx in range(3):
                image.append(int(W1[f, c, ky, kx]) & 0xFF)
for f in range(4):
    image.append(int(b1[f]) & 0xFFFFFFFF)
for _ in range(4):
    image.append(SHIFT1 & 0x1F)

image.append((8 << 24) | (4 << 16) | 1)
for f in range(8):
    for c in range(4):
        for ky in range(3):
            for kx in range(3):
                image.append(int(W2[f, c, ky, kx]) & 0xFF)
for f in range(8):
    image.append(int(b2[f]) & 0xFFFFFFFF)
for _ in range(8):
    image.append(SHIFT2 & 0x1F)

assert len(image) == 352, len(image)
assert image[0] == 0x4E4F5641

with open("nova1_model_image.mem", "w", encoding="utf-8") as f:
    for word in image:
        f.write(f"{word:08X}\n")

with open("instruction_memory.sv", "w", encoding="utf-8") as f:
    f.write("module instruction_memory (\n")
    f.write("    input logic [31:0] address,\n")
    f.write("    output logic [31:0] instruction\n")
    f.write(");\n\n")
    f.write(f"    logic [31:0] mem [0:{ROM_WORDS-1}];\n")
    f.write("    integer i;\n\n")
    f.write("    initial begin\n")
    f.write(f"        for (i = 0; i < {ROM_WORDS}; i = i + 1)\n")
    f.write("            mem[i] = 32'h00000013;\n\n")
    for i, (insn, comment) in enumerate(zip(program, comments)):
        f.write(f"        mem[{i}] = 32'h{insn:08X}; // {comment}\n")
    f.write("    end\n\n")
    f.write("    always_comb begin\n")
    f.write("        instruction = mem[address[13:2]];\n")
    f.write("    end\n\nendmodule\n")

with open("nova1_model_loader_program_listing.txt", "w", encoding="utf-8") as f:
    for i, (insn, comment) in enumerate(zip(program, comments)):
        f.write(f"{i*4:08X}  {insn:08X}  {comment}\n")

# Keep the existing Python<->RTL reference-vector artifact synchronized.
np.savez(
    "nova1_rtl_vectors.npz",
    input_image=model["test_input"].astype(np.uint8),
    expected_layer1=model["expected_layer1"].astype(np.uint8),
    expected_scores=model["expected_scores"].astype(np.uint8),
    expected_class=np.array(int(model["expected_class"]), dtype=np.int32),
    test_index=np.array(int(model["test_index"]), dtype=np.int32),
    shift1=np.array(SHIFT1, dtype=np.int32),
    shift2=np.array(SHIFT2, dtype=np.int32),
)

print(f"Generated instruction_memory.sv: {len(program)} instructions")
print(f"Generated nova1_model_image.mem: {len(image)} words = {len(image)*4} bytes")
print("Model base: 0x0000C000")
print("Expected scores: [10, 0, 0, 0, 12, 25, 0, 13]")
print("Expected class: 5")
