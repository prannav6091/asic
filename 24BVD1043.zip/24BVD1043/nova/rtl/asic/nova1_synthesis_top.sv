module nova1_synthesis_top (
    input logic clk,
    input logic reset
);

    nova1_soc NOVA1_SOC (
        .clk   (clk),
        .reset (reset)
    );

endmodule
