
# ============================================================
# NOVA-1 CNN Accelerator V2
# Cadence Genus Synthesis Script
#
# All input files are located in the same directory:
#   rtl/
#     run_genus.tcl
#     nova1_cnn_accel_v2.sdc
#     input_buffer_v2.sv
#     weight_buffer_v2.sv
#     mac_array_v2.sv
#     accumulator_v2.sv
#     postprocess_v2.sv
#     cnn_controller_v2.sv
#     cnn_datapath_v2.sv
#     nova1_cnn_accel_v2.sv
#
# Run from rtl:
#   genus -files run_genus.tcl
#
# Top module: nova1_cnn_accel_v2
# Library:    180 nm typical.lib
# ============================================================


# ============================================================
# 1. PROJECT DIRECTORIES
# ============================================================

set SCRIPT_DIR [file dirname [file normalize [info script]]]
set RTL_DIR    $SCRIPT_DIR

set LIB_DIR  "/home/install/FOUNDRY/digital/90nm/dig/lib"
set LIB_FILE [file join $LIB_DIR typical.lib]

# All generated outputs go under rtl/reports.
set REPORT_DIR  [file join $RTL_DIR reports]
set NETLIST_DIR [file join $REPORT_DIR netlist]
set INNOVUS_DIR [file join $REPORT_DIR innovus]

file mkdir $REPORT_DIR
file mkdir $NETLIST_DIR
file mkdir $INNOVUS_DIR


# ============================================================
# 2. DESIGN CONFIGURATION
# ============================================================

set TOP nova1_cnn_accel_v2

# SDC is in the same directory as this TCL script.
set SDC_FILE [file join $RTL_DIR nova1_cnn_accel_v2.sdc]

set NETLIST_FILE [file join $NETLIST_DIR \
    nova1_cnn_accel_v2_mapped.v]

set INNOVUS_SDC [file join $INNOVUS_DIR \
    nova1_cnn_accel_v2.sdc]


# ============================================================
# 3. RTL SOURCE FILES
# ============================================================

set RTL_FILES [list \
    [file join $RTL_DIR input_buffer_v2.sv] \
    [file join $RTL_DIR weight_buffer_v2.sv] \
    [file join $RTL_DIR mac_array_v2.sv] \
    [file join $RTL_DIR accumulator_v2.sv] \
    [file join $RTL_DIR postprocess_v2.sv] \
    [file join $RTL_DIR cnn_controller_v2.sv] \
    [file join $RTL_DIR cnn_datapath_v2.sv] \
    [file join $RTL_DIR nova1_cnn_accel_v2.sv] \
]


# ============================================================
# 4. CHECK INPUT FILES
# ============================================================

puts ""
puts "=================================================="
puts " NOVA-1 CNN ACCELERATOR V2 - GENUS SYNTHESIS"
puts "=================================================="
puts "RTL directory: $RTL_DIR"
puts "Top module   : $TOP"
puts "Library      : $LIB_FILE"
puts "SDC          : $SDC_FILE"
puts "Reports      : $REPORT_DIR"
puts "=================================================="

if {![file isdirectory $RTL_DIR]} {
    error "RTL directory not found: $RTL_DIR"
}

if {![file exists $LIB_FILE]} {
    error "Standard-cell Liberty file not found: $LIB_FILE"
}

if {![file exists $SDC_FILE]} {
    error "SDC file not found: $SDC_FILE"
}

foreach f $RTL_FILES {
    if {![file exists $f]} {
        error "RTL file not found: $f"
    }
}

puts "All required input files exist."


# ============================================================
# 5. READ STANDARD-CELL LIBRARY
# ============================================================

puts ""
puts "Reading standard-cell library..."

set_db init_lib_search_path $LIB_DIR
read_libs $LIB_FILE

puts "Library read command issued."


# ============================================================
# 6. READ SYSTEMVERILOG RTL
# ============================================================

puts ""
puts "Reading SystemVerilog RTL..."

read_hdl -sv $RTL_FILES

puts "RTL read command issued."


# ============================================================
# 7. ELABORATE DESIGN
# ============================================================

puts ""
puts "Elaborating top module: $TOP"

elaborate $TOP

puts ""
puts "Checking for unresolved references..."

check_design -unresolved


# ============================================================
# 8. APPLY TIMING CONSTRAINTS
# ============================================================

puts ""
puts "Reading SDC constraints..."

read_sdc $SDC_FILE

puts "Generating clock report..."

report_clocks > [file join $REPORT_DIR clocks.rpt]


# ============================================================
# 9. SYNTHESIS EFFORT
# ============================================================

puts ""
puts "Configuring synthesis effort..."

set_db syn_generic_effort medium
set_db syn_map_effort medium


# ============================================================
# 10. GENERIC SYNTHESIS
# ============================================================

puts ""
puts "Starting generic synthesis..."

syn_generic

puts "Generic synthesis command completed."


# ============================================================
# 11. TECHNOLOGY MAPPING
# ============================================================

puts ""
puts "Starting technology mapping..."

syn_map

puts "Technology mapping command completed."


# ============================================================
# 12. POST-MAPPING OPTIMIZATION
# ============================================================

puts ""
puts "Starting post-mapping optimization..."

syn_opt

puts "Optimization command completed."


# ============================================================
# 13. WRITE MAPPED GATE-LEVEL NETLIST
# ============================================================

puts ""
puts "Writing mapped gate-level netlist..."

write_hdl > $NETLIST_FILE

puts "Mapped netlist path:"
puts "  $NETLIST_FILE"


# ============================================================
# 14. EXPORT SDC FOR INNOVUS
# ============================================================

puts ""
puts "Exporting SDC for Innovus..."

write_sdc > $INNOVUS_SDC

puts "Exported SDC path:"
puts "  $INNOVUS_SDC"


# ============================================================
# 15. AREA REPORT
# ============================================================

puts ""
puts "Generating area report..."

report_area > [file join $REPORT_DIR area.rpt]


# ============================================================
# 16. TIMING REPORT
# ============================================================

puts ""
puts "Generating timing report..."

report_timing -max_paths 50 \
    > [file join $REPORT_DIR timing.rpt]


# ============================================================
# 17. POWER REPORT
# ============================================================

puts ""
puts "Generating power report..."

report_power > [file join $REPORT_DIR power.rpt]


# ============================================================
# 18. QUALITY-OF-RESULTS REPORT
# ============================================================

puts ""
puts "Generating QoR report..."

report_qor > [file join $REPORT_DIR qor.rpt]


# ============================================================
# 19. FINAL DESIGN CHECK
# ============================================================

puts ""
puts "Generating final design check..."

check_design -unresolved \
    > [file join $REPORT_DIR design_check.rpt]


# ============================================================
# 20. VERIFY OUTPUT FILES
# ============================================================

puts ""
puts "Checking generated output files..."

if {![file exists $NETLIST_FILE]} {
    error "Mapped netlist was not generated: $NETLIST_FILE"
}

if {[file size $NETLIST_FILE] == 0} {
    error "Mapped netlist is empty: $NETLIST_FILE"
}

puts "Mapped netlist exists and is non-empty."


# ============================================================
# 21. COMPLETION SUMMARY
# ============================================================

puts ""
puts "=================================================="
puts " GENUS SCRIPT REACHED THE END"
puts "=================================================="
puts "Mapped netlist:"
puts "  $NETLIST_FILE"
puts ""
puts "Reports:"
puts "  [file join $REPORT_DIR clocks.rpt]"
puts "  [file join $REPORT_DIR area.rpt]"
puts "  [file join $REPORT_DIR timing.rpt]"
puts "  [file join $REPORT_DIR power.rpt]"
puts "  [file join $REPORT_DIR qor.rpt]"
puts "  [file join $REPORT_DIR design_check.rpt]"
puts ""
puts "Innovus SDC:"
puts "  $INNOVUS_SDC"
puts "=================================================="
puts "Review the Genus log for errors and warnings."
puts "=================================================="
gui_show

