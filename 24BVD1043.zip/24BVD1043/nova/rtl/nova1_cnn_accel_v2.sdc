
# ============================================================
# NOVA-1 CNN Accelerator V2
# Timing constraints for Genus synthesis and Innovus
# Illustrative target: 100 MHz
# ============================================================

# Main clock: 10 ns period
create_clock -name CORE_CLK -period 10.000 [get_ports clk]

# Clock uncertainty and transition
set_clock_uncertainty 0.200 [get_clocks CORE_CLK]
set_clock_transition 0.100 [get_clocks CORE_CLK]

# Input delays relative to the main clock
set_input_delay 2.000 -clock CORE_CLK \
    [get_ports {cfg_wr_en cfg_wr_sel cfg_wr_addr[*] \
                cfg_wr_data[*] bias[*] shift_amount[*] start}]

# Input transition assumptions
set_input_transition 0.100 \
    [get_ports {cfg_wr_en cfg_wr_sel cfg_wr_addr[*] \
                cfg_wr_data[*] bias[*] shift_amount[*] start}]

# Output delays relative to the main clock
set_output_delay 2.000 -clock CORE_CLK \
    [get_ports {busy done result[*]}]

# Output load assumption
set_load 0.010 [get_ports {busy done result[*]}]

# Asynchronous active-low reset is not timed as a data path
set_false_path -from [get_ports rst_n]

# ============================================================
# End of constraints
# ============================================================

