`timescale 1ns/1ps

module nova1_cnn_inference_top (
    input  logic clk,
    input  logic rst_n,

    // Input tensor loading: 64 signed INT8 values
    input  logic        load_input_en,
    input  logic [5:0]  load_input_addr,
    input  logic signed [7:0] load_input_data,

    // Weight loading: 324 signed INT8 values
    // 0..35   : Layer 0
    // 36..323 : Layer 1
    input  logic        load_weight_en,
    input  logic [8:0]  load_weight_addr,
    input  logic signed [7:0] load_weight_data,

    // Bias loading: 12 signed INT32 values
    // 0..3 : Layer 0
    // 4..11: Layer 1
    input  logic        load_bias_en,
    input  logic [3:0]  load_bias_addr,
    input  logic signed [31:0] load_bias_data,

    // Inference control
    input  logic start,
    output logic busy,
    output logic done,

    // Final output: 8 signed INT8 values
    input  logic [2:0] output_addr,
    output logic signed [7:0] output_data
);

    // --------------------------------------------------
    // Fixed model configuration
    // --------------------------------------------------

    localparam integer INPUT_SIZE       = 64;
    localparam integer WEIGHT_COUNT     = 324;
    localparam integer BIAS_COUNT       = 12;
    localparam integer INTERMEDIATE_SIZE = 36;

    localparam integer L0_SHIFT = 10;
    localparam integer L1_SHIFT = 6;

    // --------------------------------------------------
    // Storage
    // --------------------------------------------------

    logic signed [7:0] input_mem [0:63];
    logic signed [7:0] weight_mem [0:323];
    logic signed [31:0] bias_mem [0:11];

    // Layer 0 output: [channel][y][x]
    logic signed [7:0] feature_mem [0:35];

    // Layer 1 output: 8 values
    logic signed [7:0] output_mem [0:7];

    // --------------------------------------------------
    // Controller
    // --------------------------------------------------

    typedef enum logic [1:0] {
        IDLE,
        MAC,
        FINISH
    } state_t;

    state_t state;

    logic layer;

    logic [3:0] out_channel;
    logic [1:0] out_y;
    logic [1:0] out_x;

    // Layer 0: 9 products per output
    // Layer 1: 36 products per output
    logic [5:0] reduction_idx;

    logic signed [31:0] accumulator;

    integer input_idx;
    integer weight_idx;
    integer bias_idx;
    integer reduction_limit;
    integer shift_amount;

    logic signed [7:0] current_input;
    logic signed [7:0] current_weight;
    logic signed [15:0] product;

    logic signed [63:0] final_sum;

    // --------------------------------------------------
    // Quantization: arithmetic shift, ReLU, INT8 clamp
    // --------------------------------------------------

    function automatic logic signed [7:0] quantize_relu (
        input logic signed [63:0] value,
        input integer shift_amt
    );
        logic signed [63:0] shifted;
        begin
            shifted = value >>> shift_amt;

            if (shifted <= 0)
                quantize_relu = 8'sd0;
            else if (shifted > 127)
                quantize_relu = 8'sd127;
            else
                quantize_relu = shifted[7:0];
        end
    endfunction

    // --------------------------------------------------
    // Address generation
    //
    // Layer 0:
    //   Input  = 8x8x1
    //   Output = 3x3x4
    //   Kernel = 3x3, stride 2
    //
    // Layer 1:
    //   Input  = 3x3x4
    //   Output = 1x1x8
    //   Kernel = 3x3, stride 1
    // --------------------------------------------------

    always_comb begin
        input_idx       = 0;
        weight_idx      = 0;
        bias_idx        = 0;
        reduction_limit = 9;
        shift_amount    = L0_SHIFT;

        if (layer == 1'b0) begin
            // Layer 0: reduction_idx = ky*3 + kx

            input_idx =
                ((out_y * 2) + (reduction_idx / 3)) * 8
                + ((out_x * 2) + (reduction_idx % 3));

            weight_idx =
                (out_channel * 9) + reduction_idx;

            bias_idx = out_channel;

            reduction_limit = 9;
            shift_amount = L0_SHIFT;
        end
        else begin
            // Layer 1: reduction_idx = ic*9 + ky*3 + kx

            input_idx = reduction_idx;

            weight_idx =
                36 + (out_channel * 36) + reduction_idx;

            bias_idx = 4 + out_channel;

            reduction_limit = 36;
            shift_amount = L1_SHIFT;
        end

        if (layer == 1'b0)
            current_input = input_mem[input_idx];
        else
            current_input = feature_mem[input_idx];

        current_weight = weight_mem[weight_idx];

        product = $signed(current_input) *
                  $signed(current_weight);

        final_sum =
            {{32{accumulator[31]}}, accumulator}
            + {{48{product[15]}}, product}
            + {{32{bias_mem[bias_idx][31]}},
                bias_mem[bias_idx]};
    end

    // --------------------------------------------------
    // Output interface
    // --------------------------------------------------

    always_comb begin
        output_data = output_mem[output_addr];
    end

    // --------------------------------------------------
    // Input, weight and bias loading
    // --------------------------------------------------

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Memories are loaded through their interfaces.
            // Reset controller state below.
        end
        else begin
            if (load_input_en)
                input_mem[load_input_addr] <= load_input_data;

            if (load_weight_en)
                weight_mem[load_weight_addr] <= load_weight_data;

            if (load_bias_en)
                bias_mem[load_bias_addr] <= load_bias_data;
        end
    end

    // --------------------------------------------------
    // Inference state machine
    // --------------------------------------------------

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state          <= IDLE;
            layer          <= 1'b0;
            out_channel    <= 4'd0;
            out_y          <= 2'd0;
            out_x          <= 2'd0;
            reduction_idx  <= 6'd0;
            accumulator    <= 32'sd0;
            busy           <= 1'b0;
            done           <= 1'b0;
        end
        else begin
            // done is a one-cycle pulse
            done <= 1'b0;

            case (state)

                IDLE: begin
                    busy <= 1'b0;

                    if (start) begin
                        layer         <= 1'b0;
                        out_channel   <= 4'd0;
                        out_y         <= 2'd0;
                        out_x         <= 2'd0;
                        reduction_idx <= 6'd0;
                        accumulator   <= 32'sd0;

                        busy  <= 1'b1;
                        state <= MAC;
                    end
                end

                MAC: begin
                    if (reduction_idx ==
                        reduction_limit - 1) begin

                        // Complete the current output element.
                        if (layer == 1'b0) begin
                            feature_mem[
                                (out_channel * 9)
                                + (out_y * 3)
                                + out_x
                            ] <= quantize_relu(
                                final_sum, shift_amount
                            );
                        end
                        else begin
                            output_mem[out_channel] <=
                                quantize_relu(
                                    final_sum, shift_amount
                                );
                        end

                        accumulator   <= 32'sd0;
                        reduction_idx <= 6'd0;

                        // Advance output coordinates.
                        if (layer == 1'b0) begin

                            if (out_x < 2) begin
                                out_x <= out_x + 1'b1;
                            end
                            else begin
                                out_x <= 2'd0;

                                if (out_y < 2) begin
                                    out_y <= out_y + 1'b1;
                                end
                                else begin
                                    out_y <= 2'd0;

                                    if (out_channel < 3) begin
                                        out_channel <=
                                            out_channel + 1'b1;
                                    end
                                    else begin
                                        // Layer 0 complete.
                                        // Start Layer 1.
                                        layer       <= 1'b1;
                                        out_channel <= 4'd0;
                                        out_y       <= 2'd0;
                                        out_x       <= 2'd0;
                                    end
                                end
                            end
                        end
                        else begin

                            if (out_channel < 7) begin
                                out_channel <=
                                    out_channel + 1'b1;
                            end
                            else begin
                                // Entire two-layer model done.
                                state <= FINISH;
                            end
                        end
                    end
                    else begin
                        // Accumulate one INT8 product.
                        accumulator <=
                            accumulator + product;

                        reduction_idx <=
                            reduction_idx + 1'b1;
                    end
                end

                FINISH: begin
                    busy  <= 1'b0;
                    done  <= 1'b1;
                    state <= IDLE;
                end

                default: begin
                    state <= IDLE;
                    busy  <= 1'b0;
                end

            endcase
        end
    end

endmodule
