# Synthesis of nova1_det_top (Cadence Genus)

1. Copy the `syn/` and `rtl/` folders to the Cadence machine, keeping them side by side.
2. Edit `LIB_DIR` and `LIBS` at the top of `run_genus.tcl` (your 90 nm `typical.lib`).
3. `cd syn && genus -files run_genus.tcl -log genus_det`
4. Results: `out/nova1_det_top_mapped.v`, `out/nova1_det_top_syn.sdc`, reports in `reports/`.

## Memories are black boxes (on purpose)
The design needs ~300 KB of storage (153,600 + 76,800 + 71,440 + 1,920 bytes).
As flip-flops that is ~2.4 million flops and would make Genus run for hours
(the same problem as the full SoC). So `nova1_det_mems.sv` is not read, and the
four wrappers stay as black boxes. Check `reports/check_unresolved.rpt`: exactly
these four should be listed: nova1_det_mem_acta, nova1_det_mem_actb,
nova1_det_mem_w, nova1_det_mem_p.

Consequences, to state correctly in any report:
* Reported area = logic only (MAC lanes, requantizer, address generation, FSM,
  parameter registers). Memory area is NOT included.
* Timing paths that start or end at memory pins are not checked until real
  SRAM macros (.lib/.lef from your kit's memory compiler) replace the wrappers.
* The constraints in `nova1_det_top.sdc` are assumptions (100 MHz, 2 ns I/O
  delay); change them if your target differs.

No synthesis has been run for this design yet; there are no area, timing or
power numbers until you run it.
