if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name maxtiming\
   -timing\
    [list ${::IMEX::libVar}/mmmc/slow.lib]
create_library_set -name mintiming\
   -timing\
    [list ${::IMEX::libVar}/mmmc/fast.lib]
create_rc_corner -name default_rc_corner\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0
create_delay_corner -name maxdelay\
   -library_set maxtiming
create_delay_corner -name mindelay\
   -library_set mintiming
create_constraint_mode -name constraints\
   -sdc_files\
    [list /dev/null]
create_analysis_view -name worstcase -constraint_mode constraints -delay_corner maxdelay
create_analysis_view -name bestcase -constraint_mode constraints -delay_corner mindelay
set_analysis_view -setup [list worstcase] -hold [list bestcase]
