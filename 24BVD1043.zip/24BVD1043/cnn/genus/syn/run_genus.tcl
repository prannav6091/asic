# run_genus.tcl - Cadence Genus synthesis of nova1_det_top
# Run from the syn/ directory:   genus -files run_genus.tcl -log genus_det
#
# EDIT THE TWO LINES BELOW to point at your 90 nm library (the same
# typical.lib used for the nova1_cnn_accel_v2 run).
set LIB_DIR  /home/install/FOUNDRY/digital/90nm/dig/lib
set LIBS     { typical.lib }

set TOP  nova1_det_top
set OUT  ./out
set RPT  ./reports
file mkdir $OUT $RPT

set_db information_level 7
set_db max_cpus_per_server 8
# memories are intentionally not read: keep them as black boxes, do not error
set_db hdl_error_on_blackbox false

# ---------------- libraries ----------------
set_db init_lib_search_path $LIB_DIR
read_libs $LIBS

# ---------------- RTL ----------------
set fp [open filelist_syn.f r]
set SRC {}
foreach line [split [read $fp] "\n"] {
    set line [string trim $line]
    if {$line ne "" && ![string match "#*" $line]} { lappend SRC $line }
}
close $fp
puts "RTL files: $SRC"
read_hdl -sv $SRC

puts "ELAB START [clock format [clock seconds]]"
elaborate $TOP
current_design $TOP
check_design -unresolved > $RPT/check_unresolved.rpt
check_design -all        > $RPT/check_design.rpt
report_hierarchy         > $RPT/hierarchy.rpt
puts "ELAB DONE [clock format [clock seconds]]"

# ---------------- constraints ----------------
read_sdc nova1_det_top.sdc
check_timing_intent > $RPT/timing_intent.rpt

# ---------------- synthesis ----------------
set_db syn_generic_effort medium
set_db syn_map_effort     medium
set_db syn_opt_effort     medium

puts "GENERIC START [clock format [clock seconds]]"
syn_generic
report_area > $RPT/area_generic.rpt
puts "MAP START [clock format [clock seconds]]"
syn_map
puts "OPT START [clock format [clock seconds]]"
syn_opt
puts "SYN DONE [clock format [clock seconds]]"

# ---------------- reports ----------------
report_qor                   > $RPT/qor.rpt
report_area                  > $RPT/area.rpt
report_gates                 > $RPT/gates.rpt
report_timing -max_paths 50  > $RPT/timing.rpt
report_power                 > $RPT/power.rpt
report_messages              > $RPT/messages.rpt

# ---------------- outputs ----------------
write_hdl    > $OUT/${TOP}_mapped.v
write_sdc    > $OUT/${TOP}_syn.sdc
write_design -innovus -base_name $OUT/${TOP}_final
puts "ALL OUTPUTS WRITTEN to $OUT and $RPT"
gui_show
