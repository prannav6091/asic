#######################################################
#                                                     
#  Innovus Command Logging File                     
#  Created on Fri Oct 23 12:13:23 2026                
#                                                     
#######################################################

#@(#)CDS: Innovus v21.15-s110_1 (64bit) 09/23/2022 13:08 (Linux 3.10.0-693.el7.x86_64)
#@(#)CDS: NanoRoute 21.15-s110_1 NR220912-2004/21_15-UB (database version 18.20.592) {superthreading v2.17}
#@(#)CDS: AAE 21.15-s039 (64bit) 09/23/2022 (Linux 3.10.0-693.el7.x86_64)
#@(#)CDS: CTE 21.15-s038_1 () Sep 20 2022 11:42:13 ( )
#@(#)CDS: SYNTECH 21.15-s012_1 () Sep  5 2022 10:25:51 ( )
#@(#)CDS: CPE v21.15-s076
#@(#)CDS: IQuantus/TQuantus 21.1.1-s867 (64bit) Sun Jun 26 22:12:54 PDT 2022 (Linux 3.10.0-693.el7.x86_64)

set_global _enable_mmmc_by_default_flow      $CTE::mmmc_default
suppressMessage ENCEXT-2799
getVersion
getVersion
getVersion
win
save_global Default.globals
set init_gnd_net VSS
set init_lef_file ../../../../../install/FOUNDRY/digital/90nm/dig/lef/gsclib090_translated.lef
set init_design_settop 0
set init_verilog out/nova1_det_top_mapped.v
set init_mmmc_file Default.view
set init_pwr_net VDD
init_design
getIoFlowFlag
setIoFlowFlag 0
floorPlan -site gsclib090site -r 0.991829754893 0.699993 8 8 8 8
uiSetTool select
getIoFlowFlag
fit
setIoFlowFlag 0
floorPlan -site gsclib090site -r 0.991345397325 0.699652 8.12 8.12 8.12 8.12
uiSetTool select
getIoFlowFlag
fit
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
setAddRingMode -ring_target default -extend_over_row 0 -ignore_rows 0 -avoid_short 0 -skip_crossing_trunks none -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size 1 -orthogonal_only true -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape }
addRing -nets {VDD VSS} -type core_rings -follow core -layer {top Metal9 bottom Metal9 left Metal8 right Metal8} -width {top 1.8 bottom 1.8 left 1.8 right 1.8} -spacing {top 0.5 bottom 0.5 left 0.5 right 0.5} -offset {top 1.8 bottom 1.8 left 1.8 right 1.8} -center 0 -threshold 0 -jog_distance 0 -snap_wire_center_to_grid None
setAddRingMode -ring_target default -extend_over_row 0 -ignore_rows 0 -avoid_short 0 -skip_crossing_trunks none -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size 1 -orthogonal_only true -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape }
addRing -nets {VDD VSS} -type core_rings -follow core -layer {top Metal9 bottom Metal9 left Metal8 right Metal8} -width {top 1.8 bottom 1.8 left 1.8 right 1.8} -spacing {top 0.5 bottom 0.5 left 0.5 right 0.5} -offset {top 1.8 bottom 1.8 left 1.8 right 1.8} -center 0 -threshold 0 -jog_distance 0 -snap_wire_center_to_grid None
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {VDD VSS} -layer Metal9 -direction horizontal -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from bottom -start_offset 1 -stop_offset 1 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {VDD VSS} -layer Metal9 -direction horizontal -width 1.8 -spacing 0.5 -number_of_sets 25 -start_from bottom -start_offset 1 -stop_offset 1 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {VDD VSS} -layer Metal8 -direction vertical -width 1.8 -spacing 0.5 -number_of_sets 25 -start_from left -start_offset 1 -stop_offset 1 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
getSrouteMode -allowWrongWayRoute -quiet
getSrouteMode -viaThruToClosestRing -quiet
getSrouteMode -extendNearestTarget -quiet
getSrouteMode -targetNumber -quiet
getSrouteMode -targetSearchDistance -quiet
getSrouteMode -jogThresholdRatio -quiet
getSrouteMode -blockPinConnectRingPinCorners -quiet
getSrouteMode -blockPinRouteWithPinWidth -quiet
getSrouteMode -padPinMinViaSize -quiet
getSrouteMode -padPinSplit -quiet
getSrouteMode -padRingLefConvention -quiet
getSrouteMode -signalPinAsPG -quiet
getSrouteMode -corePinJoinLimit -quiet
getSrouteMode -corePinLength -quiet
getSrouteMode -corePinLengthAsInstance -quiet
getSrouteMode -corePinReferenceMacro -quiet
getSrouteMode -treatEndcapAsCore -quiet
getSrouteMode -secondaryPinMaxGap -quiet
getSrouteMode -secondaryPinRailWidth -quiet
getSrouteMode -srpgAonCellPin -quiet
getSrouteMode -viaConnectToShape -quiet
getSrouteMode -layerNormalCost -quiet
getSrouteMode -layerWrongWayCost -quiet
setSrouteMode -viaConnectToShape { noshape }
sroute -connect { blockPin padPin padRing corePin floatingStripe } -layerChangeRange { Metal1(1) Metal9(9) } -blockPinTarget { nearestTarget } -padPinPortConnect { allPort oneGeom } -padPinTarget { nearestTarget } -corePinTarget { firstAfterRowEnd } -floatingStripeTarget { blockring padring ring stripe ringpin blockpin followpin } -allowJogging 1 -crossoverViaLayerRange { Metal1(1) Metal9(9) } -nets { VDD VSS } -allowLayerChange 1 -blockPin useLef -targetViaLayerRange { Metal1(1) Metal9(9) }
setRouteMode -earlyGlobalHonorMsvRouteConstraint false -earlyGlobalRoutePartitionPinGuide true
setEndCapMode -reset
setEndCapMode -boundary_tap false
setNanoRouteMode -quiet -droutePostRouteSpreadWire 1
setNanoRouteMode -quiet -droutePostRouteWidenWireRule LEFDefaultRouteSpec_gpdk090
setNanoRouteMode -quiet -timingEngine {}
setUsefulSkewMode -noBoundary false -maxAllowedDelay 1
setPlaceMode -reset
setPlaceMode -congEffort auto -timingDriven 1 -clkGateAware 1 -powerDriven 0 -ignoreScan 1 -reorderScan 1 -ignoreSpare 0 -placeIOPins 1 -moduleAwareSpare 0 -preserveRouting 1 -rmAffectedRouting 0 -checkRoute 0 -swapEEQ 0
setPlaceMode -fp false
place_design
saveDesign nova1_det_top.enc
getCTSMode -engine -quiet
getCTSMode -engine -quiet
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
getCTSMode -engine -quiet
clearGlobalNets
globalNetConnect VDD -type pgpin -pin VDD -instanceBasename * -hierarchicalInstance {}
globalNetConnect VSS -type pgpin -pin VSS -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect VDD -type pgpin -pin VDD -instanceBasename * -hierarchicalInstance {}
globalNetConnect VSS -type pgpin -pin VSS -instanceBasename * -hierarchicalInstance {}
zoomBox -143.95400 72.72900 450.29550 373.96300
zoomBox -90.90350 138.96800 338.44250 356.61000
zoomBox -52.57500 186.82600 257.62800 344.07250
zoomBox -70.18600 164.83700 294.75900 349.83300
zoomBox -177.69350 30.60350 521.42750 384.99850
zoomBox -264.07900 -77.25700 703.56300 413.25550
zoomBox -177.69400 30.60300 521.42750 384.99850
zoomBox -217.38500 -18.95450 605.11150 397.98150
getCTSMode -engine -quiet
getCTSMode -engine -quiet
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
getCTSMode -engine -quiet
create_ccopt_clock_tree_spec
ctd_win -side none -id ctd_window
selectInst {m_r_reg[55]}
zoomSelected
fit
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
report_clocks
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -preCTS
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_preCTS -outDir timingReports
getCTSMode -engine -quiet
ctd_win -side none -id ctd_window
ctd_win -side none -id ctd_window
deselectInst {m_r_reg[55]}
selectObject Net clk
zoomSelected
fit
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postCTS
optDesign -postCTS -hold
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix nova1_det_top_postCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_postCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_postCTS -outDir timingReports
setNanoRouteMode -quiet -routeWithTimingDriven 1
setNanoRouteMode -quiet -routeWithEco 0
setNanoRouteMode -quiet -routeWithSiDriven 1
setNanoRouteMode -quiet -routeTopRoutingLayer 9
setNanoRouteMode -quiet -routeBottomRoutingLayer 1
setNanoRouteMode -quiet -drouteEndIteration 1
setNanoRouteMode -quiet -routeWithTimingDriven true
setNanoRouteMode -quiet -routeWithSiDriven true
routeDesign -globalDetail
zoomBox -93.90250 63.49450 411.20950 319.54350
zoomBox -64.42500 83.17600 364.92050 300.81800
zoomBox 8.89650 125.91450 272.56900 259.57400
zoomBox -11.69650 113.91100 298.50650 271.15750
zoomBox -35.92350 99.78950 329.02100 284.78550
zoomBox -183.82100 13.58250 515.29900 367.97700
zoomBox -302.66100 -55.68700 664.97900 434.82450
fit
zoomBox -153.50500 19.40350 545.61200 373.79650
zoomBox -53.06100 79.71650 452.05100 335.76550
zoomBox -250.20700 14.44600 572.28550 431.38000
zoomBox -325.35450 -18.54550 642.28350 471.96500
zoomBox -413.76350 -57.35900 724.63400 519.71200
zoomBox -318.26950 -21.62600 649.36850 468.88450
setLayerPreference Metal9 -isSelectable 0
setLayerPreference Metal9 -isSelectable 1
setLayerPreference Metal9 -isVisible 0
setLayerPreference Metal9 -isVisible 1
zoomBox -249.05700 15.46750 573.43550 432.40150
zoomBox -61.58600 115.94000 367.76100 333.58250
zoomBox -190.22650 46.99700 508.89250 401.39100
zoomBox -249.05700 15.46750 573.43550 432.40150
zoomBox -7.82650 143.14400 497.28750 399.19400
zoomBox 140.31950 221.55350 450.52300 378.80050
zoomBox -43.63950 144.52000 550.61450 445.75650
zoomBox -285.45700 43.25750 682.18800 533.77150
pan -7.56400 279.83750
fit
zoomBox -65.08450 90.59450 440.02750 346.64350
zoomBox -28.72800 116.74600 400.61800 334.38800
zoomBox -217.38150 -18.95250 605.11100 397.98150
getCTSMode -engine -quiet
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -pathReports -drvReports -slackReports -numPaths 50 -prefix nova1_det_top_postRoute -outDir timingReports
setAnalysisMode -cppr both -clockGatingCheck true -timeBorrowing true -useOutputPinCap true -sequentialConstProp false -timingSelfLoopsNoSkew false -enableMultipleDriveNet true -clkSrcPath true -warn true -usefulSkew true -analysisType onChipVariation -log true
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -pathReports -drvReports -slackReports -numPaths 50 -prefix nova1_det_top_postRoute -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_postRoute -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_postRoute -outDir timingReports
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postRoute
optDesign -postRoute -hold
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -pathReports -drvReports -slackReports -numPaths 50 -prefix nova1_det_top_postRoute -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -hold -pathReports -slackReports -numPaths 50 -prefix nova1_det_top_postRoute -outDir timingReports
getMultiCpuUsage -localCpu
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report nova1_det_top.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
verifyConnectivity -type all -error 1000 -warning 50
saveDesign nova1_det_top.enc
zoomBox -165.89550 14.80250 533.22350 369.19650
zoomBox -122.13250 43.49450 472.11900 344.72950
zoomBox -26.43900 106.23300 338.50600 291.22900
zoomBox -3.59450 121.21000 306.60900 278.45700
zoomBox -277.95650 -58.66700 689.68650 431.84600
zoomBox -160.21600 -4.46600 662.28050 412.47000
pan -56.38300 147.83650
zoomBox -83.00550 87.05250 422.11050 343.10350
zoomBox -24.00500 130.96600 340.94200 315.96300
zoomBox 35.27150 175.08450 259.39500 288.69600
zoomBox 71.67400 202.17850 209.31450 271.95050
zoomBox 87.75100 214.14450 187.19650 264.55500
zoomBox 103.90300 226.16600 164.97500 257.12450
zoomBox 116.18900 235.31150 148.07050 251.47250
zoomBox 119.91300 238.08300 142.94750 249.75950
zoomBox 122.60300 240.08550 139.24600 248.52200
zoomBox 121.36650 239.16500 140.94650 249.09050
zoomBox 119.91200 238.08250 142.94750 249.75950
zoomBox 107.75550 229.03450 159.67150 255.35150
zoomBox 94.02450 218.81450 178.56100 261.66750
zoomBox 80.35700 208.64200 197.36350 267.95450
zoomBox 35.25800 175.07550 259.40600 288.69950
zoomBox -0.98050 148.10350 309.25950 305.36900
zoomBox -51.13700 110.77250 378.26100 328.44100
zoomBox -120.55800 59.10350 473.76450 360.37450
zoomBox -277.74550 -57.88900 690.01000 432.68100
zoomBox -164.70500 26.24550 534.49850 380.68250
zoomBox -83.03350 87.03250 422.14150 343.11350
zoomBox -24.02550 130.95150 340.96350 315.97000
zoomBox 18.60650 162.68250 282.31250 296.35900
zoomBox 80.35450 208.64150 197.36300 267.95500
zoomBox 107.75250 229.03350 159.67050 255.35150
zoomBox 118.19850 236.80800 145.30050 250.54650
zoomBox 122.59900 240.08400 139.24500 248.52200
zoomBox 125.39900 242.01500 135.62200 247.19700
zoomBox 127.11900 243.20050 133.39700 246.38300
zoomBox 128.17400 243.92850 132.03050 245.88350
zoomBox 128.82250 244.37550 131.19150 245.57650
zoomBox 128.38700 244.09900 131.66650 245.76150
zoomBox 128.11000 243.92300 131.96850 245.87900
zoomBox 126.95050 243.18700 133.23400 246.37200
zoomBox 125.79700 242.45400 134.49350 246.86250
zoomBox 125.06300 241.98800 135.29450 247.17450
zoomBox 120.58300 239.14200 140.18500 249.07850
zoomBox 118.92950 238.09150 141.99050 249.78150
zoomBox 95.56300 223.24850 167.50100 259.71500
zoomBox 73.95350 209.52150 191.09350 268.90150
zoomBox 52.44500 195.85900 214.57650 278.04600
zoomBox 22.67550 176.94900 247.07900 290.70250
zoomBox -44.73050 134.13100 320.67400 319.36000
zoomBox -111.82300 91.51250 393.92750 347.88500
zoomBox -263.73850 -4.98700 559.79200 412.47300
zoomBox -155.86400 60.01250 439.13700 361.62750
zoomBox -77.92450 106.97500 351.96400 324.89200
zoomBox 0.37850 154.15600 264.38400 287.98450
zoomBox 34.96000 174.99300 225.70500 271.68450
zoomBox 59.94600 190.04800 197.75900 259.90750
zoomBox 85.04800 205.17300 169.68250 248.07550
zoomBox 96.13400 211.85250 157.28300 242.85000
zoomBox 77.99600 200.92350 177.56850 251.39850
zoomBox 59.94200 190.04550 197.76000 259.90750
zoomBox 19.06500 165.41500 243.47950 279.17400
zoomBox -21.62200 140.89900 288.98650 298.35100
zoomBox -47.49600 125.30850 317.92600 310.54650
zoomBox -77.93600 106.96700 351.97200 324.89400
zoomBox -155.87950 60.00200 439.15000 361.63150
zoomBox -305.94950 -5.96250 517.62050 411.51750
zoomBox -172.78300 60.00200 422.24650 361.63150
zoomBox -35.13000 131.38300 330.29350 316.62150
zoomBox 101.32300 202.14100 239.14300 272.00400
zoomBox -35.13100 131.38200 330.29400 316.62150
zoomBox -309.80200 -11.05000 513.77500 406.43350
zoomBox -231.80250 21.19000 468.23800 376.05100
zoomBox -134.50000 43.79500 460.53450 345.42700
zoomBox -346.27600 -5.40400 477.30100 412.07950
zoomBox -231.80250 21.19000 468.23800 376.05100
zoomBox 6.02950 92.01650 371.45550 277.25650
zoomBox 109.98350 122.62650 334.40100 236.38700
zoomBox 173.82400 141.42500 311.64500 211.28850
zoomBox 223.22150 155.72550 295.16550 192.19500
zoomBox 155.58450 136.14500 317.72900 218.33850
zoomBox -247.77100 19.37450 452.28850 374.24550
zoomBox -414.95300 -41.74250 553.98800 449.42850
zoomBox -240.01100 20.34400 460.04950 375.21550
pan 14.31300 296.97900
pan -0.84150 273.82550
saveDesign nova1_det_top.enc
