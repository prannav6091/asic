# nova1_det_top.sdc - synthesis constraints (ASSUMPTIONS, edit to your targets)
#   * 100 MHz clock (10 ns) - same target as the earlier v2 runs
#   * inputs arrive / outputs are needed 2 ns after/before the clock edge
#   * 0.2 ns clock uncertainty
# Paths into and out of the four memory black boxes are NOT timed until the
# real SRAM macro .lib files are added (see README_SYN.md).

create_clock -name clk -period 10.0 [get_ports clk]
set_clock_uncertainty 0.2 [get_clocks clk]
set_clock_transition  0.1 [get_clocks clk]

set_input_delay  2.0 -clock clk [remove_from_collection [all_inputs] [get_ports {clk rst_n}]]
set_output_delay 2.0 -clock clk [all_outputs]

# asynchronous active-low reset: not timed as a data path
set_false_path -from [get_ports rst_n]

set_load 0.05 [all_outputs]
