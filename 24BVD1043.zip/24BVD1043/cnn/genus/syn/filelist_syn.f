# Synthesis file list for top module nova1_det_top (paths relative to syn/)
# NOT included on purpose:
#   ../rtl/nova1_det_mems.sv     memory wrappers  -> left as black boxes
#   ../rtl/nova1_det_sram_sp.sv  behavioural RAM  -> simulation only
../rtl/nova1_det_layer_rom.sv
../rtl/nova1_det_requant.sv
../rtl/nova1_det_mac_lanes.sv
../rtl/nova1_det_top.sv
