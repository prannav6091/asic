// nova1_det_layer_rom.sv
// Fixed layer descriptor table of the 320x240 detector (must match
// model/nova_spec.py LAYERS / GEOM exactly).
//
//  #  name  in (WxHxC)   out (WxHxC)  k s  ReLU  src->dst  wbase pbase
//  0  L1    320x240x1  -> 160x120x8   3 2  yes   B -> A       0     0
//  1  L2    160x120x8  ->  80x60x16   3 2  yes   A -> B       9    16
//  2  L3     80x60x16  ->  40x30x32   3 2  yes   B -> A      81    32
//  3  L4     40x30x32  ->  40x30x32   3 1  yes   A -> B     369    64
//  4  L5     40x30x32  ->  20x15x64   3 2  yes   B -> A     945    96
//  5  L6     20x15x64  ->  20x15x64   3 1  yes   A -> B    2097   160
//  6  HEAD   20x15x64  ->  20x15x10   1 1  no    B -> A    4401   224
module nova1_det_layer_rom (
    input  logic [2:0]  layer,
    output logic [8:0]  win,     // input width
    output logic [7:0]  hin,     // input height
    output logic [6:0]  cin,     // input channels
    output logic [7:0]  wout,
    output logic [6:0]  hout,
    output logic [6:0]  cout,
    output logic        k3,      // 1: 3x3 kernel, pad 1 ; 0: 1x1 kernel, pad 0
    output logic        s2,      // 1: stride 2 ; 0: stride 1
    output logic        relu,
    output logic        src_a,   // 1: read buffer A, write B ; 0: read B, write A
    output logic [2:0]  groups,  // ceil(cout/16)
    output logic [9:0]  terms,   // cin * k * k
    output logic [12:0] wbase,
    output logic [7:0]  pbase
);
    always @(*) begin
        case (layer)
            3'd0: begin win=320; hin=240; cin=1;  wout=160; hout=120; cout=8;  k3=1; s2=1; relu=1; src_a=0; groups=1; terms=9;   wbase=0;    pbase=0;   end
            3'd1: begin win=160; hin=120; cin=8;  wout=80;  hout=60;  cout=16; k3=1; s2=1; relu=1; src_a=1; groups=1; terms=72;  wbase=9;    pbase=16;  end
            3'd2: begin win=80;  hin=60;  cin=16; wout=40;  hout=30;  cout=32; k3=1; s2=1; relu=1; src_a=0; groups=2; terms=144; wbase=81;   pbase=32;  end
            3'd3: begin win=40;  hin=30;  cin=32; wout=40;  hout=30;  cout=32; k3=1; s2=0; relu=1; src_a=1; groups=2; terms=288; wbase=369;  pbase=64;  end
            3'd4: begin win=40;  hin=30;  cin=32; wout=20;  hout=15;  cout=64; k3=1; s2=1; relu=1; src_a=0; groups=4; terms=288; wbase=945;  pbase=96;  end
            3'd5: begin win=20;  hin=15;  cin=64; wout=20;  hout=15;  cout=64; k3=1; s2=0; relu=1; src_a=1; groups=4; terms=576; wbase=2097; pbase=160; end
            default: begin // 3'd6 HEAD
                     win=20;  hin=15;  cin=64; wout=20;  hout=15;  cout=10; k3=0; s2=0; relu=0; src_a=0; groups=1; terms=64;  wbase=4401; pbase=224; end
        endcase
    end
endmodule
