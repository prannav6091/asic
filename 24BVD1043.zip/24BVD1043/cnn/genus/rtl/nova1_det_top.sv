// nova1_det_top.sv
// NOVA-1 320x240 grayscale object-detection CNN accelerator (standalone).
//
// Network (fixed, see nova1_det_layer_rom.sv / model/nova_spec.py):
//   320x240x1 -> L1..L6 (3x3 conv + ReLU) -> HEAD (1x1 conv) -> 20x15x10 INT8
//
// Interface summary (full contract in docs/02_interface_contract.md):
//   * Load weights (wt_*) and per-channel params (prm_*) while not busy.
//   * Pulse start -> accelerator enters LOAD, raises pix_ready and accepts
//     76,800 pixels (row-major) on pix_valid & pix_ready, then computes.
//   * done is held high when finished (until the next start).
//   * Read results: drive out_addr (0..2999), out_data valid 1 cycle later.
//     Order: addr = (cell_row*20 + cell_col)*10 + channel.
//   * error (sticky until next accepted start): start, wt_wr_en or prm_wr_en
//     while busy.
//
// Compute: 16 lanes = 16 output channels in parallel. Each cycle one input
// activation is read and multiplied by 16 weights (one 128-bit weight word).
module nova1_det_top (
    input  logic          clk,
    input  logic          rst_n,
    // control / status
    input  logic          start,
    output logic          busy,
    output logic          done,
    output logic          error,
    output logic [31:0]   perf_cycles,     // cycles spent busy in last/current run
    // pixel stream (accepted only while pix_ready)
    input  logic          pix_valid,
    input  logic [7:0]    pix_data,
    output logic          pix_ready,
    // weight memory load: one 128-bit word = 16 INT8 weights (lane l = byte l)
    input  logic          wt_wr_en,
    input  logic [12:0]   wt_wr_addr,
    input  logic [127:0]  wt_wr_data,
    // parameter memory load: [31:0] bias, [47:32] M, [53:48] S
    input  logic          prm_wr_en,
    input  logic [7:0]    prm_wr_addr,
    input  logic [63:0]   prm_wr_data,
    // result readout
    input  logic [11:0]   out_addr,
    output logic signed [7:0] out_data
);
    localparam integer LANES     = 16;
    localparam integer NPIX      = 76800;
    localparam integer NOUT      = 3000;
    localparam [2:0]   LAST_LAYER = 3'd6;

    typedef enum logic [3:0] {S_IDLE, S_LOAD, S_PLOAD, S_PINIT, S_MAC, S_DRAIN, S_WRITE, S_DONE} state_t;
    state_t state;

    // ---------------- layer descriptor ----------------
    logic [2:0]  layer;
    logic [8:0]  d_win;  logic [7:0] d_hin;  logic [6:0] d_cin;
    logic [7:0]  d_wout; logic [6:0] d_hout; logic [6:0] d_cout;
    logic        d_k3, d_s2, d_relu, d_src_a;
    logic [2:0]  d_groups; logic [9:0] d_terms; logic [12:0] d_wbase; logic [7:0] d_pbase;

    nova1_det_layer_rom u_rom (
        .layer(layer), .win(d_win), .hin(d_hin), .cin(d_cin), .wout(d_wout), .hout(d_hout),
        .cout(d_cout), .k3(d_k3), .s2(d_s2), .relu(d_relu), .src_a(d_src_a),
        .groups(d_groups), .terms(d_terms), .wbase(d_wbase), .pbase(d_pbase));

    // ---------------- counters ----------------
    logic [16:0] pix_cnt;
    logic [2:0]  g;            // output-channel group
    logic [6:0]  oy;
    logic [7:0]  ox;
    logic [1:0]  ky, kx;
    logic [6:0]  ci;
    logic [9:0]  t;            // term index within group
    logic [4:0]  j;            // lane counter (PLOAD / WRITE)
    logic [3:0]  j_d;
    logic        pl_valid_d, mac_valid_d, inb_d;

    // ---------------- per-lane parameters ----------------
    logic [LANES*32-1:0] bias_r;
    logic [LANES*16-1:0] m_r;
    logic [LANES*6-1:0]  s_r;

    // ---------------- memories ----------------
    logic        a_we, b_we, w_we, p_we;
    logic [17:0] a_addr, b_addr;
    logic [12:0] w_addr;
    logic [7:0]  p_addr;
    logic [7:0]  a_wdata, b_wdata, a_rdata, b_rdata;
    logic [127:0] w_rdata;
    logic [63:0]  p_rdata;

    nova1_det_mem_acta u_act_a (.clk(clk), .we(a_we), .addr(a_addr), .wdata(a_wdata),     .rdata(a_rdata));
    nova1_det_mem_actb u_act_b (.clk(clk), .we(b_we), .addr(b_addr), .wdata(b_wdata),     .rdata(b_rdata));
    nova1_det_mem_w    u_wmem  (.clk(clk), .we(w_we), .addr(w_addr), .wdata(wt_wr_data),  .rdata(w_rdata));
    nova1_det_mem_p    u_pmem  (.clk(clk), .we(p_we), .addr(p_addr), .wdata(prm_wr_data), .rdata(p_rdata));

    // ---------------- address generation ----------------
    logic [1:0]  k_last;
    logic        ci_last, term_last, lane_last, ox_last, oy_last, g_last;
    logic signed [10:0] iy, ix;
    logic        inb;
    logic [31:0] src_addr, dst_addr, wa;
    logic [6:0]  nl_m1;                // lanes used in this group minus 1
    logic [6:0]  co_base;

    always @(*) begin
        k_last    = d_k3 ? 2'd2 : 2'd0;
        ci_last   = (ci == d_cin - 7'd1);
        term_last = ci_last && (kx == (d_k3 ? 2'd2 : 2'd0)) && (ky == (d_k3 ? 2'd2 : 2'd0));
        co_base   = {g, 4'd0};
        nl_m1     = ((d_cout - co_base) > 7'd16) ? 7'd15 : (d_cout - co_base - 7'd1);
        lane_last = ({2'd0, j} == nl_m1);
        ox_last   = (ox == d_wout - 8'd1);
        oy_last   = (oy == d_hout - 7'd1);
        g_last    = (g == d_groups - 3'd1);

        iy  = $signed({4'd0, oy} << d_s2) + $signed({9'd0, ky}) - (d_k3 ? 11'sd1 : 11'sd0);
        ix  = $signed({3'd0, ox} << d_s2) + $signed({9'd0, kx}) - (d_k3 ? 11'sd1 : 11'sd0);
        inb = (iy >= 0) && (iy < $signed({3'd0, d_hin})) && (ix >= 0) && (ix < $signed({2'd0, d_win}));
        src_addr = inb ? (((iy[9:0] * d_win) + ix[9:0]) * d_cin + ci) : 32'd0;
        dst_addr = ((oy * d_wout) + ox) * d_cout + co_base + j;
        wa       = d_wbase + g * d_terms + t;
    end

    // ---------------- requantizer (shared, one lane per cycle) ----------------
    logic [LANES*32-1:0] mac_acc;
    logic signed [7:0] rq_y;
    logic [3:0] jl;
    assign jl = j[3:0];
    nova1_det_requant u_rq (
        .acc  (mac_acc[jl*32 +: 32]),
        .m    (m_r[jl*16 +: 16]),
        .s    (s_r[jl*6 +: 6]),
        .relu (d_relu),
        .y    (rq_y));

    // ---------------- MAC lanes ----------------
    logic signed [7:0]   mac_act;
    assign mac_act = inb_d ? $signed(d_src_a ? a_rdata : b_rdata) : 8'sd0;

    nova1_det_mac_lanes #(.LANES(LANES)) u_lanes (
        .clk(clk), .rst_n(rst_n),
        .load_bias(state == S_PINIT), .bias_vec(bias_r),
        .mac_en(mac_valid_d), .act(mac_act), .w_vec(w_rdata),
        .acc_vec(mac_acc));

    // ---------------- memory port muxes ----------------
    logic idle_like, pix_fire;
    assign idle_like = (state == S_IDLE) || (state == S_DONE);
    assign pix_ready = (state == S_LOAD);
    assign pix_fire  = pix_valid && pix_ready;

    always @(*) begin
        a_we = 1'b0; a_addr = 18'd0; a_wdata = 8'd0;
        b_we = 1'b0; b_addr = 18'd0; b_wdata = 8'd0;
        w_we = 1'b0; w_addr = wa[12:0];
        p_we = 1'b0; p_addr = d_pbase + {g, 4'd0} + {3'd0, j};
        case (state)
            S_IDLE, S_DONE: begin
                a_addr = {6'd0, out_addr};
                w_we = wt_wr_en;  w_addr = wt_wr_addr;
                p_we = prm_wr_en; p_addr = prm_wr_addr;
            end
            S_LOAD: begin
                b_we = pix_fire; b_addr = {1'b0, pix_cnt}; b_wdata = {1'b0, pix_data[7:1]};
            end
            S_MAC: begin
                if (d_src_a) a_addr = src_addr[17:0];
                else         b_addr = src_addr[17:0];
            end
            S_WRITE: begin
                if (d_src_a) begin b_we = 1'b1; b_addr = dst_addr[17:0]; b_wdata = rq_y; end
                else         begin a_we = 1'b1; a_addr = dst_addr[17:0]; a_wdata = rq_y; end
            end
            default: ;
        endcase
    end

    // ---------------- result readout ----------------
    logic oob_d;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) oob_d <= 1'b0;
        else        oob_d <= (out_addr >= NOUT);
    end
    assign out_data = oob_d ? 8'sd0 : $signed(a_rdata);

    // ---------------- status ----------------
    assign busy = !idle_like;
    assign done = (state == S_DONE);

    // ---------------- control FSM ----------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE; layer <= 3'd0; g <= 3'd0; oy <= 7'd0; ox <= 8'd0;
            ky <= 2'd0; kx <= 2'd0; ci <= 7'd0; t <= 10'd0; j <= 5'd0; j_d <= 4'd0;
            pix_cnt <= 17'd0; pl_valid_d <= 1'b0; mac_valid_d <= 1'b0; inb_d <= 1'b0;
            bias_r <= '0; m_r <= '0; s_r <= '0; error <= 1'b0; perf_cycles <= 32'd0;
        end
        else begin
            pl_valid_d  <= 1'b0;
            mac_valid_d <= 1'b0;
            if (busy) perf_cycles <= perf_cycles + 32'd1;

            if (!idle_like && (start || wt_wr_en || prm_wr_en)) error <= 1'b1;

            // capture parameter words loaded in S_PLOAD (1-cycle read latency)
            if (pl_valid_d) begin
                bias_r[j_d*32 +: 32] <= p_rdata[31:0];
                m_r[j_d*16 +: 16]    <= p_rdata[47:32];
                s_r[j_d*6 +: 6]      <= p_rdata[53:48];
            end

            case (state)
                S_IDLE, S_DONE: begin
                    if (start) begin
                        state <= S_LOAD; pix_cnt <= 17'd0; error <= 1'b0; perf_cycles <= 32'd0;
                    end
                end
                S_LOAD: begin
                    if (pix_fire) begin
                        if (pix_cnt == NPIX - 1) begin
                            state <= S_PLOAD; layer <= 3'd0; g <= 3'd0; j <= 5'd0;
                        end
                        pix_cnt <= pix_cnt + 17'd1;
                    end
                end
                S_PLOAD: begin
                    if (j == 5'd16) begin
                        state <= S_PINIT; oy <= 7'd0; ox <= 8'd0;
                    end
                    else begin
                        pl_valid_d <= 1'b1; j_d <= j[3:0]; j <= j + 5'd1;
                    end
                end
                S_PINIT: begin                       // acc <= bias (in u_lanes)
                    state <= S_MAC; ky <= 2'd0; kx <= 2'd0; ci <= 7'd0; t <= 10'd0;
                end
                S_MAC: begin                         // issue one term per cycle
                    mac_valid_d <= 1'b1;
                    inb_d       <= inb;
                    t <= t + 10'd1;
                    if (term_last) begin
                        state <= S_DRAIN;
                    end
                    else if (!ci_last) ci <= ci + 7'd1;
                    else begin
                        ci <= 7'd0;
                        if (kx != k_last) kx <= kx + 2'd1;
                        else begin kx <= 2'd0; ky <= ky + 2'd1; end
                    end
                end
                S_DRAIN: begin                       // last product accumulates this cycle
                    state <= S_WRITE; j <= 5'd0;
                end
                S_WRITE: begin                       // write one lane per cycle
                    if (!lane_last) j <= j + 5'd1;
                    else begin
                        j <= 5'd0;
                        if (!ox_last) begin ox <= ox + 8'd1; state <= S_PINIT; end
                        else begin
                            ox <= 8'd0;
                            if (!oy_last) begin oy <= oy + 7'd1; state <= S_PINIT; end
                            else begin
                                oy <= 7'd0;
                                if (!g_last) begin g <= g + 3'd1; state <= S_PLOAD; end
                                else begin
                                    g <= 3'd0;
                                    if (layer == LAST_LAYER) state <= S_DONE;
                                    else begin layer <= layer + 3'd1; state <= S_PLOAD; end
                                end
                            end
                        end
                    end
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
