// nova1_det_requant.sv
// y = clamp( ((acc * M) + 2^(S-1)) >>> S , lo, 127 ),  lo = 0 if relu else -128
// S = 0 -> no rounding term. Matches model/nova_spec.py requant() bit-exactly.
module nova1_det_requant (
    input  logic signed [31:0] acc,
    input  logic        [15:0] m,
    input  logic        [5:0]  s,
    input  logic               relu,
    output logic signed [7:0]  y
);
    logic signed [63:0] prod, rnd, shifted;
    always @(*) begin
        prod    = $signed({{32{acc[31]}}, acc}) * $signed({48'd0, m});
        rnd     = (s == 6'd0) ? 64'sd0 : (64'sd1 <<< (s - 6'd1));
        shifted = (prod + rnd) >>> s;
        if (shifted > 64'sd127)
            y = 8'sd127;
        else if (relu && shifted < 64'sd0)
            y = 8'sd0;
        else if (shifted < -64'sd128)
            y = -8'sd128;
        else
            y = shifted[7:0];
    end
endmodule
