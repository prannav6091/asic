// nova1_det_mems.sv
// Fixed-size memory wrappers used by nova1_det_top. Each one maps to ONE
// future SRAM/ROM macro. In simulation they use the behavioural
// nova1_det_sram_sp. In synthesis this file and nova1_det_sram_sp.sv are NOT
// read, so Genus keeps the four wrappers as black boxes (no flip-flop RAMs).
//
//   wrapper            words x bits      bytes     use
//   nova1_det_mem_acta 153,600 x 8      153,600   activations (L1/L3/L5/HEAD out)
//   nova1_det_mem_actb  76,800 x 8       76,800   input image, L2/L4/L6 out
//   nova1_det_mem_w      4,465 x 128     71,440   weights (16 per word)
//   nova1_det_mem_p        240 x 64       1,920   bias / M / S per channel
module nova1_det_mem_acta (input logic clk, input logic we, input logic [17:0] addr,
                           input logic [7:0] wdata, output logic [7:0] rdata);
    nova1_det_sram_sp #(.WIDTH(8), .DEPTH(153600), .AW(18)) u_ram (.*);
endmodule

module nova1_det_mem_actb (input logic clk, input logic we, input logic [17:0] addr,
                           input logic [7:0] wdata, output logic [7:0] rdata);
    nova1_det_sram_sp #(.WIDTH(8), .DEPTH(76800), .AW(18)) u_ram (.*);
endmodule

module nova1_det_mem_w (input logic clk, input logic we, input logic [12:0] addr,
                        input logic [127:0] wdata, output logic [127:0] rdata);
    nova1_det_sram_sp #(.WIDTH(128), .DEPTH(4465), .AW(13)) u_ram (.*);
endmodule

module nova1_det_mem_p (input logic clk, input logic we, input logic [7:0] addr,
                        input logic [63:0] wdata, output logic [63:0] rdata);
    nova1_det_sram_sp #(.WIDTH(64), .DEPTH(240), .AW(8)) u_ram (.*);
endmodule
