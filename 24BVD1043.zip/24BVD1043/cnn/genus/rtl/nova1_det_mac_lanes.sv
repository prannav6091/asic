// nova1_det_mac_lanes.sv
// 16 independent INT8 x INT8 -> INT32 multiply-accumulate lanes.
// Every lane multiplies the SAME activation by its own weight (one output
// channel per lane). Accumulators wrap modulo 2^32 (same as the Python model).
module nova1_det_mac_lanes #(
    parameter integer LANES = 16
) (
    input  logic                     clk,
    input  logic                     rst_n,
    input  logic                     load_bias,          // acc[l] <= bias[l]
    input  logic [LANES*32-1:0]      bias_vec,
    input  logic                     mac_en,             // acc[l] += act * w[l]
    input  logic signed [7:0]        act,
    input  logic [LANES*8-1:0]       w_vec,
    output logic [LANES*32-1:0]      acc_vec
);
    genvar l;
    generate
        for (l = 0; l < LANES; l = l + 1) begin : g_lane
            logic signed [31:0] acc;
            logic signed [7:0]  w;
            logic signed [15:0] p;
            assign w = w_vec[l*8 +: 8];
            assign p = act * w;
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n)          acc <= 32'sd0;
                else if (load_bias)  acc <= bias_vec[l*32 +: 32];
                else if (mac_en)     acc <= acc + {{16{p[15]}}, p};
            end
            assign acc_vec[l*32 +: 32] = acc;
        end
    endgenerate
endmodule
