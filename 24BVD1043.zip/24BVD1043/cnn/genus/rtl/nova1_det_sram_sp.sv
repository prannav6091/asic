// nova1_det_sram_sp.sv
// Generic single-port synchronous RAM (1-cycle read latency, no reset).
// Behavioural model for simulation. For synthesis this module is NOT read:
// each instance is left as a black box to be replaced by an SRAM/ROM macro
// from the target kit's memory compiler (see syn/README_SYN.md).
module nova1_det_sram_sp #(
    parameter integer WIDTH = 8,
    parameter integer DEPTH = 1024,
    parameter integer AW    = 10
) (
    input  logic             clk,
    input  logic             we,
    input  logic [AW-1:0]    addr,
    input  logic [WIDTH-1:0] wdata,
    output logic [WIDTH-1:0] rdata
);
    logic [WIDTH-1:0] mem [0:DEPTH-1];

    always @(posedge clk) begin
        if (we) begin
            if (addr < DEPTH) mem[addr] <= wdata;
        end
        else begin
            rdata <= (addr < DEPTH) ? mem[addr] : '0;
        end
    end
endmodule
