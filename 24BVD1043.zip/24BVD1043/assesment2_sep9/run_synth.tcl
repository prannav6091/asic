# Master Synthesis Script for Cadence Genus (Common UI / Stylus)
# Place and execute this script inside the 'fir_tech' directory

set ROOT_DIR [pwd]

# Define designs: { folder_name top_module verilog_file sdc_file }
set designs {
    {"fir"                "fir_4tap"             "fir_4tap.v"             "fir_4tap.sdc"}
    {"fir_area_optimized" "fir_4tap_shared_mult" "fir_4tap_shared_mult.v"  "fir_4tap_shared_mult.sdc"}
    {"fir_piplined"      "fir_4tap_pipelined"   "fir_4tap_pipelined.v"    "fir_4tap_pipelined.sdc"}
}

set corners {"slow" "typical" "fast"}
set techs   {"45nm" "90nm" "180nm"}

foreach design_info $designs {
    set dir_name   [lindex $design_info 0]
    set top_module [lindex $design_info 1]
    set hdl_file   [lindex $design_info 2]
    set sdc_file   [lindex $design_info 3]

    foreach corner $corners {
        foreach tech $techs {

            # Safely clear design and library state between iterations
            if {[get_db designs] ne ""} {
                delete_obj [get_db designs]
            }
            set_db library {}

            # Define and create output directory structure
            set run_dir "${ROOT_DIR}/${dir_name}/${corner}/${tech}"
            file mkdir "${run_dir}/output/netlist"
            file mkdir "${run_dir}/output/constraints"
            file mkdir "${run_dir}/output/reports"

            # Set search paths
            set_db init_lib_search_path "/home/install/FOUNDRY/digital/${tech}/dig/lib"
            set_db init_hdl_search_path "${ROOT_DIR}/${dir_name}"

            # Set timing library (Stylus UI method)
            set_db library "${corner}.lib"

            # Read and elaborate HDL
            read_hdl "${hdl_file}"
            elaborate ${top_module}

            # Apply SDC constraints to elaborated design
            read_sdc "${ROOT_DIR}/${dir_name}/${sdc_file}"

            # Set synthesis effort levels
            set_db syn_generic_effort medium
            set_db syn_map_effort     medium
            set_db syn_opt_effort     medium

            # Generic synthesis stage
            syn_generic
            write_hdl > "${run_dir}/output/netlist/${top_module}_generic.v"

            # Mapping stage
            syn_map
            write_hdl > "${run_dir}/output/netlist/${top_module}_mapped.v"

            # Optimization stage
            syn_opt
            write_hdl > "${run_dir}/output/netlist/${top_module}_opt.v"

            # Export timing constraints and analytical reports
            write_sdc > "${run_dir}/output/constraints/${top_module}_synth.sdc"

            report_timing > "${run_dir}/output/reports/${top_module}_timing.rpt"
            report_power  > "${run_dir}/output/reports/${top_module}_power.rpt"
            report_area   > "${run_dir}/output/reports/${top_module}_area.rpt"
            report_gates  > "${run_dir}/output/reports/${top_module}_gates.rpt"
            report_qor    > "${run_dir}/output/reports/${top_module}_qor.rpt"
        }
    }
}
