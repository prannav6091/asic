# 100MHz Clock (10.0ns period)
create_clock -name clk -period 10.0 [get_ports clk]

# Clock Uncertainty & Transitions
set_clock_uncertainty 0.2 [get_clocks clk]
set_clock_transition 0.1 [get_clocks clk]

# Input / Output Delay Constraints (2.0ns budget)
set_input_delay -clock clk 2.0 [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay -clock clk 2.0 [all_outputs]

# External Load Constraint
set_load 0.05 [all_outputs]
