# Cadence Genus(TM) Synthesis Solution, Version 21.14-s082_1, built Jun 23 2022 14:32:08

# Date: Tue Sep 08 11:46:01 2026
# Host: cad312vitcc.vit.ac.in (x86_64 w/Linux 4.18.0-553.150.1.el8_10.x86_64) (16cores*64cpus*2physical cpus*INTEL(R) XEON(R) GOLD 6526Y 38400KB)
# OS:   Red Hat Enterprise Linux release 8.10 (Ootpa)


      set TOP_MODULE fir_normal
      set WORK_DIR /home/vlsi37/24bvd1094/ppa_a
      set OUT_DIR /home/vlsi37/24bvd1094/ppa_a/output/180nm/slow

      set_db init_lib_search_path /home/install/FOUNDRY/digital/180nm/dig/lib
      set_db init_hdl_search_path ${WORK_DIR}

      read_libs slow.lib
      read_hdl {fir_normal.v}
      elaborate ${TOP_MODULE}

      read_sdc ${WORK_DIR}/constraints.sdc

      set_db syn_generic_effort medium
      set_db syn_map_effort medium
      set_db syn_opt_effort medium

      syn_generic
      syn_map
      syn_opt

      write_hdl > ${OUT_DIR}/netlist/${TOP_MODULE}_opt.v
      write_sdc > ${OUT_DIR}/constraints/${TOP_MODULE}_synth.sdc

      report_timing > ${OUT_DIR}/reports/timing.rpt
      report_power  > ${OUT_DIR}/reports/power.rpt
      report_area   > ${OUT_DIR}/reports/area.rpt
      report_gates  > ${OUT_DIR}/reports/gates.rpt
      report_qor    > ${OUT_DIR}/reports/qor.rpt
      exit
    
