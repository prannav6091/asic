#!/bin/bash

WORK_DIR="/home/vlsi37/24bvd1094/ppa_a"
TOP_MODULE="fir_normal"

TECH_NODES=("180nm" "90nm" "45nm")
CORNERS=("slow" "typical" "fast")

cd ${WORK_DIR}

for tech in "${TECH_NODES[@]}"; do
  for corner in "${CORNERS[@]}"; do
    echo "=========================================================================="
    echo " RUNNING SYNTHESIS: ${TOP_MODULE} | Node: ${tech} | Corner: ${corner}"
    echo "=========================================================================="

    OUT_DIR="${WORK_DIR}/output/${tech}/${corner}"
    mkdir -p "${OUT_DIR}/netlist" "${OUT_DIR}/constraints" "${OUT_DIR}/reports"

    genus -no_gui -batch -execute "
      set TOP_MODULE ${TOP_MODULE}
      set WORK_DIR ${WORK_DIR}
      set OUT_DIR ${OUT_DIR}

      set_db init_lib_search_path /home/install/FOUNDRY/digital/${tech}/dig/lib
      set_db init_hdl_search_path \${WORK_DIR}

      read_libs ${corner}.lib
      read_hdl {fir_normal.v}
      elaborate \${TOP_MODULE}

      read_sdc \${WORK_DIR}/constraints.sdc

      set_db syn_generic_effort medium
      set_db syn_map_effort medium
      set_db syn_opt_effort medium

      syn_generic
      syn_map
      syn_opt

      write_hdl > \${OUT_DIR}/netlist/\${TOP_MODULE}_opt.v
      write_sdc > \${OUT_DIR}/constraints/\${TOP_MODULE}_synth.sdc

      report_timing > \${OUT_DIR}/reports/timing.rpt
      report_power  > \${OUT_DIR}/reports/power.rpt
      report_area   > \${OUT_DIR}/reports/area.rpt
      report_gates  > \${OUT_DIR}/reports/gates.rpt
      report_qor    > \${OUT_DIR}/reports/qor.rpt
      exit
    "
  done
done

echo "=========================================================================="
echo " ALL 9 COMBINATIONS COMPLETED SUCCESSFULLY FOR ${TOP_MODULE}!"
echo "=========================================================================="
