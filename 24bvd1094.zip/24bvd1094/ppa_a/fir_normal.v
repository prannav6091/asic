module fir_normal (
    input wire clk,
    input wire rst,
    input wire signed [7:0] xin,
    output reg signed [15:0] yout
);

    // Filter Coefficients: H = [1, 2, 3, 4]
    parameter signed [7:0] H0 = 8'sd1;
    parameter signed [7:0] H1 = 8'sd2;
    parameter signed [7:0] H2 = 8'sd3;
    parameter signed [7:0] H3 = 8'sd4;

    // Shift Register Pipeline Stage Registers
    reg signed [7:0] x0, x1, x2, x3;

    // Intermediate Product Registers
    reg signed [15:0] p0, p1, p2, p3;

    // Pipeline Logic & Accumulation
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            x0   <= 8'sd0;
            x1   <= 8'sd0;
            x2   <= 8'sd0;
            x3   <= 8'sd0;
            p0   <= 16'sd0;
            p1   <= 16'sd0;
            p2   <= 16'sd0;
            p3   <= 16'sd0;
            yout <= 16'sd0;
        end else begin
            // Shift Delay Chain
            x0 <= xin;
            x1 <= x0;
            x2 <= x1;
            x3 <= x2;

            // Multiplication Stage
            p0 <= x0 * H0;
            p1 <= x1 * H1;
            p2 <= x2 * H2;
            p3 <= x3 * H3;

            // Output Accumulation Stage
            yout <= p0 + p1 + p2 + p3;
        end
    end

endmodule
