add_search_path /home/install/FOUNDRY/digital/45nm/dig/lib -library -both
read_library -liberty -both \
    /home/install/FOUNDRY/digital/45nm/dig/lib/fast.lib \
    /home/install/FOUNDRY/digital/45nm/dig/lib/fast.lib

