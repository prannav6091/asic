
//input ports
add mapped point clk clk -type PI PI
add mapped point rst rst -type PI PI
add mapped point xin[7] xin[7] -type PI PI
add mapped point xin[6] xin[6] -type PI PI
add mapped point xin[5] xin[5] -type PI PI
add mapped point xin[4] xin[4] -type PI PI
add mapped point xin[3] xin[3] -type PI PI
add mapped point xin[2] xin[2] -type PI PI
add mapped point xin[1] xin[1] -type PI PI
add mapped point xin[0] xin[0] -type PI PI

//output ports
add mapped point yout[15] yout[15] -type PO PO
add mapped point yout[14] yout[14] -type PO PO
add mapped point yout[13] yout[13] -type PO PO
add mapped point yout[12] yout[12] -type PO PO
add mapped point yout[11] yout[11] -type PO PO
add mapped point yout[10] yout[10] -type PO PO
add mapped point yout[9] yout[9] -type PO PO
add mapped point yout[8] yout[8] -type PO PO
add mapped point yout[7] yout[7] -type PO PO
add mapped point yout[6] yout[6] -type PO PO
add mapped point yout[5] yout[5] -type PO PO
add mapped point yout[4] yout[4] -type PO PO
add mapped point yout[3] yout[3] -type PO PO
add mapped point yout[2] yout[2] -type PO PO
add mapped point yout[1] yout[1] -type PO PO
add mapped point yout[0] yout[0] -type PO PO

//inout ports




//Sequential Pins
add mapped point p2[7]/q p2_reg[7]/Q -type DFF DFF
add mapped point p2[8]/q p2_reg[8]/Q -type DFF DFF
add mapped point p2[6]/q p2_reg[6]/Q -type DFF DFF
add mapped point p2[5]/q p2_reg[5]/Q -type DFF DFF
add mapped point p2[4]/q p2_reg[4]/Q -type DFF DFF
add mapped point p2[3]/q p2_reg[3]/Q -type DFF DFF
add mapped point p2[2]/q p2_reg[2]/Q -type DFF DFF
add mapped point p2[1]/q p2_reg[1]/Q -type DFF DFF
add mapped point p3[3]/q p3_reg[3]/Q -type DFF DFF
add mapped point p0[3]/q p0_reg[3]/Q -type DFF DFF
add mapped point p0[4]/q p0_reg[4]/Q -type DFF DFF
add mapped point p0[5]/q p0_reg[5]/Q -type DFF DFF
add mapped point p0[6]/q p0_reg[6]/Q -type DFF DFF
add mapped point p0[1]/q p0_reg[1]/Q -type DFF DFF
add mapped point p0[2]/q p0_reg[2]/Q -type DFF DFF
add mapped point p3[7]/q p3_reg[7]/Q -type DFF DFF
add mapped point p3[5]/q p3_reg[5]/Q -type DFF DFF
add mapped point p3[6]/q p3_reg[6]/Q -type DFF DFF
add mapped point p3[4]/q p3_reg[4]/Q -type DFF DFF
add mapped point p3[8]/q p3_reg[8]/Q -type DFF DFF
add mapped point p0[0]/q p0_reg[0]/Q -type DFF DFF
add mapped point p0[7]/q p0_reg[7]/Q -type DFF DFF
add mapped point yout[3]/q yout_reg[3]/Q -type DFF DFF
add mapped point x0[4]/q x0_reg[4]/Q -type DFF DFF
add mapped point x3[2]/q x3_reg[2]/Q -type DFF DFF
add mapped point x0[6]/q x0_reg[6]/Q -type DFF DFF
add mapped point p3[2]/q p3_reg[2]/Q -type DFF DFF
add mapped point x3[4]/q x3_reg[4]/Q -type DFF DFF
add mapped point x3[5]/q x3_reg[5]/Q -type DFF DFF
add mapped point x0[0]/q x0_reg[0]/Q -type DFF DFF
add mapped point x0[1]/q x0_reg[1]/Q -type DFF DFF
add mapped point p3[9]/q p3_reg[9]/Q -type DFF DFF
add mapped point x0[2]/q x0_reg[2]/Q -type DFF DFF
add mapped point yout[6]/q yout_reg[6]/Q -type DFF DFF
add mapped point x3[6]/q x3_reg[6]/Q -type DFF DFF
add mapped point x0[3]/q x0_reg[3]/Q -type DFF DFF
add mapped point yout[7]/q yout_reg[7]/Q -type DFF DFF
add mapped point x0[5]/q x0_reg[5]/Q -type DFF DFF
add mapped point yout[9]/q yout_reg[9]/Q -type DFF DFF
add mapped point yout[5]/q yout_reg[5]/Q -type DFF DFF
add mapped point p2[9]/q p2_reg[9]/Q -type DFF DFF
add mapped point p1[2]/q p1_reg[2]/Q -type DFF DFF
add mapped point yout[1]/q yout_reg[1]/Q -type DFF DFF
add mapped point yout[11]/q yout_reg[11]/Q -type DFF DFF
add mapped point yout[10]/q yout_reg[10]/Q -type DFF DFF
add mapped point yout[8]/q yout_reg[8]/Q -type DFF DFF
add mapped point x3[3]/q x3_reg[3]/Q -type DFF DFF
add mapped point yout[4]/q yout_reg[4]/Q -type DFF DFF
add mapped point yout[2]/q yout_reg[2]/Q -type DFF DFF
add mapped point x0[7]/q x0_reg[7]/Q -type DFF DFF
add mapped point x3[1]/q x3_reg[1]/Q -type DFF DFF
add mapped point yout[0]/q yout_reg[0]/Q -type DFF DFF
add mapped point p2[0]/q p2_reg[0]/Q -type DFF DFF
add mapped point p1[1]/q p1_reg[1]/Q -type DFF DFF
add mapped point p1[5]/q p1_reg[5]/Q -type DFF DFF
add mapped point p1[7]/q p1_reg[7]/Q -type DFF DFF
add mapped point p1[8]/q p1_reg[8]/Q -type DFF DFF
add mapped point p1[3]/q p1_reg[3]/Q -type DFF DFF
add mapped point p1[4]/q p1_reg[4]/Q -type DFF DFF
add mapped point p1[6]/q p1_reg[6]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
