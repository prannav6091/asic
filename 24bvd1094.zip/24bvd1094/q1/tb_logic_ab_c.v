
//`timescale 1ns/1ps

module tb_logic_ab_c;

reg a, b, c;
wire y;

logic_ab_c DUT (
    .a(a),
    .b(b),
    .c(c),
    .y(y)
);

initial begin
    $display("Time | a b c | y");
    $monitor("%4t | %b %b %b | %b", $time, a, b, c, y);

    a=0; b=0; c=0; #10;
    a=0; b=0; c=1; #10;
    a=0; b=1; c=0; #10;
    a=0; b=1; c=1; #10;
    a=1; b=0; c=0; #10;
    a=1; b=0; c=1; #10;
    a=1; b=1; c=0; #10;
    a=1; b=1; c=1; #10;

    $finish;
end

endmodule

