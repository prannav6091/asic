# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.14-s082_1 on Wed Oct 14 16:32:10 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design logic_ab_c

create_clock -name "CLK" -period 4.0 -waveform {0.0 2.0} 
set_clock_transition 0.1 [get_clocks CLK]
set_load -pin_load 0.05 [get_ports y]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks CLK] -add_delay 0.5 [get_ports a]
set_input_delay -clock [get_clocks CLK] -add_delay 0.5 [get_ports b]
set_input_delay -clock [get_clocks CLK] -add_delay 0.5 [get_ports c]
set_output_delay -clock [get_clocks CLK] -add_delay 0.5 [get_ports y]
set_max_fanout 8.000 [current_design]
set_max_transition 0.5 [current_design]
set_input_transition 0.1 [get_ports a]
set_input_transition 0.1 [get_ports b]
set_input_transition 0.1 [get_ports c]
set_wire_load_mode "enclosed"
set_clock_uncertainty -setup 0.2 [get_clocks CLK]
set_clock_uncertainty -hold 0.2 [get_clocks CLK]
