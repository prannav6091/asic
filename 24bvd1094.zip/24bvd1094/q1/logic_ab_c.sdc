
# Timing constraints for logic_ab_c
# Function: y = (a & b) | c
# Combinational circuit — virtual clock
# Target timing period: 4 ns

# Virtual clock (no physical clock port)
create_clock -name CLK -period 4.000

# Clock quality assumptions
set_clock_uncertainty 0.20 [get_clocks CLK]
set_clock_transition  0.10 [get_clocks CLK]

# External interface timing budgets
set_input_delay  0.50 -clock [get_clocks CLK] [get_ports {a b c}]
set_output_delay 0.50 -clock [get_clocks CLK] [get_ports y]

# Input transition and output loading
set_input_transition 0.10 [get_ports {a b c}]
set_load 0.05 [get_ports y]

# Design-rule limits
set_max_transition 0.50 [current_design]
set_max_fanout 8 [current_design]

