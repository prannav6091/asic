//`timescale 1ns / 1ps

module tb_pipeline_y_ab_c;

    // Inputs
    reg clk;
    reg rst;
    reg [15:0] a;
    reg [15:0] b;
    reg [15:0] c;

    // Output
    wire [31:0] y;

    // Instantiate the Unit Under Test (UUT)
    pipeline_y_ab_c uut (
        .clk(clk),
        .rst(rst),
        .a(a),
        .b(b),
        .c(c),
        .y(y)
    );

    // Clock generation: 10ns period (100 MHz)
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst = 1;
        a   = 16'd0;
        b   = 16'd0;
        c   = 16'd0;

        // Apply reset
        #20;
        rst = 0;
        #10;

        // Test Case 1: 3 * 4 + 5 = 17
        a = 16'd3;
        b = 16'd4;
        c = 16'd5;
        #10;

        // Test Case 2: 10 * 20 + 30 = 230
        a = 16'd10;
        b = 16'd20;
        c = 16'd30;
        #10;

        // Test Case 3: 100 * 5 + 50 = 550
        a = 16'd100;
        b = 16'd5;
        c = 16'd50;
        #10;

        // Hold inputs stable for pipeline to drain
        #30;
        
        $finish;
    end

    initial begin
        // Monitor signals for simulation waveform / console output
        $monitor("Time=%0t ns | rst=%b | a=%0d, b=%0d, c=%0d | y=%0d", 
                 $time, rst, a, b, c, y);
    end

endmodule
