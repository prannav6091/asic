if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name MAXDELAY\
   -timing\
    [list ${::IMEX::libVar}/mmmc/slow.lib]
create_library_set -name MINDELAY\
   -timing\
    [list ${::IMEX::libVar}/mmmc/fast.lib]
create_rc_corner -name default_rc_corner\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0
create_delay_corner -name MINTIME\
   -library_set MINDELAY
create_delay_corner -name MAXTIME\
   -library_set MAXDELAY
create_constraint_mode -name CONST\
   -sdc_files\
    [list /dev/null]
create_analysis_view -name BEST -constraint_mode CONST -delay_corner MINTIME
create_analysis_view -name WORST -constraint_mode CONST -delay_corner MAXTIME
set_analysis_view -setup [list WORST] -hold [list BEST]
