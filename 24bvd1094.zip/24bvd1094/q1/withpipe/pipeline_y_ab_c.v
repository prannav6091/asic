module pipeline_y_ab_c (
    input wire clk,
    input wire rst,
    input wire [15:0] a,
    input wire [15:0] b,
    input wire [15:0] c,
    output reg [31:0] y
);

    // Stage 1 internal registers
    reg [15:0] a_q, b_q, c_q1;
    reg [31:0] mult_q;
    
    // Stage 2 internal registers
    reg [31:0] c_q2;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            a_q    <= 16'd0;
            b_q    <= 16'd0;
            c_q1   <= 16'd0;
            mult_q <= 32'd0;
            c_q2   <= 32'd0;
            y      <= 32'd0;
        end else begin
            // Stage 1: Register inputs, compute multiplication, delay c
            a_q    <= a;
            b_q    <= b;
            mult_q <= a_q * b_q;
            c_q1   <= c;

            // Stage 2: Register delayed c and compute final addition
            c_q2   <= {16'd0, c_q1}; // Zero extend to match multiplication width
            y      <= mult_q + c_q2;
        end
    end

endmodule
