########################################################################
# Timing constraints for pipeline_y_ab_c
# Function: 2-stage pipelined MAC (y = ab + c)
# Target clock period: 8.0 ns (125 MHz)
########################################################################

# Real clock definition on the input clock port
create_clock -name clk -period 8.000 [get_ports clk]

# Clock quality assumptions
set_clock_uncertainty 0.20 [get_clocks clk]
set_clock_transition  0.10 [get_clocks clk]

# External interface timing budgets relative to the clock
set_input_delay  0.50 -clock [get_clocks clk] [get_ports {a b c rst}]
set_output_delay 0.50 -clock [get_clocks clk] [get_ports {y}]

# Input transition and output loading
set_input_transition 0.10 [get_ports {a b c rst}]
set_load 0.05 [get_ports y]

# Design-rule limits
set_max_transition 0.50 [current_design]
set_max_fanout 8 [current_design]
