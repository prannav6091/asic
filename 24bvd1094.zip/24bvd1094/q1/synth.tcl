
########################################################################
# Genus Synthesis: Logic AB_C
# Function: y = (a & b) | c
########################################################################

set TOP_MODULE "logic_ab_c"

# Project configuration
set PROJECT_DIR "/home/vlsi51/24BVD1084/expression_n"
set LIB_DIR "/home/install/FOUNDRY/digital/90nm/dig/lib"

set_db init_lib_search_path $LIB_DIR
set_db init_hdl_search_path $PROJECT_DIR

# Output directories
set OUTPUT_DIR "$PROJECT_DIR/output"

file mkdir "$OUTPUT_DIR/netlist"
file mkdir "$OUTPUT_DIR/constraints"
file mkdir "$OUTPUT_DIR/reports"

# Read technology library
read_libs slow.lib

# Read RTL (testbench is NOT synthesized)
read_hdl "$PROJECT_DIR/logic_ab_c.v"

# Elaborate design
elaborate $TOP_MODULE

# Read timing constraints
read_sdc "$PROJECT_DIR/logic_ab_c.sdc"

# Synthesis effort
set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium

# Generic synthesis
syn_generic
write_hdl > "$OUTPUT_DIR/netlist/${TOP_MODULE}_generic.v"

# Technology mapping
syn_map
write_hdl > "$OUTPUT_DIR/netlist/${TOP_MODULE}_mapped.v"

# Optimization
syn_opt
write_hdl > "$OUTPUT_DIR/netlist/${TOP_MODULE}_opt.v"

# Export synthesized constraints
write_sdc > "$OUTPUT_DIR/constraints/${TOP_MODULE}_synth.sdc"

# Reports
report_timing > "$OUTPUT_DIR/reports/${TOP_MODULE}_timing.rpt"
report_power  > "$OUTPUT_DIR/reports/${TOP_MODULE}_power.rpt"
report_area   > "$OUTPUT_DIR/reports/${TOP_MODULE}_area.rpt"
report_gates  > "$OUTPUT_DIR/reports/${TOP_MODULE}_gates.rpt"
report_qor    > "$OUTPUT_DIR/reports/${TOP_MODULE}_qor.rpt"

# GUI
gui_show

