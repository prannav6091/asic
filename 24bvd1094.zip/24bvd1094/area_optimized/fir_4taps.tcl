
set TOP_MODULE "fir_4tap_shared_mult"

set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
set_db init_hdl_search_path /home/vlsi37/24bvd1094/area_optimized


read_libs slow.lib
read_hdl {fir_4tap_shared_mult.v}
elaborate 
read_sdc fir_4tap_shared_mult.sdc

set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium
syn_generic
write_hdl > output_slowlib_slow/netlist/${TOP_MODULE}_genric.v
syn_map
write_hdl > output_slowlib_slow/netlist/${TOP_MODULE}_mapped.v
syn_opt
write_hdl > output_slowlib_slow/netlist/${TOP_MODULE}_opt.v

write_sdc > output_slowlib_slow/constraints/${TOP_MODULE}_synth.sdc

report_timing > output_slowlib_slow/reports/${TOP_MODULE}_timing.rpt
report_power > output_slowlib_slow/reports/${TOP_MODULE}_power.rpt
report_area > output_slowlib_slow/reports/${TOP_MODULE}_area.rpt
report_gates > output_slowlib_slow/reports/${TOP_MODULE}_gates.rpt
report_qor > output_slowlib_slow/reports/${TOP_MODULE}_qor.rpt

gui_show
