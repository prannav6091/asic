
//`timescale 1ns/1ps

module tb_logic_ab_c;

reg a, b, c;
integer i;
wire y;

logic_ab_c dut (
    .a(a),
    .b(b),
    .c(c),
    .y(y)
);

initial begin
    i = 0;

    for (i = 0; i < 8; i = i + 1) begin
        {a, b, c} = i;
        #10;
        $display("a=%b b=%b c=%b y=%b", a, b, c, y);
    end

    $finish;
end

endmodule

