
set TOP_MODULE logic_ab_c

set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
set_db init_hdl_search_path /home/vlsi37/24bvd1094/question/asic_ab_c

# Read libraries and RTL
read_libs slow.lib
read_hdl logic_ab_c.v
elaborate $TOP_MODULE

# Read timing constraints
read_sdc logic_ab_c.sdc

# Create output directories
file mkdir output/netlist
file mkdir output/reports
file mkdir output/constraints

# Stage 1: Generic synthesis
syn_generic
write_hdl > output/netlist/logic_ab_c_generic.v

# Stage 2: Technology mapping
syn_map
write_hdl > output/netlist/logic_ab_c_mapped.v

# Stage 3: Optimization
syn_opt
write_hdl > output/netlist/logic_ab_c_optimized.v

# Reports for final optimized design
report_timing > output/reports/timing.rpt
report_area  > output/reports/area.rpt
report_power > output/reports/power.rpt

# Export timing constraints
write_sdc > output/constraints/logic_ab_c_synth.sdc

gui_show


