module logic_ab_c (
    input a, b, c,
    output y
);

assign y = (a & b) | c;

endmodule
