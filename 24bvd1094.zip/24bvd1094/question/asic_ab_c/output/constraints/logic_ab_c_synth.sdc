# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.14-s082_1 on Sun Oct 11 15:13:01 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design logic_ab_c

create_clock -name "virtual_clk" -period 10.0 -waveform {0.0 5.0} 
set_load -pin_load 0.01 [get_ports y]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks virtual_clk] -add_delay 0.2 [get_ports a]
set_input_delay -clock [get_clocks virtual_clk] -add_delay 0.2 [get_ports b]
set_input_delay -clock [get_clocks virtual_clk] -add_delay 0.2 [get_ports c]
set_output_delay -clock [get_clocks virtual_clk] -add_delay 0.2 [get_ports y]
set_input_transition 0.05 [get_ports a]
set_input_transition 0.05 [get_ports b]
set_input_transition 0.05 [get_ports c]
set_wire_load_mode "enclosed"
