#######################################################
#                                                     
#  Innovus Command Logging File                     
#  Created on Sun Oct 11 15:16:32 2026                
#                                                     
#######################################################

#@(#)CDS: Innovus v21.15-s110_1 (64bit) 09/23/2022 13:08 (Linux 3.10.0-693.el7.x86_64)
#@(#)CDS: NanoRoute 21.15-s110_1 NR220912-2004/21_15-UB (database version 18.20.592) {superthreading v2.17}
#@(#)CDS: AAE 21.15-s039 (64bit) 09/23/2022 (Linux 3.10.0-693.el7.x86_64)
#@(#)CDS: CTE 21.15-s038_1 () Sep 20 2022 11:42:13 ( )
#@(#)CDS: SYNTECH 21.15-s012_1 () Sep  5 2022 10:25:51 ( )
#@(#)CDS: CPE v21.15-s076
#@(#)CDS: IQuantus/TQuantus 21.1.1-s867 (64bit) Sun Jun 26 22:12:54 PDT 2022 (Linux 3.10.0-693.el7.x86_64)

set_global _enable_mmmc_by_default_flow      $CTE::mmmc_default
suppressMessage ENCEXT-2799
getVersion
getVersion
getVersion
win
save_global Default.globals
set init_gnd_net VSS
set init_lef_file ../../../../install/FOUNDRY/digital/90nm/dig/lef/gsclib090_translated.lef
set init_design_settop 0
set init_verilog output/netlist/logic_ab_c_optimized.v
set init_mmmc_file Default.view
set init_pwr_net VDD
init_design
zoomBox -1.32200 -0.43500 5.66500 2.94300
zoomBox -1.57700 -0.79300 6.64300 3.18100
zoomBox -1.32200 -0.43500 5.66500 2.94300
zoomBox -1.10500 -0.13100 4.83400 2.74050
pan -0.42500 0.94600
selectObject IO_Pin a
deselectAll
selectObject IO_Pin y
deselectAll
getIoFlowFlag
setIoFlowFlag 0
floorPlan -site gsclib090site -r 0.699731903485 0.699732 8 8 8 8
uiSetTool select
getIoFlowFlag
fit
setIoFlowFlag 0
floorPlan -site gsclib090site -r 0.692307692308 0.692308 8.12 8.12 8.12 8.12
uiSetTool select
getIoFlowFlag
fit
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
setAddRingMode -ring_target default -extend_over_row 0 -ignore_rows 0 -avoid_short 0 -skip_crossing_trunks none -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size 1 -orthogonal_only true -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape }
addRing -nets {VDD VSS} -type core_rings -follow core -layer {top Metal9 bottom Metal9 left Metal8 right Metal8} -width {top 1.8 bottom 1.8 left 1.8 right 1.8} -spacing {top 0.5 bottom 0.5 left 0.5 right 0.5} -offset {top 1.8 bottom 1.8 left 1.8 right 1.8} -center 1 -threshold 0 -jog_distance 0 -snap_wire_center_to_grid None
setAddRingMode -ring_target default -extend_over_row 0 -ignore_rows 0 -avoid_short 0 -skip_crossing_trunks none -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size 1 -orthogonal_only true -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape }
addRing -nets {VDD VSS} -type core_rings -follow core -layer {top Metal9 bottom Metal9 left Metal8 right Metal8} -width {top 1.8 bottom 1.8 left 1.8 right 1.8} -spacing {top 0.5 bottom 0.5 left 0.5 right 0.5} -offset {top 1.8 bottom 1.8 left 1.8 right 1.8} -center 1 -threshold 0 -jog_distance 0 -snap_wire_center_to_grid None
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {VDD VSS} -layer Metal9 -direction horizontal -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from left -start_offset 1 -stop_offset 1 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {VDD VSS} -layer Metal9 -direction horizontal -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from left -start_offset 1 -stop_offset 1 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {VDD VSS} -layer Metal9 -direction horizontal -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from left -start_offset 1 -stop_offset 1 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {VDD VSS} -layer Metal8 -direction vertical -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from left -start_offset 1 -stop_offset 1 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {VDD VSS} -layer Metal8 -direction vertical -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from left -start_offset 1 -stop_offset 1 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setSrouteMode -viaConnectToShape { noshape }
sroute -connect { blockPin padPin padRing corePin floatingStripe } -layerChangeRange { Metal1(1) Metal9(9) } -blockPinTarget { nearestTarget } -padPinPortConnect { allPort oneGeom } -padPinTarget { nearestTarget } -corePinTarget { firstAfterRowEnd } -floatingStripeTarget { blockring padring ring stripe ringpin blockpin followpin } -allowJogging 1 -crossoverViaLayerRange { Metal1(1) Metal9(9) } -nets { VDD VSS } -allowLayerChange 1 -blockPin useLef -targetViaLayerRange { Metal1(1) Metal9(9) }
setSrouteMode -viaConnectToShape { noshape }
sroute -connect { blockPin padPin padRing corePin floatingStripe } -layerChangeRange { Metal1(1) Metal9(9) } -blockPinTarget { nearestTarget } -padPinPortConnect { allPort oneGeom } -padPinTarget { nearestTarget } -corePinTarget { firstAfterRowEnd } -floatingStripeTarget { blockring padring ring stripe ringpin blockpin followpin } -allowJogging 1 -crossoverViaLayerRange { Metal1(1) Metal9(9) } -nets { VDD VSS } -allowLayerChange 1 -blockPin useLef -targetViaLayerRange { Metal1(1) Metal9(9) }
setRouteMode -earlyGlobalHonorMsvRouteConstraint false -earlyGlobalRoutePartitionPinGuide true
setEndCapMode -reset
setEndCapMode -boundary_tap false
setNanoRouteMode -quiet -droutePostRouteSpreadWire 1
setNanoRouteMode -quiet -droutePostRouteWidenWireRule LEFDefaultRouteSpec_gpdk090
setNanoRouteMode -quiet -timingEngine {}
setUsefulSkewMode -noBoundary false -maxAllowedDelay 1
setPlaceMode -reset
setPlaceMode -congEffort auto -timingDriven 1 -clkGateAware 1 -powerDriven 0 -ignoreScan 1 -reorderScan 1 -ignoreSpare 0 -placeIOPins 1 -moduleAwareSpare 0 -preserveRouting 1 -rmAffectedRouting 0 -checkRoute 0 -swapEEQ 0
setRouteMode -earlyGlobalHonorMsvRouteConstraint false -earlyGlobalRoutePartitionPinGuide true
setEndCapMode -reset
setEndCapMode -boundary_tap false
setUsefulSkewMode -noBoundary false -maxAllowedDelay 1
setPlaceMode -fp false
place_design
setPlaceMode -fp false
place_design
zoomBox -2.82100 3.67900 23.51900 16.41350
zoomBox 3.44650 6.85800 17.19700 13.50600
zoomBox 4.45200 7.30800 16.14050 12.95900
zoomBox 5.30650 7.69050 15.24200 12.49400
zoomBox 6.65100 8.29250 13.82950 11.76300
zoomBox 7.17600 8.51900 13.27800 11.46900
zoomBox 8.83000 9.23250 11.53850 10.54200
zoomBox 9.01900 9.30750 11.32150 10.42050
zoomBox 9.17950 9.37100 11.13700 10.31750
zoomBox 9.43100 9.47100 10.84700 10.15550
zoomBox 9.52950 9.51000 10.73350 10.09200
zoomBox 9.43050 9.47050 10.84700 10.15550
zoomBox 9.31350 9.42400 10.98050 10.23000
zoomBox 9.17600 9.36950 11.13800 10.31800
zoomBox 9.01450 9.30550 11.32300 10.42150
zoomBox 8.60200 9.14200 11.79700 10.68650
zoomBox 8.34000 9.03750 12.09900 10.85500
zoomBox 8.03050 8.91500 12.45400 11.05350
zoomBox 7.71500 8.69500 12.91900 11.21100
zoomBox 6.90800 8.14050 14.11100 11.62300
zoomBox 5.79550 7.40400 15.76550 12.22400
zoomBox 4.26000 6.42150 18.06050 13.09350
zoomBox -2.92250 2.52700 28.18000 17.56400
zoomBox -5.21350 1.29900 31.37850 18.99000
zoomBox -11.07950 -1.84500 39.56750 22.64100
pan -5.54250 8.86900
getCTSMode -engine -quiet
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix logic_ab_c_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix logic_ab_c_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix logic_ab_c_preCTS -outDir timingReports
getCTSMode -engine -quiet
create_ccopt_clock_tree_spec
ctd_win -side none -id ctd_window
getCTSMode -engine -quiet
zoomBox -6.16300 2.09050 24.94050 17.12800
zoomBox -3.66600 3.11700 22.77200 15.89900
zoomBox 1.79300 5.36200 18.03000 13.21200
zoomBox 3.09650 5.89800 16.89800 12.57050
zoomBox 4.20400 6.35350 15.93600 12.02550
zoomBox 5.14600 6.74100 15.11800 11.56200
zoomBox 5.94650 7.07000 14.42300 11.16800
zoomBox 6.62700 7.34950 13.83200 10.83300
zoomBox 6.06350 7.07300 14.54100 11.17150
zoomBox 5.40150 6.74800 15.37500 11.57000
zoomBox 3.70550 5.91650 17.51050 12.59050
zoomBox 1.35900 4.76550 20.46600 14.00300
zoomBox 2.62750 5.38750 18.86850 13.23950
zoomBox 1.35900 4.76550 20.46600 14.00300
zoomBox -1.88900 3.17200 24.55700 15.95750
zoomBox -6.37250 0.96650 30.23100 18.66300
zoomBox -12.16350 -2.27100 38.49900 22.22250
getCTSMode -engine -quiet
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix logic_ab_c_postCTS -outDir timingReports
pan -6.48850 9.61850
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix logic_ab_c_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix logic_ab_c_postCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -hold -pathReports -slackReports -numPaths 50 -prefix logic_ab_c_postCTS -outDir timingReports
getCTSMode -engine -quiet
getMultiCpuUsage -localCpu
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
getCTSMode -engine -quiet
setAnalysisMode -cppr both -clockGatingCheck true -timeBorrowing true -useOutputPinCap true -sequentialConstProp false -timingSelfLoopsNoSkew false -enableMultipleDriveNet true -clkSrcPath true -warn true -usefulSkew false -analysisType onChipVariation -log true
setAnalysisMode -checkType hold
setNanoRouteMode -quiet -routeWithTimingDriven 1
setNanoRouteMode -quiet -routeWithEco 1
setNanoRouteMode -quiet -routeWithSiDriven 1
setNanoRouteMode -quiet -routeTopRoutingLayer 9
setNanoRouteMode -quiet -routeBottomRoutingLayer 1
setNanoRouteMode -quiet -drouteEndIteration 1
setNanoRouteMode -quiet -routeWithTimingDriven true
setNanoRouteMode -quiet -routeWithSiDriven true
routeDesign -globalDetail
setNanoRouteMode -quiet -routeWithTimingDriven true
setNanoRouteMode -quiet -routeWithSiDriven true
routeDesign -globalDetail
zoomBox -14.43400 -0.24200 28.62900 20.57750
zoomBox -10.84900 1.71550 25.75450 19.41200
zoomBox -7.80150 3.37950 23.31150 18.42150
zoomBox -5.21100 4.79400 21.23500 17.57950
zoomBox -10.84900 1.71550 25.75450 19.41200
zoomBox -18.65200 -2.54550 32.01050 21.94800
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -pathReports -drvReports -slackReports -numPaths 50 -prefix logic_ab_c_postRoute -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -pathReports -drvReports -slackReports -numPaths 50 -prefix logic_ab_c_postRoute -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -hold -pathReports -slackReports -numPaths 50 -prefix logic_ab_c_postRoute -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postRoute -hold -pathReports -slackReports -numPaths 50 -prefix logic_ab_c_postRoute -outDir timingReports
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
zoomBox -14.29700 -0.43900 28.76600 20.38050
zoomBox -10.59550 1.35150 26.00850 19.04800
zoomBox -4.77450 4.16700 21.67200 16.95300
zoomBox -2.50150 5.26650 19.97900 16.13500
zoomBox -0.56900 6.20100 18.53950 15.43950
zoomBox 1.07250 6.99550 17.31550 14.84850
zoomBox 2.46900 7.67100 16.27550 14.34600
zoomBox -2.50300 5.26600 19.97850 16.13500
zoomBox -7.45200 2.87150 23.66600 17.91600
zoomBox -10.59950 1.34900 26.01050 19.04850
zoomBox -14.30200 -0.44200 28.76850 20.38100
zoomBox -10.40150 0.87100 26.20850 18.57050
zoomBox -7.08600 1.98700 24.03250 17.03150
zoomBox -4.26800 2.93550 22.18300 15.72350
zoomBox -1.87250 3.74200 20.61050 14.61150
zoomBox 0.16350 4.42750 19.27400 13.66650
zoomBox 1.89400 5.01000 18.13800 12.86350
zoomBox 0.16300 4.42750 19.27400 13.66700
zoomBox -1.87300 3.74200 20.61050 14.61200
zoomBox -4.26900 2.93550 22.18300 15.72400
zoomBox -7.08700 1.98650 24.03300 17.03200
zoomBox -10.40300 0.87050 26.20900 18.57100
zoomBox -14.30350 -0.44250 28.76950 20.38150
verifyConnectivity -type all -error 1000 -warning 50
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
verify_drc -report logic_ab_c.drc.rpt
zoomBox -19.68300 -1.44350 30.99100 23.05550
zoomBox -26.01200 -2.62100 33.60450 26.20150
pan 2.68850 19.91350
zoomBox -16.20950 -3.51200 34.46450 20.98700
zoomBox -10.16250 -1.31350 32.91050 19.51050
pan -3.41850 8.97850
panCenter 22.18800 11.40350
pan -11.50000 -1.96500
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
zoomBox 0.61500 3.77400 23.10050 14.64500
zoomBox 2.61500 4.62400 21.72750 13.86400
zoomBox 7.88850 6.89350 19.62650 12.56850
zoomBox -1.17050 3.17150 21.31700 14.04350
zoomBox -4.41350 1.88050 22.04250 14.67100
zoomBox -12.70150 -1.42550 23.91650 16.27800
zoomBox -17.96300 -3.52750 25.11700 17.30000
pan 6.11400 17.51800
pan -0.23300 10.44550
ecoRoute
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
zoomBox -9.18700 0.55850 27.43100 18.26200
zoomBox -2.85750 4.84900 19.63150 15.72150
selectWire 2.0100 2.0100 3.8100 16.8400 8 VSS
zoomBox -1.55150 5.57300 17.56450 14.81500
zoomBox -0.44450 6.18850 15.80400 14.04400
zoomBox 1.29550 7.15600 13.03600 12.83200
zoomBox 2.55350 7.85500 11.03600 11.95600
zoomBox 3.04050 8.13050 10.25100 11.61650
zoomBox 1.97950 7.53050 11.95950 12.35550
zoomBox 1.30650 7.14900 13.04800 12.82550
zoomBox -1.51050 5.55150 17.60900 14.79500
zoomBox 5.95200 9.01800 13.16350 12.50450
zoomBox 6.56400 9.29500 12.69400 12.25850
zoomBox 7.08450 9.53050 12.29500 12.04950
zoomBox 7.52650 9.73050 11.95600 11.87200
zoomBox 7.90200 9.90050 11.66750 11.72100
zoomBox 8.22150 10.04500 11.42250 11.59250
zoomBox 8.49300 10.16800 11.21400 11.48350
zoomBox 8.72400 10.27200 11.03700 11.39050
zoomBox 8.92000 10.36100 10.88650 11.31150
zoomBox 8.49250 10.16750 11.21450 11.48350
zoomBox 7.90000 9.89900 11.66850 11.72100
zoomBox 7.08050 9.52800 12.29700 12.05000
zoomBox 6.55950 9.29200 12.69650 12.25900
zoomBox 5.94650 9.01450 13.16650 12.50500
zoomBox 5.22550 8.68800 13.71950 12.79450
zoomBox 8.72200 10.27100 11.03700 11.39000
pan -0.05700 1.30650
zoomBox 8.48800 9.89350 11.21150 11.21000
zoomBox 8.28000 9.73450 11.48400 11.28350
zoomBox 7.74700 9.32750 12.18150 11.47150
zoomBox 7.40750 9.06850 12.62500 11.59100
zoomBox 8.27950 9.73450 11.48350 11.28350
zoomBox 8.48750 9.89350 11.21100 11.21000
zoomBox 7.40700 9.06850 12.62450 11.59100
zoomBox 6.53950 8.40600 13.76050 11.89700
zoomBox 5.98800 7.98450 14.48300 12.09150
zoomBox 5.33850 7.48850 15.33300 12.32050
zoomBox 4.57450 6.90500 16.33350 12.59000
zoomBox 3.67550 6.21850 17.51000 12.90700
zoomBox 2.61850 5.42250 18.89450 13.29150
zoomBox 1.46050 4.65200 20.61000 13.91000
zoomBox 0.13350 3.81250 22.66250 14.70450
zoomBox -1.42750 2.88250 25.07700 15.69650
zoomBox -3.26400 1.78850 27.91750 16.86350
zoomBox -5.42450 0.50100 31.25950 18.23650
zoomBox -7.96700 -1.01350 35.19150 19.85200
zoomBox -10.95750 -2.79500 39.81700 21.75250
zoomBox -7.77450 -0.21200 35.38400 20.65350
zoomBox -10.95750 -2.80400 39.81700 21.74350
zoomBox -7.94850 -0.86250 35.21000 20.00300
zoomBox -5.39100 0.78750 31.29400 18.52350
zoomBox -3.21750 2.19050 27.96500 17.26600
zoomBox -1.36950 3.38300 25.13550 16.19700
zoomBox 0.20100 4.39650 22.73050 15.28850
pan 0.06750 1.25550
zoomBox 1.78400 2.54550 20.93450 11.80400
zoomBox 5.09850 4.92700 16.85950 10.61300
zoomBox 6.56250 5.97900 15.06000 10.08700
zoomBox 7.13450 6.38950 14.35700 9.88150
zoomBox 7.61900 6.73850 13.75900 9.70700
zoomBox 8.67950 7.50200 12.45100 9.32550
deselectAll
selectMarker 8.7000 7.9400 11.3100 8.3000 1 1 6
deselectAll
selectMarker 8.7000 7.9400 11.3100 8.3000 1 1 6
deselectAll
selectMarker 8.7000 7.9400 11.3100 8.3000 1 1 6
setLayerPreference violation -isVisible 1
violationBrowser -all -no_display_false -displayByLayer
violationBrowserClose
zoomBox 8.45550 7.39200 12.89350 9.53750
zoomBox 7.88350 7.10950 14.02650 10.07950
zoomBox 7.40150 6.89100 14.62900 10.38500
zoomBox 6.84150 6.56750 15.34450 10.67850
zoomBox 6.18500 6.18500 16.18900 11.02150
pan 0.63150 2.17200
zoomBox 7.72300 9.17650 14.95100 12.67100
zoomBox 8.07700 9.49650 14.22100 12.46700
zoomBox 8.37800 9.76850 13.60050 12.29350
zoomBox 8.63050 9.97600 13.07050 12.12250
deselectAll
selectMarker 8.7000 10.5500 11.3100 10.9100 1 1 6
setLayerPreference violation -isVisible 1
violationBrowser -all -no_display_false -displayByLayer
zoomBox 7.395 6.635 12.615 9.605
zoomBox 7.395 6.635 12.615 9.605
zoomBox -1.385 2.235 21.395 14.87
zoomBox 3.975 -0.805 16.005 19.655
zoomBox 7.395 9.245 12.615 12.215
zoomBox 7.395 6.635 12.615 9.605
zoomBox 7.395 9.245 12.615 12.215
zoomBox 7.395 6.635 12.615 9.605
deselectAll
selectMarker 8.7000 7.9400 11.3100 8.3000 1 1 6
zoomBox -1.385 2.235 21.395 14.87
zoomBox 7.395 6.635 12.615 9.605
zoomBox 7.47300 6.79750 12.69500 9.32200
zoomBox 4.67300 5.89450 14.67700 10.73100
zoomBox 3.57950 5.48700 15.34900 11.17700
zoomBox 2.29300 5.00700 16.13950 11.70150
zoomBox 4.67200 5.89400 14.67700 10.73100
zoomBox 5.60100 6.24050 14.10550 10.35200
zoomBox 6.39100 6.53500 13.62000 10.03000
zoomBox 7.07650 6.77150 13.22150 9.74250
zoomBox 7.66250 6.97000 12.88650 9.49550
zoomBox 8.18550 7.12350 12.62650 9.27050
zoomBox 7.65100 6.98150 12.87600 9.50750
zoomBox 6.28200 6.61800 13.51450 10.11450
zoomBox 5.41150 6.38650 13.92050 10.50050
zoomBox 4.38700 6.11450 14.39800 10.95450
zoomBox 3.18200 5.79450 14.96050 11.48900
zoomBox 1.76450 5.41800 15.62150 12.11750
zoomBox 0.09650 4.97500 16.39950 12.85700
zoomBox -1.86600 4.45400 17.31450 13.72700
zoomBox -0.18950 4.97800 16.11400 12.86000
zoomBox 1.21050 5.42450 15.06850 12.12450
zoomBox 2.40000 5.80450 14.18000 11.49950
zoomBox 3.41150 6.12700 13.42450 10.96800
zoomBox 4.27100 6.40150 12.78250 10.51650
zoomBox 5.00200 6.63500 12.23650 10.13250
zoomBox 5.62300 6.83350 11.77250 9.80650
zoomBox 4.74350 6.59000 11.97900 10.08800
zoomBox 3.71050 6.32200 12.22300 10.43750
pan 2.94850 2.88800
zoomBox 5.59750 6.22600 15.61250 11.06800
zoomBox 2.87950 5.27300 16.74100 11.97450
zoomBox 1.15100 4.66650 17.45900 12.55100
zoomBox -0.88300 3.95350 18.30350 13.22950
zoomBox -3.27550 3.11450 19.29700 14.02750
zoomBox -4.99100 2.24500 21.56550 15.08400
zoomBox -7.00950 1.22200 24.23400 16.32700
zoomBox -4.99150 2.24450 21.56550 15.08400
zoomBox -1.81900 3.85300 17.36900 13.12950
zoomBox -0.58000 4.48400 15.73000 12.36950
zoomBox 0.47300 5.02100 14.33700 11.72350
pan 1.50050 4.65600
zoomBox 5.48550 6.17750 14.00050 10.29400
zoomBox 3.33800 5.53600 15.12350 11.23400
zoomBox 1.97200 5.12850 15.83750 11.83200
zoomBox 0.36500 4.64900 16.67750 12.53550
zoomBox -1.52550 4.08450 17.66600 13.36300
pan -11.78800 4.98700
zoomBox -13.31350 3.46150 23.45350 21.23700
pan 5.92550 11.84500
zoomBox -7.38800 -4.60550 35.86750 16.30700
pan -1.84700 4.86350
fit
zoomBox 7.395 6.635 12.615 9.605
zoomBox 7.395 6.635 12.615 9.605
deselectAll
selectMarker 8.7000 7.9400 11.3100 8.3000 1 1 6
zoomBox 7.395 6.635 12.615 9.605
zoomBox 7.395 6.635 12.615 9.605
zoomBox 7.47150 6.89300 12.69300 9.41750
zoomBox 7.92800 7.11100 12.36700 9.25700
zoomBox 8.31600 7.29650 12.08900 9.12050
zoomBox 8.64550 7.45350 11.85250 9.00400
zoomBox 8.92500 7.56900 11.65100 8.88700
pan 0.19500 -1.33800
zoomBox 9.32750 7.62900 11.64500 8.74950
zoomBox 9.50450 7.66550 11.47450 8.61800
zoomBox 9.65500 7.69650 11.32950 8.50600
pan 0.14300 -1.87100
pan -0.09400 -1.99400
verifyConnectivity -type all -error 1000 -warning 50
violationBrowser -all -no_display_false -displayByLayer
dbSchema sWire
zoomBox 8.90300 6.68050 13.34450 8.82800
fit
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
violationBrowser -all -no_display_false -displayByLayer
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
violationBrowser -all -no_display_false -displayByLayer
zoomBox -8.06250 0.80600 28.39300 18.43100
zoomBox -5.19200 2.29200 25.79550 17.27350
zoomBox -0.67850 4.62850 21.71050 15.45300
zoomBox 1.08400 5.54100 20.11500 14.74200
zoomBox 3.85550 6.97600 17.60650 13.62400
zoomBox 5.85800 8.01300 15.79350 12.81650
zoomBox 6.64000 8.41800 15.08550 12.50100
zoomBox 7.30500 8.76250 14.48350 12.23300
zoomBox 7.87000 9.05500 13.97200 12.00500
zoomBox 8.75850 9.51550 13.16750 11.64700
zoomBox 9.10550 9.69500 12.85350 11.50700
zoomBox 9.36100 9.94000 12.54750 11.48050
pan -0.65450 0.79600
zoomBox 8.71650 10.02700 11.42500 11.33650
zoomBox 8.93950 10.16750 11.24250 11.28100
pan -0.03900 1.26650
zoomBox 9.09650 10.32000 11.05400 11.26650
zoomBox 7.52150 9.76950 12.71550 12.28050
zoomBox 7.07550 9.61350 13.18600 12.56750
zoomBox 6.55100 9.43000 13.74000 12.90550
zoomBox 4.35350 8.66100 16.05950 14.32050
zoomBox 3.34850 8.30900 17.12050 14.96750
zoomBox 2.16550 7.89550 18.36850 15.72900
zoomBox -0.86200 6.83650 21.56450 17.67900
fit
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
violationBrowser -all -no_display_false -displayByLayer
clearGlobalNets
globalNetConnect VDD -type pgpin -pin VDD -instanceBasename * -hierarchicalInstance {}
globalNetConnect VSS -type pgpin -pin VSS -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect VDD -type pgpin -pin VDD -instanceBasename * -hierarchicalInstance {}
globalNetConnect VSS -type pgpin -pin VSS -instanceBasename * -hierarchicalInstance {}
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
violationBrowser -all -no_display_false -displayByLayer
clearGlobalNets
globalNetConnect VDD -type pgpin -pin VDD -instanceBasename * -hierarchicalInstance {}
globalNetConnect VSS -type pgpin -pin VSS -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect VDD -type pgpin -pin VDD -instanceBasename * -hierarchicalInstance {}
globalNetConnect VSS -type pgpin -pin VSS -instanceBasename * -hierarchicalInstance {}
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
violationBrowser -all -no_display_false -displayByLayer
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postRoute
optDesign -postRoute -hold
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postRoute
optDesign -postRoute -hold
violationBrowser -all -no_display_false -displayByLayer
getCTSMode -engine -quiet
getCTSMode -engine -quiet
getCTSMode -engine -quiet
zoomBox -8.42600 1.00300 28.02950 18.62800
zoomBox -5.86450 2.65700 25.12250 17.63800
zoomBox -1.83650 5.25750 20.55200 16.08150
zoomBox 1.07350 7.13650 17.24950 14.95700
zoomBox -0.74800 6.71200 18.28300 15.91300
zoomBox -5.41250 5.62600 20.92950 18.36150
zoomBox -8.37900 4.93550 22.61200 19.91850
zoomBox -11.86900 4.12300 24.59200 21.75050
pan 4.51650 12.92250
zoomBox -9.71650 -1.52350 33.17900 19.21500
zoomBox -12.49750 -4.55500 37.96750 19.84300
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report logic_ab_c.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
violationBrowser -all -no_display_false -displayByLayer
pan -0.88050 9.88500
zoomBox -10.20100 -1.00150 32.69450 19.73700
zoomBox -5.21250 1.53200 25.78050 16.51600
zoomBox -7.50550 0.36750 28.95750 17.99600
zoomBox 3.04350 5.16100 19.22350 12.98350
selectMarker 4.3100 7.3750 15.7000 9.1750 -1 3 7
zoomBox -1.385 -1.385 21.395 20.235
zoomBox -1.385 1.68 21.395 14.87
zoomBox 1.42100 4.28800 18.17650 12.38850
zoomBox 2.77350 4.82750 17.01600 11.71300
zoomBox 3.92300 5.28550 16.02950 11.13850
zoomBox 4.90050 5.67550 15.19100 10.65050
zoomBox 6.07350 5.99350 14.82050 10.22250
zoomBox -0.95050 3.86300 18.76500 13.39450
zoomBox -7.32150 1.69300 24.78250 17.21400
zoomBox -10.23100 0.70500 27.53850 18.96500
zoomBox -13.52150 -0.64200 30.91300 20.84050
fit
fit
