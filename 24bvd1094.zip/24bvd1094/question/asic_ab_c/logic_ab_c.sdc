create_clock -name virtual_clk -period 10

set_input_delay 0.2 -clock virtual_clk [get_ports {a b c}]
set_output_delay 0.2 -clock virtual_clk [get_ports y]

set_input_transition 0.05 [get_ports {a b c}]
set_load 0.01 [get_ports y]
