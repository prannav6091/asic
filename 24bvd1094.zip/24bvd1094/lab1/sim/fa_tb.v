module fa_tb();

reg a_tb, b_tb, cin_tb;
wire sum_tb, cout_tb;

fa uut (
    .A(a_tb),
    .B(b_tb),
    .Cin(cin_tb),
    .Sum(sum_tb),
    .Cout(cout_tb)
);

initial begin
    $display("a b cin | sum cout");
    $monitor("%0t ns a=%0b b=%0b cin=%0b sum=%0b cout=%0b",
             $time, a_tb, b_tb, cin_tb, sum_tb, cout_tb);

    a_tb=0; b_tb=0; cin_tb=0; #10;
    a_tb=0; b_tb=0; cin_tb=1; #10;
    a_tb=0; b_tb=1; cin_tb=0; #10;
    a_tb=0; b_tb=1; cin_tb=1; #10;
    a_tb=1; b_tb=0; cin_tb=0; #10;
    a_tb=1; b_tb=0; cin_tb=1; #10;
    a_tb=1; b_tb=1; cin_tb=0; #10;
    a_tb=1; b_tb=1; cin_tb=1; #10;

    $finish;
end

endmodule
