# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.14-s082_1 on Mon Sep 07 19:24:18 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design seq_alu

create_clock -name "clk" -period 10.0 -waveform {0.0 5.0} [get_ports clk]
set_load -pin_load 0.05 [get_ports {result_out[4]}]
set_load -pin_load 0.05 [get_ports {result_out[3]}]
set_load -pin_load 0.05 [get_ports {result_out[2]}]
set_load -pin_load 0.05 [get_ports {result_out[1]}]
set_load -pin_load 0.05 [get_ports {result_out[0]}]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports reset]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {a_in[3]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {a_in[2]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {a_in[1]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {a_in[0]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {b_in[3]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {b_in[2]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {b_in[1]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {b_in[0]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {opcode[1]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {opcode[0]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {result_out[4]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {result_out[3]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {result_out[2]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {result_out[1]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports {result_out[0]}]
set_input_transition 0.1 [get_ports reset]
set_input_transition 0.1 [get_ports {a_in[3]}]
set_input_transition 0.1 [get_ports {a_in[2]}]
set_input_transition 0.1 [get_ports {a_in[1]}]
set_input_transition 0.1 [get_ports {a_in[0]}]
set_input_transition 0.1 [get_ports {b_in[3]}]
set_input_transition 0.1 [get_ports {b_in[2]}]
set_input_transition 0.1 [get_ports {b_in[1]}]
set_input_transition 0.1 [get_ports {b_in[0]}]
set_input_transition 0.1 [get_ports {opcode[1]}]
set_input_transition 0.1 [get_ports {opcode[0]}]
set_wire_load_mode "enclosed"
set_clock_uncertainty -setup 0.2 [get_clocks clk]
set_clock_uncertainty -hold 0.2 [get_clocks clk]
