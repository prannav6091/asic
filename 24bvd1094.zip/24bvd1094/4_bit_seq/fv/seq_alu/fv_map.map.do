
//input ports
add mapped point clk clk -type PI PI
add mapped point reset reset -type PI PI
add mapped point a_in[3] a_in[3] -type PI PI
add mapped point a_in[2] a_in[2] -type PI PI
add mapped point a_in[1] a_in[1] -type PI PI
add mapped point a_in[0] a_in[0] -type PI PI
add mapped point b_in[3] b_in[3] -type PI PI
add mapped point b_in[2] b_in[2] -type PI PI
add mapped point b_in[1] b_in[1] -type PI PI
add mapped point b_in[0] b_in[0] -type PI PI
add mapped point opcode[1] opcode[1] -type PI PI
add mapped point opcode[0] opcode[0] -type PI PI

//output ports
add mapped point result_out[4] result_out[4] -type PO PO
add mapped point result_out[3] result_out[3] -type PO PO
add mapped point result_out[2] result_out[2] -type PO PO
add mapped point result_out[1] result_out[1] -type PO PO
add mapped point result_out[0] result_out[0] -type PO PO

//inout ports




//Sequential Pins
add mapped point result_out[4]/q result_out_reg[4]/Q -type DFF DFF
add mapped point result_out[3]/q result_out_reg[3]/Q -type DFF DFF
add mapped point result_out[2]/q result_out_reg[2]/Q -type DFF DFF
add mapped point result_out[1]/q result_out_reg[1]/Q -type DFF DFF
add mapped point result_out[0]/q result_out_reg[0]/Q -type DFF DFF
add mapped point b_reg[0]/q b_reg_reg[0]/Q -type DFF DFF
add mapped point a_reg[3]/q a_reg_reg[3]/Q -type DFF DFF
add mapped point b_reg[1]/q b_reg_reg[1]/Q -type DFF DFF
add mapped point a_reg[2]/q a_reg_reg[2]/Q -type DFF DFF
add mapped point b_reg[3]/q b_reg_reg[3]/Q -type DFF DFF
add mapped point b_reg[2]/q b_reg_reg[2]/Q -type DFF DFF
add mapped point a_reg[1]/q a_reg_reg[1]/Q -type DFF DFF
add mapped point a_reg[0]/q a_reg_reg[0]/Q -type DFF DFF
add mapped point op_reg[0]/q op_reg_reg[0]/Q -type DFF DFF
add mapped point op_reg[1]/q op_reg_reg[1]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
