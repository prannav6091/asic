# Define real clock (e.g., 10ns period / 100MHz)
create_clock -name clk -period 10.0 [get_ports clk]

# Clock uncertainty / jitter
set_clock_uncertainty 0.2 [get_clocks clk]

# Input and Output Delays relative to clk
set_input_delay -max 2.0 -clock clk [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay -max 2.0 -clock clk [all_outputs]

# Input Transition & Output Load
set_input_transition 0.1 [remove_from_collection [all_inputs] [get_ports clk]]
set_load 0.05 [all_outputs]
