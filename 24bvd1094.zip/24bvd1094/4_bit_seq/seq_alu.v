module seq_alu (
    input wire clk,
    input wire reset,
    input wire [3:0] a_in,
    input wire [3:0] b_in,
    input wire [1:0] opcode,
    output reg [4:0] result_out
);

    reg [3:0] a_reg, b_reg;
    reg [1:0] op_reg;

    // Register inputs on rising clock edge
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            a_reg  <= 4'b0000;
            b_reg  <= 4'b0000;
            op_reg <= 2'b00;
        end else begin
            a_reg  <= a_in;
            b_reg  <= b_in;
            op_reg <= opcode;
        end
    end

    // Compute ALU result sequentially
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            result_out <= 5'b00000;
        end else begin
            case (op_reg)
                2'b00: result_out <= a_reg + b_reg;       // Addition
                2'b01: result_out <= a_reg - b_reg;       // Subtraction
                2'b10: result_out <= {1'b0, a_reg & b_reg}; // AND
                2'b11: result_out <= {1'b0, a_reg | b_reg}; // OR
                default: result_out <= 5'b00000;
            endcase
        end
    end

endmodule
