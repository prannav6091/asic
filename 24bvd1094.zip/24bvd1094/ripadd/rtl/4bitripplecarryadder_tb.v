module tb_ripple_carry_adder_4bit;

    reg  [3:0] A;
    reg  [3:0] B;
    reg        Cin;
    wire [3:0] Sum;
    wire       Cout;

    ripple_carry_adder_4bit uut (
        .A(A),
        .B(B),
        .Cin(Cin),
        .Sum(Sum),
        .Cout(Cout)
    );

    initial begin
        $monitor("Time=%0t | A=%b B=%b Cin=%b | Cout=%b Sum=%b", 
                 $time, A, B, Cin, Cout, Sum);

        // Test 1
        A = 4'b0010; B = 4'b0100; Cin = 1'b0; #10;

        // Test 2
        A = 4'b0101; B = 4'b0011; Cin = 1'b1; #10;

        // Test 3
        A = 4'b1010; B = 4'b0110; Cin = 1'b0; #10;

        // Test 4
        A = 4'b1111; B = 4'b1111; Cin = 1'b1; #10;

        $finish;
    end

endmodule
