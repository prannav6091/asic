set TOP_MODULE "seq_alu"

# Set search paths
set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
set_db init_hdl_search_path /home/vlsi51/24BVD1094/seq_alu

# Read timing libraries and design files
read_libs slow.lib
read_hdl {seq_alu.v}
elaborate ${TOP_MODULE}

# Read timing constraints
read_sdc seq_alu.sdc

# Synthesis Settings
set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium

# -------------------------------------------------------------
# Stage 1: Generic Synthesis
# -------------------------------------------------------------
syn_generic
write_hdl > output/netlist/${TOP_MODULE}_generic.v

report_timing > output/reports/${TOP_MODULE}_generic_timing.rpt
report_power  > output/reports/${TOP_MODULE}_generic_power.rpt
report_area   > output/reports/${TOP_MODULE}_generic_area.rpt
report_gates  > output/reports/${TOP_MODULE}_generic_gates.rpt
report_qor    > output/reports/${TOP_MODULE}_generic_qor.rpt

# -------------------------------------------------------------
# Stage 2: Mapped Synthesis
# -------------------------------------------------------------
syn_map
write_hdl > output/netlist/${TOP_MODULE}_mapped.v

report_timing > output/reports/${TOP_MODULE}_mapped_timing.rpt
report_power  > output/reports/${TOP_MODULE}_mapped_power.rpt
report_area   > output/reports/${TOP_MODULE}_mapped_area.rpt
report_gates  > output/reports/${TOP_MODULE}_mapped_gates.rpt
report_qor    > output/reports/${TOP_MODULE}_mapped_qor.rpt

# -------------------------------------------------------------
# Stage 3: Optimized Synthesis
# -------------------------------------------------------------
syn_opt
write_hdl > output/netlist/${TOP_MODULE}_opt.v

report_timing > output/reports/${TOP_MODULE}_opt_timing.rpt
report_power  > output/reports/${TOP_MODULE}_opt_power.rpt
report_area   > output/reports/${TOP_MODULE}_opt_area.rpt
report_gates  > output/reports/${TOP_MODULE}_opt_gates.rpt
report_qor    > output/reports/${TOP_MODULE}_opt_qor.rpt

# Export final constraints
write_sdc > output/constraints/${TOP_MODULE}_synth.sdc

gui_show
