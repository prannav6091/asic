// 1-bit Full Adder (Gate-Level / Structural Modeling)
module full_adder (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    wire w1, w2, w3;

    xor u1 (w1, a, b);
    xor u2 (sum, w1, cin);

    and u3 (w2, a, b);
    and u4 (w3, w1, cin);
    or  u5 (cout, w2, w3);
endmodule

// 4-bit Ripple Carry Adder (Structural Modeling)
module rca_4bit (
    input  wire [3:0] A,
    input  wire [3:0] B,
    input  wire       Cin,
    output wire [3:0] Sum,
    output wire       Cout
);
    wire [3:0] c;

    // Instantiate 4 Full Adders
    full_adder fa0 (.a(A[0]), .b(B[0]), .cin(Cin),  .sum(Sum[0]), .cout(c[0]));
    full_adder fa1 (.a(A[1]), .b(B[1]), .cin(c[0]), .sum(Sum[1]), .cout(c[1]));
    full_adder fa2 (.a(A[2]), .b(B[2]), .cin(c[1]), .sum(Sum[2]), .cout(c[2]));
    full_adder fa3 (.a(A[3]), .b(B[3]), .cin(c[2]), .sum(Sum[3]), .cout(Cout));

endmodule
