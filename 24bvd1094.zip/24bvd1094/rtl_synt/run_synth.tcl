# 1. Top Module and Directory Setup
set TOP_MODULE "rca_4bit"
set WORK_DIR "/home/vlsi37/24bvd1094/rtl_synt"

# Create output subdirectories if they don't exist
file mkdir ${WORK_DIR}/output/netlist
file mkdir ${WORK_DIR}/output/constrints
file mkdir ${WORK_DIR}/output/reports

# 2. Search Paths and Library Loading
set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
set_db init_hdl_search_path ${WORK_DIR}

read_libs slow.lib

# 3. Read HDL and Elaborate
read_hdl {rca_4bit.v}
elaborate ${TOP_MODULE}

# 4. Read SDC Constraints
read_sdc ${WORK_DIR}/constraints.sdc

# Set Synthesis Effort
set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium

# ------------------------------------------------------------------
# STAGE 1: Generic Synthesis
# ------------------------------------------------------------------
syn_generic

write_hdl > ${WORK_DIR}/output/netlist/${TOP_MODULE}_generic.v
report_timing > ${WORK_DIR}/output/reports/${TOP_MODULE}_generic_timing.rpt
report_power  > ${WORK_DIR}/output/reports/${TOP_MODULE}_generic_power.rpt
report_area   > ${WORK_DIR}/output/reports/${TOP_MODULE}_generic_area.rpt
report_gates  > ${WORK_DIR}/output/reports/${TOP_MODULE}_generic_gates.rpt
report_qor    > ${WORK_DIR}/output/reports/${TOP_MODULE}_generic_qor.rpt

# ------------------------------------------------------------------
# STAGE 2: Mapped Synthesis
# ------------------------------------------------------------------
syn_map

write_hdl > ${WORK_DIR}/output/netlist/${TOP_MODULE}_mapped.v
report_timing > ${WORK_DIR}/output/reports/${TOP_MODULE}_mapped_timing.rpt
report_power  > ${WORK_DIR}/output/reports/${TOP_MODULE}_mapped_power.rpt
report_area   > ${WORK_DIR}/output/reports/${TOP_MODULE}_mapped_area.rpt
report_gates  > ${WORK_DIR}/output/reports/${TOP_MODULE}_mapped_gates.rpt
report_qor    > ${WORK_DIR}/output/reports/${TOP_MODULE}_mapped_qor.rpt

# ------------------------------------------------------------------
# STAGE 3: Optimized Synthesis
# ------------------------------------------------------------------
syn_opt

write_hdl > ${WORK_DIR}/output/netlist/${TOP_MODULE}_opt.v
write_sdc > ${WORK_DIR}/output/constrints/${TOP_MODULE}_synth.sdc

report_timing > ${WORK_DIR}/output/reports/${TOP_MODULE}_opt_timing.rpt
report_power  > ${WORK_DIR}/output/reports/${TOP_MODULE}_opt_power.rpt
report_area   > ${WORK_DIR}/output/reports/${TOP_MODULE}_opt_area.rpt
report_gates  > ${WORK_DIR}/output/reports/${TOP_MODULE}_opt_gates.rpt
report_qor    > ${WORK_DIR}/output/reports/${TOP_MODULE}_opt_qor.rpt

puts "Synthesis completed successfully for ${TOP_MODULE}!"
