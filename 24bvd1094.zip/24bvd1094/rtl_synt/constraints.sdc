
create_clock -name vclk -period 10.0


set_input_delay -max 2.0 -clock vclk [get_ports {A[*] B[*] Cin}]

# Define Output Delays for all outputs
set_output_delay -max 2.0 -clock vclk [get_ports {Sum[*] Cout}]

# Define Input Transition / Slew
set_input_transition 0.1 [get_ports {A[*] B[*] Cin}]

# Define Output Load (adjust technology library load unit if needed, e.g., 0.05 pF)
set_load 0.05 [get_ports {Sum[*] Cout}]
