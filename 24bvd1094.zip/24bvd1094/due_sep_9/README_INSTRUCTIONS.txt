================================================================================
CADENCE INNOVUS ASIC PHYSICAL DESIGN FLOW INSTRUCTIONS
================================================================================

This directory contains modular TCL scripts to perform the complete ASIC physical 
design flow for a 4-Tap FIR Filter under a 90 nm slow-corner standard-cell library.

DIRECTORY SETUP BEFORE RUNNING:
--------------------------------
Ensure your working folder has the following inputs/paths:
1. netlists/fir_normal_synth.v  -> Synthesized Verilog netlist
2. constraints/fir_4tap.sdc     -> SDC timing constraints
3. tech/lef/tech_90nm.lef       -> Technology LEF file
4. tech/lef/stdcells_90nm.lef   -> Standard-cell LEF file
5. tech/lib/slow_corner_90nm.lib -> 90nm slow-corner timing library (.lib)

HOW TO EXECUTE THE FLOW:
------------------------
Method 1: Interactive GUI Execution
  1. Open terminal in the directory where these .tcl files are saved.
  2. Launch Innovus GUI:
        innovus
  3. In the Innovus console, execute:
        source run_normal_fir.tcl

Method 2: Batch Mode (Non-interactive)
  1. Run directly from terminal:
        innovus -files run_normal_fir.tcl -log innovus_run.log

STAGE BREAKDOWN:
----------------
- 01_init.tcl      : MMMC setup, loading LEFs, netlist, SDC, and library files.
- 02_floorplan.tcl : Core size allocation, power rings (M4/M5), power stripes, and sroute.
- 03_place_opt.tcl : Standard cell placement and pre-CTS timing check.
- 04_cts.tcl       : Clock tree generation (CCOpt) and post-CTS timing/hold optimization.
- 05_route.tcl     : NanoRoute execution and post-route timing closure.
- 06_signoff.tcl   : Verification (verify_drc, verifyConnectivity) and Area/Timing/Power reports.

OUTPUTS GENERATED:
------------------
- reports/normal_fir/final/ : Contains area.txt, power.txt, timing_setup, timing_hold, and DRC logs.
================================================================================
