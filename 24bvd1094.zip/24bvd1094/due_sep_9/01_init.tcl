# ==============================================================================
# Step 1: Design Import and Multi-Mode Multi-Corner (MMMC) Setup
# ==============================================================================

set NETLIST     "../lab5/output/netlist/fir_4tap_mapped.v"
set TOP_MODULE  "fir_4tap"
set SDC_FILE    "../lab5/output/constraints/fir_4tap_synth.sdc"

set TECH_LEF    "/home/vlsi37/.local/share/Trash/files/digital/90nm/dig/lef/gsclib090_tech.lef"
set CELL_LEF    "/home/vlsi37/.local/share/Trash/files/digital/90nm/dig/lef/gsclib090_macro.lef"
set LIB_SLOW    "/home/vlsi37/.local/share/Trash/files/digital/90nm/dig/lib/slow.lib"

set init_gnd_net VSS
set init_vdd_net VDD
set init_top_cell $TOP_MODULE
set init_verilog $NETLIST
set init_lef_file [list $TECH_LEF $CELL_LEF]
set init_mmmc_file "mmmc_setup.tcl"

# Write MMMC configuration
set mmmc_fd [open "mmmc_setup.tcl" w]
puts $mmmc_fd "create_library_set -name slow_lib -timing \[list $LIB_SLOW\]"
puts $mmmc_fd "create_rc_corner -name default_rc -qx_tech_file {}"
puts $mmmc_fd "create_delay_corner -name slow_corner -library_set slow_lib -rc_corner default_rc"
puts $mmmc_fd "create_constraint_mode -name functional_mode -sdc_files \[list $SDC_FILE\]"
puts $mmmc_fd "create_analysis_view -name setup_analysis -delay_corner slow_corner -constraint_mode functional_mode"
puts $mmmc_fd "set_analysis_view -setup \[list setup_analysis\] -hold \[list setup_analysis\]"
close $mmmc_fd

# Run Innovus Initialization
init_design
puts "\[PD-FLOW\] Step 1: Design Initialization Completed Successfully."
