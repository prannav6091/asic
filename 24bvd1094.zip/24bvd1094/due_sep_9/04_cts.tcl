# ==============================================================================
# Step 4: Clock Tree Synthesis (CTS) & Post-CTS Optimization
# ==============================================================================

# Generate CCOpt Spec and Run Clock Tree Synthesis
create_ccopt_clock_tree_spec
ccopt_design

# Post-CTS Setup & Hold Optimization
optDesign -postCTS
optDesign -postCTS -hold

# Check Post-CTS Timing
file mkdir reports/normal_fir/post_cts
timeDesign -postCTS -outDir reports/normal_fir/post_cts
timeDesign -postCTS -hold -outDir reports/normal_fir/post_cts

puts "\[PD-FLOW\] Step 4: Clock Tree Synthesis & Post-CTS Optimization Completed."
