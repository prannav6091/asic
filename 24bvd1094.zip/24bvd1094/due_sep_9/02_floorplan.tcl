# ==============================================================================
# Step 2: Floorplanning & Power Planning
# ==============================================================================

# Initialize Floorplan (65% core utilization, 10um core-to-io margin)
floorPlan -r 1.0 0.65 10 10 10 10

# Global PG Pin Connections
globalNetConnect VDD -type pgpin -pin VDD -inst * -override
globalNetConnect VSS -type pgpin -pin VSS -inst * -override

# Build Power Rings around Core
addRing -nets {VDD VSS} \
        -type core_rings \
        -follow core \
        -layer {top Metal5 bottom Metal5 left Metal4 right Metal4} \
        -width 2 \
        -spacing 1 \
        -offset 1

# Add Vertical Power Stripes
addStripe -nets {VDD VSS} \
          -layer Metal4 \
          -direction vertical \
          -width 1.5 \
          -spacing 1 \
          -set_to_set_distance 20 \
          -start 10

# Special Route for Standard Cell Rails
sroute -connect { blockPin padPin padRing corePin floatingStripe } \
       -layerChangeRange { Metal1 Metal5 } \
       -targetViaLayerRange { Metal1 Metal5 }

puts "\[PD-FLOW\] Step 2: Floorplanning & Power Planning Completed."
