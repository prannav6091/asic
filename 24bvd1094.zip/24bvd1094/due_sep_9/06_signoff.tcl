# ==============================================================================
# Step 6: Sign-off Physical Verification & Report Extraction
# ==============================================================================

file mkdir reports/normal_fir/final

# 1. DRC & Connectivity Sign-off Checks
verify_drc -limit 1000 -outDir reports/normal_fir/final
verifyConnectivity -type all -error 1000 -outDir reports/normal_fir/final

# 2. Setup & Hold Timing Verification
timeDesign -postRoute -outDir reports/normal_fir/final/timing_setup
timeDesign -postRoute -hold -outDir reports/normal_fir/final/timing_hold

report_timing -max_paths 1 -path_type full_clock > reports/normal_fir/final/critical_path_setup.txt
report_timing -early -max_paths 1 -path_type full_clock > reports/normal_fir/final/critical_path_hold.txt

# 3. Area Sign-off Report
report_area > reports/normal_fir/final/area.txt

# 4. Power Sign-off Report
report_power -outfile reports/normal_fir/final/power.txt

puts "\[PD-FLOW\] Step 6: Sign-off Verification and Reports Generated."
