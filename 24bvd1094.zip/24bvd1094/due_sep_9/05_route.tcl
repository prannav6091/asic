# ==============================================================================
# Step 5: Routing & Post-Route Timing Optimization
# ==============================================================================

# NanoRoute Execution
setNanoRouteMode -quiet -routeWithTimingDriven true
setNanoRouteMode -quiet -routeWithSiDriven false
routeDesign

# Post-Route Setup & Hold Optimization
optDesign -postRoute
optDesign -postRoute -hold

# Save Intermediate Database
file mkdir saved_designs
saveDesign saved_designs/normal_fir_routed.enc

puts "\[PD-FLOW\] Step 5: Routing & Post-Route Optimization Completed."
