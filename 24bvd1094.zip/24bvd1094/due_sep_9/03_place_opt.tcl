# ==============================================================================
# Step 3: Standard Cell Placement & Pre-CTS Optimization
# ==============================================================================

# Standard Cell Placement
setPlaceMode -fp false
place_design

# Pre-CTS Timing & DRC Optimization
setOptMode -fixCap true -fixTran true -setupTargetSlack 0.0
optDesign -preCTS

# Check Early Timing
file mkdir reports/normal_fir/pre_cts
timeDesign -preCTS -outDir reports/normal_fir/pre_cts

puts "\[PD-FLOW\] Step 3: Placement & Pre-CTS Optimization Completed."
