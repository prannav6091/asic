# ==============================================================================
# Cadence Innovus Automation Master Script
# Design: Normal 4-Tap FIR Filter (90 nm Slow Corner)
# Flow Stage: Complete Physical Design (Import to Sign-off)
# ==============================================================================

puts "========================================================================"
puts " STARTING PHYSICAL DESIGN FLOW: Normal 4-Tap FIR Filter"
puts "========================================================================"

# Step 1: Design Import & Initialization
source 01_init.tcl

# Step 2: Floorplanning & Power Planning
source 02_floorplan.tcl

# Step 3: Standard Cell Placement & Pre-CTS Optimization
source 03_place_opt.tcl

# Step 4: Clock Tree Synthesis (CTS) & Post-CTS Optimization
source 04_cts.tcl

# Step 5: Routing & Post-Route Optimization
source 05_route.tcl

# Step 6: Final Sign-off & Verification Reports
source 06_signoff.tcl

puts "========================================================================"
puts " PHYSICAL DESIGN FLOW COMPLETED SUCCESSFULLY FOR NORMAL FIR FILTER"
puts "========================================================================"
