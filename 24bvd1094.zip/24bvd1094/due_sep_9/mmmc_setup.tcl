create_library_set -name slow_lib -timing [list /home/vlsi37/.local/share/Trash/files/digital/90nm/dig/lib/slow.lib]
create_rc_corner -name default_rc -qx_tech_file {}
create_delay_corner -name slow_corner -library_set slow_lib -rc_corner default_rc
create_constraint_mode -name functional_mode -sdc_files [list ../lab5/output/constraints/fir_4tap_synth.sdc]
create_analysis_view -name setup_analysis -delay_corner slow_corner -constraint_mode functional_mode
set_analysis_view -setup [list setup_analysis] -hold [list setup_analysis]
