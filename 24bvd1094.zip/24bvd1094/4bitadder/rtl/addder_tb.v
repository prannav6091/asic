
module tb_adder;

    reg [3:0] A;
    reg [3:0] B;
    reg Cin;

    wire [3:0] Y;
    wire Cout;

    // Instantiate DUT
    adder uut (
        .A(A),
        .B(B),
        .Cin(Cin),
        .Y(Y),
        .Cout(Cout)
    );

    initial begin
        $display("Time\tA\tB\tCin\tCout\tY");
        $monitor("%0t\t%b\t%b\t%b\t%b\t%b",
                 $time, A, B, Cin, Cout, Y);

        A = 4'b0000; B = 4'b0000; Cin = 0; #10;
        A = 4'b0001; B = 4'b0010; Cin = 0; #10;
        A = 4'b0011; B = 4'b0101; Cin = 0; #10;
        A = 4'b0111; B = 4'b0001; Cin = 1; #10;
        A = 4'b1111; B = 4'b0001; Cin = 0; #10;
        A = 4'b1010; B = 4'b0101; Cin = 1; #10;
        A = 4'b1111; B = 4'b1111; Cin = 1; #10;

        $finish;
    end

endmodule
