module tb_toggle_less;
reg clk, d;
wire q;

toggle_cov dut(
    .clk(clk),
    .d(d),
    .q(q)
);

// Clock generation: 10ns period
always #5 clk = ~clk;

initial begin
    // 1. Initialize clock and data low at time 0
    clk = 0;
    d   = 0;

    // 2. Wait for clock edges to clear any initial X states on 'q'
    @(posedge clk);
    #1; // Wait slightly past clock edge to settle q = 0 cleanly

    // 3. Drive d = 1 (0 -> 1 transition on d)
    d = 1;
    @(posedge clk); 
    #1; // q transitions 0 -> 1 cleanly

    // 4. Drive d = 0 (1 -> 0 transition on d)
    d = 0;
    @(posedge clk);
    #1; // q transitions 1 -> 0 cleanly

    // 5. Allow additional clock cycles for coverage tools to record final values
    #20;
    $finish;
end

endmodule
