//--------------------------------------
// Datapath
//--------------------------------------
module datapath(
    input clk,
    input rst,
    input load,
    input execute,
    input [1:0] sel,
    input [3:0] A,
    input [3:0] B,
    output reg [7:0] Y
);

reg [3:0] regA;
reg [3:0] regB;

always @(posedge clk or posedge rst) begin
    if(rst) begin
        regA <= 4'd0;
        regB <= 4'd0;
        Y <= 8'd0;
    end
    else begin

        if(load) begin
            regA <= A;
            regB <= B;
        end

        if(execute) begin
            case(sel)

                // Addition
                2'b00:
                    Y <= regA + regB;

                // Subtraction
                2'b01:
                    Y <= regA - regB;

                // Multiplication
                2'b10:
                    Y <= regA * regB;

                // Division
                2'b11:
                begin
                    if(regB != 0)
                        Y <= regA / regB;
                    else
                        Y <= 8'd0;
                end

                default:
                    Y <= 8'd0;

            endcase
        end

    end
end

endmodule
