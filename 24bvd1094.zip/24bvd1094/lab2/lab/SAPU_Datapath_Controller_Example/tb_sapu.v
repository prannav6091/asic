

module tb_sapu;

reg clk;
reg rst;
reg start;
reg [1:0] sel;
reg [3:0] A;
reg [3:0] B;

wire [7:0] Y;
wire done;

sapu dut(
    .clk(clk),
    .rst(rst),
    .start(start),
    .sel(sel),
    .A(A),
    .B(B),
    .Y(Y),
    .done(done)
);

always #5 clk = ~clk;

task execute_operation;
input [3:0] a;
input [3:0] b;
input [1:0] operation;
begin

    @(posedge clk);
    A = a;
    B = b;
    sel = operation;
    start = 1;

    @(posedge clk);
    start = 0;

    wait(done);

    @(posedge clk);

end
endtask

initial begin

    clk = 0;
    rst = 1;
    start = 0;
    sel = 0;
    A = 0;
    B = 0;

    repeat(2) @(posedge clk);
    rst = 0;

    //-------------------------
    // ADDITION
    //-------------------------
    execute_operation(4'd0,4'd0,2'b00);
    execute_operation(4'd1,4'd1,2'b00);
    execute_operation(4'd7,4'd5,2'b00);
    execute_operation(4'd15,4'd15,2'b00);
    execute_operation(4'b1010,4'b0101,2'b00);

    //-------------------------
    // SUBTRACTION
    //-------------------------
    execute_operation(4'd15,4'd0,2'b01);
    execute_operation(4'd10,4'd3,2'b01);
    execute_operation(4'd5,4'd10,2'b01);
    execute_operation(4'd0,4'd15,2'b01);
    execute_operation(4'b1010,4'b0101,2'b01);

    //-------------------------
    // MULTIPLICATION
    //-------------------------
    execute_operation(4'd0,4'd0,2'b10);
    execute_operation(4'd1,4'd15,2'b10);
    execute_operation(4'd15,4'd15,2'b10);
    execute_operation(4'd6,4'd5,2'b10);
    execute_operation(4'd9,4'd8,2'b10);

    //-------------------------
    // DIVISION
    //-------------------------
    execute_operation(4'd12,4'd3,2'b11);
    execute_operation(4'd15,4'd1,2'b11);
    execute_operation(4'd15,4'd15,2'b11);
    execute_operation(4'd0,4'd15,2'b11);

    //-------------------------
    // DIVIDE BY ZERO
    //-------------------------
    execute_operation(4'd10,4'd0,2'b11);
    execute_operation(4'd0,4'd0,2'b11);

    //-------------------------
    // Toggle every input bit
    //-------------------------
    execute_operation(4'b0001,4'b0010,2'b00);
    execute_operation(4'b0011,4'b0100,2'b01);
    execute_operation(4'b0101,4'b0110,2'b10);
    execute_operation(4'b0111,4'b1000,2'b11);
    execute_operation(4'b1001,4'b1010,2'b00);
    execute_operation(4'b1011,4'b1100,2'b01);
    execute_operation(4'b1101,4'b1110,2'b10);
    execute_operation(4'b1111,4'b0001,2'b11);

    //-------------------------
    // Mid Simulation Reset
    //-------------------------
    @(posedge clk);
    rst = 1;

    @(posedge clk);
    rst = 0;

    //-------------------------
    // Run again after reset
    //-------------------------
    execute_operation(4'd8,4'd4,2'b00);
    execute_operation(4'd8,4'd4,2'b01);
    execute_operation(4'd8,4'd4,2'b10);
    execute_operation(4'd8,4'd4,2'b11);

    //-------------------------
    // Random tests
    //-------------------------
    repeat(50)
    begin
        execute_operation($random,$random,$random);
    end

    #50;

    $finish;

end

initial begin
    $monitor("Time=%0t rst=%b start=%b sel=%b A=%d B=%d Y=%d done=%b",
             $time,rst,start,sel,A,B,Y,done);
end

endmodule
