

module tb_alu;

reg  [3:0] a;
reg  [3:0] b;
reg  [1:0] op;

wire [3:0] y_good;
wire [3:0] y_bad;

// Instantiate alu_good
alu_good uut_good (
    .a(a),
    .b(b),
    .op(op),
    .y(y_good)
);

// Instantiate alu_bad
alu_bad uut_bad (
    .a(a),
    .b(b),
    .op(op),
    .y(y_bad)
);

initial begin
    a = 4'd5;
    b = 4'd2;

    op = 2'b00; #10;
    op = 2'b01; #10;
    op = 2'b10; #10;
    op = 2'b11; #10;

    // Additional test cases
    a = 4'd10; b = 4'd3;

    op = 2'b00; #10;
    op = 2'b01; #10;
    op = 2'b10; #10;
    op = 2'b11; #10;

    $finish;
end

initial begin
    $monitor("Time=%0t  a=%d  b=%d  op=%b  alu_good=%d  alu_bad=%d",
             $time, a, b, op, y_good, y_bad);
end

endmodule
