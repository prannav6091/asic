module tb_fsm_less;

    reg clk, rst, x;
    wire y;

    // Instantiate DUT
    fsm_cov dut (
        .clk(clk),
        .rst(rst),
        .x(x),
        .y(y)
    );

    // Clock Generation: 10ns period
    always #5 clk = ~clk;

    initial begin
        // ----------------------------------------------------
        // 1. Initialize Signals
        // ----------------------------------------------------
        clk = 0;
        rst = 1;
        x   = 0;

        // Synchronize with clock edges
        repeat (2) @(posedge clk);
        #1;
        rst = 0; // rst: 1 -> 0 (Enters S0)

        // ----------------------------------------------------
        // 2. Cover S0 Self-Loop & Transition S0 -> S1
        // ----------------------------------------------------
        x = 0; @(posedge clk); #1; // S0 -> S0 (x = 0)
        x = 1; @(posedge clk); #1; // S0 -> S1 (x = 1, toggles x: 0 -> 1)

        // ----------------------------------------------------
        // 3. Cover S1 Fallback Branch & S1 -> S2 Sequence
        // ----------------------------------------------------
        x = 0; @(posedge clk); #1; // S1 -> S0 (x = 0, toggles x: 1 -> 0)
        
        x = 1; @(posedge clk); #1; // S0 -> S1
        x = 1; @(posedge clk); #1; // S1 -> S2 (Enters S2, triggers y if applicable)

        // ----------------------------------------------------
        // 4. Cover S2 Branches & Return to S0
        // ----------------------------------------------------
        x = 1; @(posedge clk); #1; // S2 -> S2 / S1 (x = 1)
        x = 0; @(posedge clk); #1; // S2 -> S0 (x = 0)

        // ----------------------------------------------------
        // 5. Complete Toggle Coverage on Reset (rst: 0 -> 1 -> 0)
        // ----------------------------------------------------
        x = 1; @(posedge clk); #1; // Move to active state S1
        rst = 1; @(posedge clk); #1; // Active reset (toggles rst: 0 -> 1)
        rst = 0; @(posedge clk); #1; // Return to operation (toggles rst: 1 -> 0)

        #20;
        $finish;
    end

endmodule
