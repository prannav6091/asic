module tb_fsm_full;

    reg clk, rst, x;
    wire y;

    fsm_cov dut (
        .clk(clk),
        .rst(rst),
        .x(x),
        .y(y)
    );

    // Clock Generation: 10ns period
    always #5 clk = ~clk;

    initial begin
        // Initialize
        clk = 0;
        rst = 1;
        x   = 0;
        
        // Hold reset for 2 clock cycles
        repeat (2) @(posedge clk);
        #1;
        rst = 0; // Transition -> S0

        // ----------------------------------------------------
        // 1. Cover S0 self-loop (x = 0)
        // ----------------------------------------------------
        x = 0;
        @(posedge clk); #1;

        // ----------------------------------------------------
        // 2. S0 -> S1 (x = 1), then S1 -> S0 fallback (x = 0)
        // ----------------------------------------------------
        x = 1; @(posedge clk); #1; // S0 -> S1
        x = 0; @(posedge clk); #1; // S1 -> S0 (MISSING ARC FIX 1)

        // ----------------------------------------------------
        // 3. S0 -> S1 -> S2 sequence
        // ----------------------------------------------------
        x = 1; @(posedge clk); #1; // S0 -> S1
        x = 1; @(posedge clk); #1; // S1 -> S2

        // ----------------------------------------------------
        // 4. S2 -> S2 / S1 self-loop or forward branch (x = 1)
        // ----------------------------------------------------
        x = 1; @(posedge clk); #1; // S2 on x=1 (MISSING ARC FIX 2)

        // ----------------------------------------------------
        // 5. S2 -> S0 transition (x = 0)
        // ----------------------------------------------------
        x = 0; @(posedge clk); #1; // S2 -> S0

        // ----------------------------------------------------
        // 6. Test asynchronous / synchronous Reset from non-idle state
        // ----------------------------------------------------
        x = 1; @(posedge clk); #1; // Move to S1
        rst = 1; @(posedge clk); #1; // Reset from S1 -> S0
        rst = 0; @(posedge clk); #1;

        #20;
        $finish;
    end

endmodule
