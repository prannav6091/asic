

module tb_expression_full;

reg a, b, c;
wire y;

// Instantiate DUT
expression_cov dut(
    .a(a),
    .b(b),
    .c(c),
    .y(y)
);

integer i;

initial begin
    // Initialize
    a = 0; b = 0; c = 0;
    #10;

    // Loop through all 8 input combinations (000 to 111)
    for (i = 0; i < 8; i = i + 1) begin
        {a, b, c} = i[2:0];
        #10;
    end

    // Extra step to return signals to 0 so all inputs hit both 1->0 and 0->1 transitions
    {a, b, c} = 3'b000;
    #10;

    $finish;
end

endmodule
