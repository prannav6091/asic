# Robust Report Parser & Metrics Comparator for Cadence Genus
# Place in 'fir_tech' directory and execute via: tclsh parse_to_txt.tcl

set ROOT_DIR [pwd]

set designs {
    {"fir"                "fir_4tap"}
    {"fir_area_optimized" "fir_4tap_shared_mult"}
    {"fir_piplined"       "fir_4tap_pipelined"}
}

set corners {"slow" "typical" "fast"}
set techs   {"45nm" "90nm" "180nm"}

set txt_file "synthesis_comparison_summary.txt"
set fp [open $txt_file "w"]

set format_str "%-20s %-8s %-6s %-16s %-12s %-10s %-14s"

# File & Console Header
puts $fp "==================================================================================================="
puts $fp "                                GENUS SYNTHESIS COMPARISON SUMMARY                                  "
puts $fp "==================================================================================================="
puts $fp [format $format_str "Design" "Corner" "Tech" "Slack (ps)" "Area" "Gates" "Power"]
puts $fp [string repeat "-" 100]

puts [format $format_str "Design" "Corner" "Tech" "Slack (ps)" "Area" "Gates" "Power"]
puts [string repeat "-" 100]

foreach design_info $designs {
    set dir_name   [lindex $design_info 0]
    set top_module [lindex $design_info 1]

    foreach corner $corners {
        foreach tech $techs {

            set report_dir "${ROOT_DIR}/${dir_name}/${corner}/${tech}/output/reports"
            
            set timing_rpt "${report_dir}/${top_module}_timing.rpt"
            set area_rpt   "${report_dir}/${top_module}_area.rpt"
            set gates_rpt  "${report_dir}/${top_module}_gates.rpt"
            set power_rpt  "${report_dir}/${top_module}_power.rpt"
            set qor_rpt    "${report_dir}/${top_module}_qor.rpt"

            set slack "N/A"
            set area  "N/A"
            set gates "N/A"
            set power "N/A"
            set power_unit ""

            # Parse Power & Dynamic Power Unit
            if {[file exists $power_rpt]} {
                set ch [open $power_rpt r]
                while {[gets $ch line] >= 0} {
                    if {[regexp -nocase {power unit:\s*(\w+)} $line -> unit]} {
                        set power_unit $unit
                    } elseif {[regexp -nocase {total power:\s*([-\d\.\+eE]+\s*\w+)} $line -> val]} {
                        set power $val
                        break
                    } elseif {[regexp -nocase {Subtotal\s+[-\d\.\+eE]+\s+[-\d\.\+eE]+\s+[-\d\.\+eE]+\s+([-\d\.\+eE]+)} $line -> val]} {
                        set power "${val}${power_unit}"
                        break
                    } elseif {[regexp -nocase {Total\s+[-\d\.\+eE]+\s+[-\d\.\+eE]+\s+[-\d\.\+eE]+\s+([-\d\.\+eE]+)} $line -> val]} {
                        set power "${val}${power_unit}"
                        break
                    }
                }
                close $ch
            }

            # Parse Timing Slack / WNS
            if {[file exists $timing_rpt]} {
                set ch [open $timing_rpt r]
                while {[gets $ch line] >= 0} {
                    if {[regexp -nocase {slack[:=\s]+([-\d\.\+eE]+)} $line -> val]} {
                        set slack $val
                        break
                    } elseif {[regexp -nocase {(?:MET|VIOLATED)\s*\(\s*([-\d\.\+eE]+)\s*ps} $line -> val]} {
                        set slack $val
                        break
                    } elseif {[regexp -nocase {no\s+constrained\s+timing\s+paths} $line]} {
                        set slack "Unconstrained"
                        break
                    }
                }
                close $ch
            }

            # Parse Total Area
            if {[file exists $area_rpt]} {
                set ch [open $area_rpt r]
                while {[gets $ch line] >= 0} {
                    if {[regexp -nocase {total cell area:\s*([-\d\.]+)} $line -> val]} {
                        set area $val
                        break
                    } elseif {[regexp -nocase {total\s+\d+\s+([-\d\.]+)} $line -> val]} {
                        set area $val
                    }
                }
                close $ch
            }

            # Parse Gate Count
            if {[file exists $gates_rpt]} {
                set ch [open $gates_rpt r]
                while {[gets $ch line] >= 0} {
                    if {[regexp -nocase {total\s+(\d+)} $line -> val]} {
                        set gates $val
                    }
                }
                close $ch
            }

            # Fallback to QoR report for any uncaptured metrics
            if {($slack eq "N/A" || $area eq "N/A" || $power eq "N/A" || $gates eq "N/A") && [file exists $qor_rpt]} {
                set ch [open $qor_rpt r]
                while {[gets $ch line] >= 0} {
                    if {$slack eq "N/A" && [regexp -nocase {worst slack[:=\s]+([-\d\.]+)} $line -> val]} {
                        set slack $val
                    }
                    if {$area eq "N/A" && [regexp -nocase {cell area[:=\s]+([-\d\.]+)} $line -> val]} {
                        set area $val
                    }
                    if {$gates eq "N/A" && [regexp -nocase {leaf instance count[:=\s]+(\d+)} $line -> val]} {
                        set gates $val
                    }
                    if {$power eq "N/A" && [regexp -nocase {total power[:=\s]+([-\d\.\+eE]+\s*\w+)} $line -> val]} {
                        set power $val
                    }
                }
                close $ch
            }

            if {$slack eq "N/A"} { set slack "Unconstrained" }

            set formatted_row [format $format_str $dir_name $corner $tech $slack $area $gates $power]
            puts $fp $formatted_row
            puts $formatted_row
        }
    }
}

puts $fp [string repeat "=" 100]
close $fp

puts [string repeat "=" 100]
puts "Parsed summary successfully written to: '${ROOT_DIR}/${txt_file}'"
