//`timescale 1ns / 1ps

module tb_fsm_101_min;

    reg clk = 0, rst = 1, x = 0;
    wire y;

    // Instantiate UUT
    fsm_101 uut (.clk(clk), .rst(rst), .x(x), .y(y));

    // 10ns Clock
    always #5 clk = ~clk;

    initial begin
        // Apply reset first
        #12 rst = 0;

        // Optimized 9-bit sequence for 100% full coverage
        #10 x = 1; // S0 -> S1
        #10 x = 1; // S1 -> S1 (Self-loop on 1)
        #10 x = 0; // S1 -> S2 
        #10 x = 0; // S2 -> S0 (Reset to S0 on 0)
        #10 x = 0; // S0 -> S0 (Self-loop on 0)
        #10 x = 1; // S0 -> S1
        #10 x = 0; // S1 -> S2
        #10 x = 1; // S2 -> S3 (Detects "101", y = 1)
        #10 x = 0; // S3 -> S2 (Overlapping transition)
        #10 x = 1; // S2 -> S3 (Detects "101", y = 1)
        #10 x = 1; // S3 -> S1 (Transition on 1 from S3)

        #20 $finish;
    end

    initial begin
        $monitor("Time=%0t | rst=%b | x=%b | State=S%0d | y=%b", $time, rst, x, uut.state, y);
    end

endmodule
