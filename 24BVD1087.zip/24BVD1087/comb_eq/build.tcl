# Define the top module name
set TOP_MODULE "equation_logic"

# Set library and HDL search paths
set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
#set_db init_hdl_search_path /home/Sakthivel/lab5/equation_logic

# Read standard cell library
read_libs slow.lib

# Read the Verilog design file(s)
read_hdl {equation_logic.v}

# Elaborate the design
elaborate 

# Read constraints (Ensure you have a basic .sdc file created for this)
read_sdc equation_logic.sdc

# Set synthesis optimization effort levels
set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium

# Generic Synthesis (Technology independent)
syn_generic
write_hdl > output/netlist/${TOP_MODULE}_generic.v

# Mapping Synthesis (Technology dependent)
syn_map
write_hdl > output/netlist/${TOP_MODULE}_mapped.v

# Optimization Synthesis (Timing/Area/Power optimization)
syn_opt
write_hdl > output/netlist/${TOP_MODULE}_opt.v

# Write out the synthesized constraints
write_sdc > output/constraints/${TOP_MODULE}_synth.sdc

# Generate post-synthesis reports
report_timing > output/reports/${TOP_MODULE}_timing.rpt
report_power > output/reports/${TOP_MODULE}_power.rpt
report_area > output/reports/${TOP_MODULE}_area.rpt
report_gates > output/reports/${TOP_MODULE}_gates.rpt
report_qor > output/reports/${TOP_MODULE}_qor.rpt

# Open Genus GUI for visual analysis
gui_show
