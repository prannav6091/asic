module equation_arithmetic #(
    parameter WIDTH = 8
)(
    input  wire [WIDTH-1:0] A,
    input  wire [WIDTH-1:0] B,
    input  wire [WIDTH-1:0] C,
    input  wire [WIDTH-1:0] D,
    output wire [(2*WIDTH)-1:0] Y
);

    assign Y = (A * B) - (C * D);

endmodule
