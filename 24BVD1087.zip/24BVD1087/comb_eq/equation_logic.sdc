################################################################################
# SDC Constraints for equation_logic (Combinational: Y = AB - CD)
# Target Virtual Clock Frequency: 100 MHz (Period: 10.0 ns)
################################################################################

# ------------------------------------------------------------------------------
# 1. Clock Definition (Virtual Clock)
# ------------------------------------------------------------------------------
# Creating a virtual clock (no port association) to constrain combinational paths
create_clock -name virtual_clk -period 10.0 

# Set clock network uncertainties (jitter, skew margins)
set_clock_uncertainty 0.2 [get_clocks virtual_clk]

# ------------------------------------------------------------------------------
# 2. Input Delays
# ------------------------------------------------------------------------------
# Assuming external launcher register clock-to-Q + board trace delay
set_input_delay -clock virtual_clk -max 2.0 [get_ports {A B C D}]
set_input_delay -clock virtual_clk -min 0.5 [get_ports {A B C D}]

# ------------------------------------------------------------------------------
# 3. Output Delays
# ------------------------------------------------------------------------------
# Assuming external capture register setup/hold requirements + board trace delay
set_output_delay -clock virtual_clk -max 2.0 [get_ports Y]
set_output_delay -clock virtual_clk -min -0.5 [get_ports Y]

# ------------------------------------------------------------------------------
# 4. Environmental and Load Constraints
# ------------------------------------------------------------------------------
# Define driving cell for input ports (Replace 'BUFX2' with a cell from your target slow.lib)
set_driving_cell -lib_cell BUFX2 [get_ports {A B C D}]

# Define output capacitive load (e.g., 5.0 pF)
set_load 5.0 [get_ports Y]
