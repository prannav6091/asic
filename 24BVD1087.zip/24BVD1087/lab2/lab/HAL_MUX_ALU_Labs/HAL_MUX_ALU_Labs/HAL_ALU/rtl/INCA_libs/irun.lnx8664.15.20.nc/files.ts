1785247213 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_ALU/rtl/cds.lib
1785247216 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_ALU/rtl/hdl.var
1785247198 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_ALU/rtl/alu_good.v
1784269297 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_ALU/rtl/alu_bad.v
