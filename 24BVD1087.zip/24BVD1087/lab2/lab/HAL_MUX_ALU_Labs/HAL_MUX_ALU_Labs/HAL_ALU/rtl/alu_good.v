//module alu_good(input [3:0] a,b,input [1:0] op,output reg [3:0] y);
//always @(*) begin
//case(op)
//2'b00:y=a+b;
//2'b01:y=a-b;
//2'b10:y=a&b;
//default:y=a|b;
//endcase
//end
//endmodule

// =============================================================================
// File Name:   alu_good.v
// Description: Fully compliant, parameterized registered ALU with overflow
//              handling using combinational wires to avoid unread registers.
// =============================================================================



// =============================================================================
// File Name:   alu_good.v
// Description: Fully compliant, parameterized registered ALU. Uses inline
//              slicing to satisfy both overflow and unread wire rules.
// =============================================================================

module alu_good #(
    parameter [31:0] DATA_WIDTH = 32'd4,
    parameter [31:0] OP_WIDTH   = 32'd2
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire [DATA_WIDTH-1:0] a,
    input  wire [DATA_WIDTH-1:0] b,
    input  wire [  OP_WIDTH-1:0] op,
    output reg  [DATA_WIDTH-1:0] y
);

    // Pipeline registers for input isolation
    reg [DATA_WIDTH-1:0] reg_a;
    reg [DATA_WIDTH-1:0] reg_b;
    reg [  OP_WIDTH-1:0] reg_op;

    // Labeled sequential block for registering inputs
    always @(posedge clk or negedge rst_n) begin : proc_reg_inputs
        if (rst_n == 1'b0) begin
            reg_a  <= {DATA_WIDTH{1'b0}};
            reg_b  <= {DATA_WIDTH{1'b0}};
            reg_op <= {OP_WIDTH{1'b0}};
        end else begin
            reg_a  <= a;
            reg_b  <= b;
            reg_op <= op;
        end
    end

    // Labeled sequential block for registered ALU logic execution
    always @(posedge clk or negedge rst_n) begin : proc_alu_output
        if (rst_n == 1'b0) begin
            y <= {DATA_WIDTH{1'b0}};
        end else begin
            case (reg_op)
                // Inline slicing handles overflow checks cleanly without
                // generating unread intermediate net connections.
                2'b00: begin
                    y <= {reg_a + reg_b}[DATA_WIDTH-1:0];
                end
                2'b01: begin
                    y <= {reg_a - reg_b}[DATA_WIDTH-1:0];
                end
                2'b10: begin
                    y <= reg_a & reg_b;
                end
                default: begin
                    y <= reg_a | reg_b;
                end
            endcase
        end
    end

endmodule
