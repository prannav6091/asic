1784269297 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_MUX/rtl/mux_bad.v
1785246809 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_MUX/rtl/mux_good.v
