1785246880 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_MUX/rtl/cds.lib
1785246885 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_MUX/rtl/hdl.var
1785246809 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_MUX/rtl/mux_good.v
1784269297 /home/vlsi29/24BVD1087/lab2/lab/HAL_MUX_ALU_Labs/HAL_MUX_ALU_Labs/HAL_MUX/rtl/mux_bad.v
