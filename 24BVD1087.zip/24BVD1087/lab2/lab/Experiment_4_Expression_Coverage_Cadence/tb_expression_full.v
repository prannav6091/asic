
module tb_expression_full;

reg a,b,c;
wire y;

expression_cov dut(
.a(a),
.b(b),
.c(c),
.y(y)
);

initial begin
    // Expression = 1
    a=1; b=1; c=1;
    #10;
   
    a=0; b=0; c=0;
    #10;

    a=1; b=1; c=1;
    #10;

    $finish;
end

endmodule
