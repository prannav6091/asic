initial begin

    rst_n = 0;
    start = 0;
    op_in = 0;
    operand_a = 0;
    operand_b = 0;

    repeat(2) @(posedge clk);
    rst_n = 1;

    // ADD
    run_test(2'b00,16'd10,16'd20);

    // SUB
    run_test(2'b01,16'd30,16'd10);

    // MUL
    run_test(2'b10,16'd7,16'd8);

    // DIV
    run_test(2'b11,16'd50,16'd7);

    // DIV BY ZERO
    run_test(2'b11,16'd25,16'd0);

    #20;
    $finish;
end
