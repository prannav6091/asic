module alu (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire [1:0]  op,     // 00: ADD, 01: SUB, 10: MUL, 11: DIV
    output reg  [31:0] result, // {Remainder[15:0], Quotient[15:0]} for DIV
    output reg         dbz     // Divide by zero flag
);

    always @(*) begin
        dbz    = 1'b0;
        result = 32'd0;

        case (op)
            // Case 1: Simple Arithmetic
            2'b00: result = {16'd0, a + b}; // ADD
            2'b01: result = {16'd0, a - b}; // SUB

            // Case 2: Multi-bit / Division Logic
            2'b10: result = a * b;          // MUL
            2'b11: begin                    // DIV
                if (b == 16'd0) begin
                    dbz    = 1'b1;
                    result = 32'd0;
                end else begin
                    result = {(a % b), (a / b)};
                end
            end
        endcase
    end

endmodule
