module datapath (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        load_en,    // Enabled during LOAD state
    input  wire        exec_en,    // Enabled during EXECUTE state
    input  wire [1:0]  op_in,
    input  wire [15:0] operand_a,
    input  wire [15:0] operand_b,
    output wire [1:0]  op_out,
    output reg  [31:0] result,
    output reg         dbz
);

    reg [15:0] reg_a, reg_b;
    reg [1:0]  reg_op;

    wire [31:0] alu_result;
    wire        alu_dbz;

    // Output latched operation to Controller if needed
    assign op_out = reg_op;

    // ALU Module Instance
    alu alu_inst (
        .a(reg_a),
        .b(reg_b),
        .op(reg_op),
        .result(alu_result),
        .dbz(alu_dbz)
    );

    // Register Loads
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            reg_a  <= 16'd0;
            reg_b  <= 16'd0;
            reg_op <= 2'b00;
            result <= 32'd0;
            dbz    <= 1'b0;
        end else if (load_en) begin
            reg_a  <= operand_a;
            reg_b  <= operand_b;
            reg_op <= op_in;
        end else if (exec_en) begin
            result <= alu_result;
            dbz    <= alu_dbz;
        end
    end

endmodule
