module controller (
    input  wire clk,
    input  wire rst_n,
    input  wire start,
    output reg  load_en,
    output reg  exec_en,
    output reg  done
);

    // FSM States
    localparam IDLE    = 2'b00;
    localparam LOAD    = 2'b01;
    localparam EXECUTE = 2'b10;

    reg [1:0] state, next_state;

    // State Register
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            state <= IDLE;
        else
            state <= next_state;
    end

    // Next-State Logic
    always @(*) begin
        case (state)
            IDLE:    next_state = start ? LOAD : IDLE;
            LOAD:    next_state = EXECUTE;
            EXECUTE: next_state = IDLE;
            default: next_state = IDLE;
        endcase
    end

    // Control Outputs
    always @(*) begin
        load_en = 1'b0;
        exec_en = 1'b0;
        done    = 1'b0; // Fixed typo here

        case (state)
            LOAD:    load_en = 1'b1;
            EXECUTE: begin
                exec_en = 1'b1;
                done    = 1'b1;
            end
            default: ;
        endcase
    end

endmodule
