module fa_tb();
reg a,b,cin;
wire sum,cout;
fa uut(.sum(sum),.cout(cout),.a(a),.b(b),.cin(cin));
initial begin
$monitor("Time=%0d a=%0b b=%0b cin=%0b sum=%0b cout=%0b",
$time,a,b,cin,sum,cout);
a = 1'b0; b = 1'b0; cin = 1'b0; #10;
a = 1'b1; b = 1'b1; cin = 1'b1; #10;
a = 1'b0; b = 1'b0; cin = 1'b0; #10;
$finish;
end
endmodule



