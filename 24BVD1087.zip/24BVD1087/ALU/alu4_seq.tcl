set TOP_MODULE "alu4_seq"

set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
set_db init_hdl_search_path /home/vlsi30/24BVD1020/24BVD1020/4bit_alu

read_libs slow.lib
read_hdl {alu4_seq.v}

elaborate

read_sdc alu4_seq.sdc

set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium

# ================================================================
# GENERIC SYNTHESIS
# ================================================================

syn_generic

write_hdl > output/netlist/${TOP_MODULE}_generic.v

report_timing > output/reports/${TOP_MODULE}_generic_timing.rpt
report_power > output/reports/${TOP_MODULE}_generic_power.rpt
report_area > output/reports/${TOP_MODULE}_generic_area.rpt
report_gates > output/reports/${TOP_MODULE}_generic_gates.rpt
report_qor > output/reports/${TOP_MODULE}_generic_qor.rpt


# ================================================================
# MAPPED SYNTHESIS
# ================================================================

syn_map

write_hdl > output/netlist/${TOP_MODULE}_mapped.v

report_timing > output/reports/${TOP_MODULE}_mapped_timing.rpt
report_power > output/reports/${TOP_MODULE}_mapped_power.rpt
report_area > output/reports/${TOP_MODULE}_mapped_area.rpt
report_gates > output/reports/${TOP_MODULE}_mapped_gates.rpt
report_qor > output/reports/${TOP_MODULE}_mapped_qor.rpt


# ================================================================
# OPTIMIZED SYNTHESIS
# ================================================================

syn_opt

write_hdl > output/netlist/${TOP_MODULE}_opt.v

report_timing > output/reports/${TOP_MODULE}_opt_timing.rpt
report_power > output/reports/${TOP_MODULE}_opt_power.rpt
report_area > output/reports/${TOP_MODULE}_opt_area.rpt
report_gates > output/reports/${TOP_MODULE}_opt_gates.rpt
report_qor > output/reports/${TOP_MODULE}_opt_qor.rpt

write_sdc > output/constrints/${TOP_MODULE}_synth.sdc

gui_show
