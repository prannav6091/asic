################################################################################
# SDC Constraints for 4-bit Sequential ALU
################################################################################

# Clock
create_clock -name Clk -period 10.0 [get_ports Clk]

set_clock_uncertainty 0.2 [get_clocks Clk]
set_clock_transition 0.1 [get_clocks Clk]

# Input delays
set_input_delay -clock Clk -max 2.0 [get_ports {A[*] B[*] Sel[*] Rst}]
set_input_delay -clock Clk -min 0.5 [get_ports {A[*] B[*] Sel[*] Rst}]

# Output delays
set_output_delay -clock Clk -max 2.0 [get_ports {Y[*] Cout}]
set_output_delay -clock Clk -min -0.5 [get_ports {Y[*] Cout}]

# Input transition
set_input_transition 0.1 [get_ports {A[*] B[*] Sel[*] Rst}]

# Output load
set_load 5.0 [get_ports {Y[*] Cout}]

# Driving cell
set_driving_cell -lib_cell BUFX2 [get_ports {A[*] B[*] Sel[*] Rst}]
