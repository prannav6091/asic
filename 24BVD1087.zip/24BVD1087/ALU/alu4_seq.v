module alu4_seq (
    input Clk,
    input Rst,
    input [3:0] A,
    input [3:0] B,
    input [1:0] Sel,
    output reg [3:0] Y,
    output reg Cout
);

always @(posedge Clk) begin
    if (Rst) begin
        Y <= 4'b0000;
        Cout <= 1'b0;
    end
    else begin
        case (Sel)
            2'b00: {Cout,Y} <= A + B;
            2'b01: {Cout,Y} <= A - B;
            2'b10: begin
                Y <= A & B;
                Cout <= 1'b0;
            end
            2'b11: begin
                Y <= A | B;
                Cout <= 1'b0;
            end
        endcase
    end
end

endmodule
