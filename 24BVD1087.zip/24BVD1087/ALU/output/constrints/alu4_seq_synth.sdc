# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.14-s082_1 on Tue Sep 08 18:15:20 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design alu4_seq

create_clock -name "Clk" -period 10.0 -waveform {0.0 5.0} [get_ports Clk]
set_clock_transition 0.1 [get_clocks Clk]
set_load -pin_load 5.0 [get_ports {Y[3]}]
set_load -pin_load 5.0 [get_ports {Y[2]}]
set_load -pin_load 5.0 [get_ports {Y[1]}]
set_load -pin_load 5.0 [get_ports {Y[0]}]
set_load -pin_load 5.0 [get_ports Cout]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {A[3]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {A[2]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {A[1]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {A[0]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {B[3]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {B[2]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {B[1]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {B[0]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {Sel[1]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {Sel[0]}]
set_input_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports Rst]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {A[3]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {A[2]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {A[1]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {A[0]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {B[3]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {B[2]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {B[1]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {B[0]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {Sel[1]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports {Sel[0]}]
set_input_delay -clock [get_clocks Clk] -add_delay -min 0.5 [get_ports Rst]
set_output_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {Y[3]}]
set_output_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {Y[2]}]
set_output_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {Y[1]}]
set_output_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports {Y[0]}]
set_output_delay -clock [get_clocks Clk] -add_delay -max 2.0 [get_ports Cout]
set_output_delay -clock [get_clocks Clk] -add_delay -min -0.5 [get_ports {Y[3]}]
set_output_delay -clock [get_clocks Clk] -add_delay -min -0.5 [get_ports {Y[2]}]
set_output_delay -clock [get_clocks Clk] -add_delay -min -0.5 [get_ports {Y[1]}]
set_output_delay -clock [get_clocks Clk] -add_delay -min -0.5 [get_ports {Y[0]}]
set_output_delay -clock [get_clocks Clk] -add_delay -min -0.5 [get_ports Cout]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports Rst]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {A[3]}]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {A[2]}]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {A[1]}]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {A[0]}]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {B[3]}]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {B[2]}]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {B[1]}]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {B[0]}]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {Sel[1]}]
set_driving_cell -lib_cell BUFX2 -library slow -pin "Y" [get_ports {Sel[0]}]
set_wire_load_mode "enclosed"
set_clock_uncertainty -setup 0.2 [get_clocks Clk]
set_clock_uncertainty -hold 0.2 [get_clocks Clk]
