add_search_path ../LIB/ -library -both
read_library -liberty -both \
    /home/vlsi29/24BVD1087/lab6/SMS_Activity_Power_analaysis/Activity_Based_Power_Analysis_EASY_TCL/scripts/../LIB/teaching_base.lib \
    /home/vlsi29/24BVD1087/lab6/SMS_Activity_Power_analaysis/Activity_Based_Power_Analysis_EASY_TCL/scripts/../LIB/teaching_base.lib

