//module mux_good(input [3:0] a,b,input sel,output reg [3:0] y);
//always @(*) begin
// y=b;
// if(sel) y=a;
//end
//endmodule


module mux_good #(
    // Parameter width explicitly sized as a 32-bit constant expression
    // to prevent memory bloat warnings in the linter database.
    parameter [31:0] WIDTH = 32'd4
)(
    input  wire              clk,
    input  wire              rst_n,
    input  wire [WIDTH-1:0] a,
    input  wire [WIDTH-1:0] b,
    input  wire              sel,
    output reg  [WIDTH-1:0] y
);

    // Internal pipeline registers
    reg [WIDTH-1:0] reg_a;
    reg [WIDTH-1:0] reg_b;
    reg             reg_sel;

    // Labeled sequential block for inputs
    always @(posedge clk or negedge rst_n) begin : proc_reg_inputs
        if (rst_n == 1'b0) begin
            reg_a   <= {WIDTH{1'b0}};
            reg_b   <= {WIDTH{1'b0}};
            reg_sel <= 1'b0;
        end else begin
            reg_a   <= a;
            reg_b   <= b;
            reg_sel <= sel;
        end
    end

    // Labeled sequential block for registered MUX output
    always @(posedge clk or negedge rst_n) begin : proc_mux_output
        if (rst_n == 1'b0) begin
            y <= {WIDTH{1'b0}};
        end else begin
            if (reg_sel == 1'b1) begin
                y <= reg_a;
            end else begin
                y <= reg_b;
            end
        end
    end

endmodule
