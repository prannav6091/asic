
module equation_arithmetic_pipe #(
    parameter WIDTH = 8
)(
    input  wire                  clk,
    input  wire                  rst,
    input  wire [WIDTH-1:0]      A,
    input  wire [WIDTH-1:0]      B,
    input  wire [WIDTH-1:0]      C,
    input  wire [WIDTH-1:0]      D,
    output reg  [(2*WIDTH)-1:0]  Y
);

    // Stage 1: Product registers
    reg [(2*WIDTH)-1:0] product_ab;
    reg [(2*WIDTH)-1:0] product_cd;

    always @(posedge clk) begin
        if (rst) begin
            product_ab <= {(2*WIDTH){1'b0}};
            product_cd <= {(2*WIDTH){1'b0}};
        end
        else begin
            product_ab <= A * B;
            product_cd <= C * D;
        end
    end

    // Stage 2: Subtraction and output register
    always @(posedge clk) begin
        if (rst)
            Y <= {(2*WIDTH){1'b0}};
        else
            Y <= product_ab - product_cd;
    end

endmodule

