
################################################################################
# SDC Constraints for equation_arithmetic_pipe
# Function: Y = (A * B) - (C * D)
# Target Clock Frequency: 100 MHz (Period: 10.0 ns)
################################################################################

# ------------------------------------------------------------------------------
# 1. Clock Definition
# ------------------------------------------------------------------------------
create_clock -name clk -period 10.0 [get_ports clk]

# Clock uncertainty
set_clock_uncertainty 0.2 [get_clocks clk]

# ------------------------------------------------------------------------------
# 2. Input Delays
# ------------------------------------------------------------------------------
# External input arrival times relative to clk
set_input_delay -clock clk -max 2.0 [get_ports {A[*] B[*] C[*] D[*]}]
set_input_delay -clock clk -min 0.5 [get_ports {A[*] B[*] C[*] D[*]}]

# ------------------------------------------------------------------------------
# 3. Output Delays
# ------------------------------------------------------------------------------
# External output timing requirements relative to clk
set_output_delay -clock clk -max 2.0 [get_ports {Y[*]}]
set_output_delay -clock clk -min -0.5 [get_ports {Y[*]}]

# ------------------------------------------------------------------------------
# 4. Input Driving Cell
# ------------------------------------------------------------------------------
# Replace BUFX2 if it does not exist in your target library
set_driving_cell -lib_cell BUFX2 [get_ports {A[*] B[*] C[*] D[*]}]

# ------------------------------------------------------------------------------
# 5. Output Load
# ------------------------------------------------------------------------------
# Example load; confirm units and intended capacitance
set_load 5.0 [get_ports {Y[*]}]

# ------------------------------------------------------------------------------
# 6. Reset Constraint
# ------------------------------------------------------------------------------
# rst is synchronous in the example RTL.
# Reset timing should be constrained according to the actual reset interface.
set_input_delay -clock clk -max 2.0 [get_ports rst]
set_input_delay -clock clk -min 0.5 [get_ports rst]

