
//input ports
add mapped point clk clk -type PI PI
add mapped point rst rst -type PI PI
add mapped point A[7] A[7] -type PI PI
add mapped point A[6] A[6] -type PI PI
add mapped point A[5] A[5] -type PI PI
add mapped point A[4] A[4] -type PI PI
add mapped point A[3] A[3] -type PI PI
add mapped point A[2] A[2] -type PI PI
add mapped point A[1] A[1] -type PI PI
add mapped point A[0] A[0] -type PI PI
add mapped point B[7] B[7] -type PI PI
add mapped point B[6] B[6] -type PI PI
add mapped point B[5] B[5] -type PI PI
add mapped point B[4] B[4] -type PI PI
add mapped point B[3] B[3] -type PI PI
add mapped point B[2] B[2] -type PI PI
add mapped point B[1] B[1] -type PI PI
add mapped point B[0] B[0] -type PI PI
add mapped point C[7] C[7] -type PI PI
add mapped point C[6] C[6] -type PI PI
add mapped point C[5] C[5] -type PI PI
add mapped point C[4] C[4] -type PI PI
add mapped point C[3] C[3] -type PI PI
add mapped point C[2] C[2] -type PI PI
add mapped point C[1] C[1] -type PI PI
add mapped point C[0] C[0] -type PI PI
add mapped point D[7] D[7] -type PI PI
add mapped point D[6] D[6] -type PI PI
add mapped point D[5] D[5] -type PI PI
add mapped point D[4] D[4] -type PI PI
add mapped point D[3] D[3] -type PI PI
add mapped point D[2] D[2] -type PI PI
add mapped point D[1] D[1] -type PI PI
add mapped point D[0] D[0] -type PI PI

//output ports
add mapped point Y[15] Y[15] -type PO PO
add mapped point Y[14] Y[14] -type PO PO
add mapped point Y[13] Y[13] -type PO PO
add mapped point Y[12] Y[12] -type PO PO
add mapped point Y[11] Y[11] -type PO PO
add mapped point Y[10] Y[10] -type PO PO
add mapped point Y[9] Y[9] -type PO PO
add mapped point Y[8] Y[8] -type PO PO
add mapped point Y[7] Y[7] -type PO PO
add mapped point Y[6] Y[6] -type PO PO
add mapped point Y[5] Y[5] -type PO PO
add mapped point Y[4] Y[4] -type PO PO
add mapped point Y[3] Y[3] -type PO PO
add mapped point Y[2] Y[2] -type PO PO
add mapped point Y[1] Y[1] -type PO PO
add mapped point Y[0] Y[0] -type PO PO

//inout ports




//Sequential Pins
add mapped point Y[15]/q Y_reg[15]/Q -type DFF DFF
add mapped point Y[14]/q Y_reg[14]/Q -type DFF DFF
add mapped point Y[12]/q Y_reg[12]/Q -type DFF DFF
add mapped point Y[8]/q Y_reg[8]/Q -type DFF DFF
add mapped point Y[0]/q Y_reg[0]/Q -type DFF DFF
add mapped point Y[7]/q Y_reg[7]/Q -type DFF DFF
add mapped point Y[11]/q Y_reg[11]/Q -type DFF DFF
add mapped point Y[6]/q Y_reg[6]/Q -type DFF DFF
add mapped point Y[5]/q Y_reg[5]/Q -type DFF DFF
add mapped point Y[13]/q Y_reg[13]/Q -type DFF DFF
add mapped point Y[10]/q Y_reg[10]/Q -type DFF DFF
add mapped point Y[4]/q Y_reg[4]/Q -type DFF DFF
add mapped point Y[3]/q Y_reg[3]/Q -type DFF DFF
add mapped point Y[9]/q Y_reg[9]/Q -type DFF DFF
add mapped point Y[2]/q Y_reg[2]/Q -type DFF DFF
add mapped point Y[1]/q Y_reg[1]/Q -type DFF DFF
add mapped point product_ab[12]/q product_ab_reg[12]/Q -type DFF DFF
add mapped point product_ab[2]/q product_ab_reg[2]/Q -type DFF DFF
add mapped point product_ab[3]/q product_ab_reg[3]/Q -type DFF DFF
add mapped point product_ab[4]/q product_ab_reg[4]/Q -type DFF DFF
add mapped point product_cd[6]/q product_cd_reg[6]/Q -type DFF DFF
add mapped point product_ab[1]/q product_ab_reg[1]/Q -type DFF DFF
add mapped point product_ab[13]/q product_ab_reg[13]/Q -type DFF DFF
add mapped point product_cd[13]/q product_cd_reg[13]/Q -type DFF DFF
add mapped point product_cd[9]/q product_cd_reg[9]/Q -type DFF DFF
add mapped point product_cd[5]/q product_cd_reg[5]/Q -type DFF DFF
add mapped point product_ab[7]/q product_ab_reg[7]/Q -type DFF DFF
add mapped point product_ab[8]/q product_ab_reg[8]/Q -type DFF DFF
add mapped point product_ab[9]/q product_ab_reg[9]/Q -type DFF DFF
add mapped point product_ab[10]/q product_ab_reg[10]/Q -type DFF DFF
add mapped point product_ab[11]/q product_ab_reg[11]/Q -type DFF DFF
add mapped point product_cd[1]/q product_cd_reg[1]/Q -type DFF DFF
add mapped point product_ab[0]/q product_ab_reg[0]/Q -type DFF DFF
add mapped point product_ab[15]/q product_ab_reg[15]/Q -type DFF DFF
add mapped point product_cd[0]/q product_cd_reg[0]/Q -type DFF DFF
add mapped point product_cd[2]/q product_cd_reg[2]/Q -type DFF DFF
add mapped point product_cd[3]/q product_cd_reg[3]/Q -type DFF DFF
add mapped point product_cd[4]/q product_cd_reg[4]/Q -type DFF DFF
add mapped point product_ab[6]/q product_ab_reg[6]/Q -type DFF DFF
add mapped point product_ab[5]/q product_ab_reg[5]/Q -type DFF DFF
add mapped point product_cd[7]/q product_cd_reg[7]/Q -type DFF DFF
add mapped point product_cd[8]/q product_cd_reg[8]/Q -type DFF DFF
add mapped point product_cd[10]/q product_cd_reg[10]/Q -type DFF DFF
add mapped point product_cd[11]/q product_cd_reg[11]/Q -type DFF DFF
add mapped point product_cd[12]/q product_cd_reg[12]/Q -type DFF DFF
add mapped point product_cd[14]/q product_cd_reg[14]/Q -type DFF DFF
add mapped point product_cd[15]/q product_cd_reg[15]/Q -type DFF DFF
add mapped point product_ab[14]/q product_ab_reg[14]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
